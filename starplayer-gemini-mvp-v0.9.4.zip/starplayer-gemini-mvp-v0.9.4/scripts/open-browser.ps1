param(
  [string]$Url = "http://127.0.0.1:3000"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$dataDir = Join-Path $root "data"
$logPath = Join-Path $dataDir "browser-open.log"
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null

function Write-OpenLog([string]$Message) {
  try { Add-Content -Path $logPath -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message) -Encoding UTF8 } catch {}
}

Write-OpenLog "Waiting for $Url"
$ready = $false
$deadline = (Get-Date).AddSeconds(60)
while ((Get-Date) -lt $deadline) {
  try {
    $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2
    if ([int]$response.StatusCode -ge 200 -and [int]$response.StatusCode -lt 500) {
      $ready = $true
      break
    }
  } catch {}
  Start-Sleep -Milliseconds 500
}

if (-not $ready) {
  Write-OpenLog "Timed out waiting for server. Browser was not opened."
  exit 1
}

$methods = @(
  @{ Name = "Start-Process URL"; Run = { Start-Process $Url | Out-Null } },
  @{ Name = "explorer.exe"; Run = { Start-Process "explorer.exe" -ArgumentList $Url | Out-Null } },
  @{ Name = "cmd start"; Run = { Start-Process "cmd.exe" -ArgumentList "/d", "/s", "/c", ("start `"`" `"{0}`"" -f $Url) -WindowStyle Hidden | Out-Null } }
)

foreach ($method in $methods) {
  try {
    & $method.Run
    Write-OpenLog ("Browser launch requested successfully via {0}." -f $method.Name)
    exit 0
  } catch {
    Write-OpenLog ("{0} failed: {1}" -f $method.Name, $_.Exception.Message)
  }
}

Write-OpenLog "All browser launch methods failed."
exit 2
