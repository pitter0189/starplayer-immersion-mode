import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

function fail(message, details = []) {
  console.error('\n[STAR PLAYER 시작 점검 실패]');
  console.error(message);
  for (const detail of details) console.error(`- ${detail}`);
  console.error('');
  process.exit(1);
}

const [major] = process.versions.node.split('.').map(Number);
if (major < 20) {
  fail(
    `현재 Node.js ${process.versions.node}에서는 이 버전을 실행할 수 없습니다.`,
    [
      'Node.js 20 이상을 설치해 주세요.',
      '설치 후 새 터미널에서 `node -v`로 버전을 확인하세요.'
    ]
  );
}

const requiredFiles = [
  'data/source/operating_rules.md',
  'public/index.html',
  'public/app.js',
  'public/styles.css',
  'package.json',
  'internal/save-reader/manifest.json',
  process.platform === 'win32' ? 'internal/save-reader/reader.exe' : 'internal/save-reader/reader_linux'
];

const missing = requiredFiles.filter((rel) => !fs.existsSync(path.join(root, rel)));
if (missing.length) {
  fail('프로젝트 필수 파일이 누락되었습니다.', missing);
}

try {
  const dbDir = path.join(root, 'data', 'db');
  fs.mkdirSync(dbDir, { recursive: true });
  const probe = path.join(dbDir, '.write-test');
  fs.writeFileSync(probe, 'ok', 'utf8');
  fs.unlinkSync(probe);
} catch (error) {
  fail('저장 폴더에 파일을 쓸 수 없습니다.', [error.message]);
}

console.log(`[preflight] Node ${process.versions.node} / project files / JSON storage OK`);
