import assert from 'node:assert/strict';
import {
  offlineParseGameInput, inningsTextToOuts, outsToInnings, judgePerformance, judgeAttention,
  chooseOutputPlan, offlineParseEventInput, judgeEventAttention, chooseEventOutputPlan,
  isLikelySpecialEventInput, isLikelyGameInput, classifyRawInputKind, sanitizeParsedGame
} from '../src/simulation.mjs';
import { buildParsedFromCompare } from '../src/save-reader.mjs';

assert.equal(inningsTextToOuts('5.2'), 17);
assert.equal(inningsTextToOuts('5.1'), 16);
assert.equal(outsToInnings(17), '5.2');

const raw = `2026년 04월 22일 - 샘플 자이언츠(원정)\n\n테스트 드래곤즈 3-4 패배\n\n테스트 선수: 선발투수, 9번타자\n\n[투수 기록]\n0승 0패 5.2이닝 상대 타자 25명 6피안타 1피홈런 5탈삼진 2볼넷 0사구 3실점 3자책점\n투구 수: 94개\n\n[타자 기록]\n9번타자(선발) 2타수 1안타 0홈런 0타점 0득점 0볼넷 0사구 0도루 1삼진\n\n3회: 헛스윙 삼진\n5회: 1루타\n\n5.2이닝 3실점으로 3-3 동점 상황에서 강판\n승패 결정 없음`;

const parsed = offlineParseGameInput(raw);
assert.equal(parsed.date, '2026-04-22');
assert.equal(parsed.opponent, '샘플 자이언츠');
assert.equal(parsed.homeAway, 'away');
assert.equal(parsed.teamScore, 3);
assert.equal(parsed.opponentScore, 4);
assert.equal(parsed.pitching.outs, 17);
assert.equal(parsed.pitching.hits, 6);
assert.equal(parsed.pitching.earnedRuns, 3);
assert.equal(parsed.pitching.pitches, 94);
assert.equal(parsed.pitching.decision, 'ND');
assert.equal(parsed.batting.atBats, 2);
assert.equal(parsed.batting.hits, 1);
assert.equal(parsed.batting.strikeouts, 1);

const sasaguOnly = offlineParseGameInput(`2026년 04월 23일 - 샘플 타이거스(홈)
테스트 드래곤즈 1-0 승리
[투수 기록]
6이닝 4피안타 7탈삼진 사사구 2개 0실점 0자책점
투구 수: 90개`);
assert.equal(sasaguOnly.pitching.walks, 2);
assert.equal(sasaguOnly.pitching.hbp, 0);

const sasaguSplit = offlineParseGameInput(`2026년 04월 24일 - 샘플 타이거스(홈)
테스트 드래곤즈 1-0 승리
[투수 기록]
6이닝 4피안타 7탈삼진 사사구 2개, 그중 사구 1개 0실점 0자책점
투구 수: 90개`);
assert.equal(sasaguSplit.pitching.walks, 1);
assert.equal(sasaguSplit.pitching.hbp, 1);

assert.equal(judgePerformance(parsed), '애매');
assert.equal(judgeAttention(parsed, { previousHomeRuns: 0 }), 1);
const gamePlan = chooseOutputPlan(parsed, '애매', 1, {}, {});
assert.ok(gamePlan.communities.some(x => x.platform === 'jp_analysis'));
assert.ok(gamePlan.communities.some(x => x.platform === 'baseball_ch'));
assert.ok(gamePlan.communities.some(x => x.platform === 'team_fans'));
assert.ok(gamePlan.communities.some(x => x.platform === 'x_jp'));
assert.ok(!gamePlan.communities.some(x => ['mlbpark','dc_baseball','x_kr','theqoo','dc_idol'].includes(x.platform)));
const japanReactionMin=gamePlan.communities.reduce((n,x)=>n+(x.posts||0)*(x.commentsMin||0),0);
assert.ok(japanReactionMin>=30, `Japan-only baseline should be >=30 reactions, got ${japanReactionMin}`);
const fullCanon={reactionScopes:{japanBaseball:true,koreaBaseball:true,koreaSocial:true,koreaEntertainment:true}};
const allScopesPlan=chooseOutputPlan(parsed, '애매', 1, {}, fullCanon);
assert.ok(allScopesPlan.communities.some(x => x.platform === 'mlbpark'));
assert.ok(allScopesPlan.communities.some(x => x.platform === 'dc_baseball'));
assert.ok(allScopesPlan.communities.some(x => x.platform === 'x_kr'));
assert.ok(allScopesPlan.communities.some(x => x.platform === 'theqoo'));
assert.ok(!allScopesPlan.communities.some(x => x.platform === 'dc_idol')); // no entertainment trigger in this game

const eventRaw = `2026년 04월 09일 오전

테스트 선수와 아이돌 그룹 NOVA 멤버 하나가 쌍둥이 남매라는 사실이 처음 외부에 알려짐.
한국 연예매체 취재 이후 소속 구단도 문의에 두 사람이 쌍둥이 남매가 맞다고 공식 확인함.
가족 사생활에 관한 추가 내용은 밝히지 않음.
전날 테스트 선수는 경기에서 8이닝 1실점 11탈삼진으로 프로 첫 승을 거둔 상태.`;
const event = offlineParseEventInput(eventRaw);
assert.equal(event.date, '2026-04-09');
assert.equal(event.timeLabel, '오전');
assert.equal(event.flags.relationshipDisclosure, true);
assert.equal(event.category, 'relationship');
assert.notEqual(event.category, 'baseball');
assert.equal(isLikelySpecialEventInput(eventRaw), true);
assert.equal(isLikelySpecialEventInput(raw), false);
assert.equal(isLikelyGameInput(raw), true);
assert.equal(event.flags.koreanEntertainment, true);

const eventWithPreviousGame = `2026년 04월 09일 오전

한국 연예매체가 테스트 선수와 아이돌 그룹 NOVA 멤버 하나가 쌍둥이 남매라고 단독 보도함.
소속 구단도 공식 확인함.
전날 3-1 경기에서 테스트 선수는 8이닝 1실점 11탈삼진으로 첫 승을 거둠.`;
assert.equal(classifyRawInputKind(eventWithPreviousGame), 'event');
assert.equal(isLikelySpecialEventInput(eventWithPreviousGame), true);

const profileEvent = `2026년 05월 01일
구단 공식 프로필에서 테스트 선수의 최고구속이 157km/h로 갱신됐다고 발표됨.`;
assert.equal(classifyRawInputKind(profileEvent), 'event');
assert.notEqual(offlineParseEventInput(profileEvent).category, 'baseball');

assert.equal(event.stateChanges.relationshipPublicJapan, true);
assert.equal(event.stateChanges.relationshipPublicKorea, true);
assert.equal(judgeEventAttention(event), 3);
const eventPlan = chooseEventOutputPlan(event, 3, {}, fullCanon);
assert.ok(eventPlan.articles.some(x => x.platform === 'dispatch'));
assert.ok(eventPlan.communities.some(x => x.platform === 'dc_idol'));
assert.ok(eventPlan.communities.some(x => x.platform === 'baseball_ch'));
assert.ok(eventPlan.communities.some(x => x.platform === 'mlbpark'));
assert.ok(eventPlan.communities.some(x => x.platform === 'dc_baseball'));
assert.ok(eventPlan.communities.some(x => x.platform === 'x_kr'));
assert.ok(eventPlan.communities.some(x => x.platform === 'theqoo'));
const eventReactionMin=eventPlan.communities.reduce((n,x)=>n+(x.posts||0)*(x.commentsMin||0),0);
assert.ok(eventReactionMin>=72, `Four-scope relevant event should be rich, got ${eventReactionMin}`);

const f=(value,status='confirmed')=>({value,status});
const compare17={schema_version:1,reader_version:'1.7',player:{id:100866,name:'테스트 선수',team:'Chunichi Dragons'},capabilities:{'game.pitching.win':'confirmed','game.pitching.loss':'confirmed','game.pitching.no_decision':'confirmed','game.pitching.pitch_count':'unmapped','game.batting.doubles':'confirmed','game.batting.hbp':'pending'},game:{date:f('2026-05-13'),opponent:f('Yokohama DeNA BayStars'),home_away:f('away'),team_score:f(4),opponent_score:f(1),result:f('win')},batting:{lineup_order:f(9),position:f('P'),plate_appearances:f(2,'pending'),at_bats:f(2),hits:f(1),singles:f(1),doubles:f(0),triples:f(0),home_runs:f(0),rbi:f(0),runs:f(1),walks:f(0),hbp:f(0,'pending'),strikeouts:f(0),stolen_bases:f(0,'pending'),grounded_into_double_play:f(null,'unmapped'),errors:f(null,'unmapped')},pitching:{appeared:f(true),started:f(true,'pending'),innings_outs:f(15),batters_faced:f(19),pitch_count:f(null,'unmapped'),hits_allowed:f(4),home_runs_allowed:f(1),walks:f(0),hbp:f(0),strikeouts:f(4),runs:f(1),earned_runs:f(1),win:f(true),loss:f(false),no_decision:f(false),hold:f(null,'unmapped'),save:f(false,'pending'),blown_save:f(null,'unmapped'),quality_start:f(false),quality_start_plus:f(false,'pending')},season:{batting:{games:f(35),plate_appearances:f(48,'pending'),at_bats:f(47),hits:f(8),singles:f(3),doubles:f(1),triples:f(0),home_runs:f(4),rbi:f(7),runs:f(6),walks:f(1),hbp:f(0,'pending'),strikeouts:f(5),stolen_bases:f(0,'pending'),grounded_into_double_play:f(null,'unmapped'),errors:f(null,'unmapped')},pitching:{appearances:f(7),starts:f(7,'pending'),innings_outs:f(114),batters_faced:f(164),pitch_count:f(null,'unmapped'),hits_allowed:f(38),home_runs_allowed:f(5),walks:f(8),hbp:f(4),strikeouts:f(27),runs:f(18),earned_runs:f(16),wins:f(1),losses:f(2),holds:f(null,'unmapped'),saves:f(0,'pending'),blown_saves:f(null,'unmapped'),quality_starts:f(3),quality_start_plus:f(1,'pending')}},verification:{verified:true,new_game_log_count:1}};
const mapped17=buildParsedFromCompare(compare17).parsed;
assert.equal(mapped17.parser,'save-reader-contract-v1');
assert.equal(mapped17.opponent,'요코하마 DeNA 베이스타스');
assert.equal(mapped17.batting.lineupSpot,9);
assert.equal(mapped17.batting.position,'P');
assert.equal(mapped17.batting.doubles,0);
assert.equal(mapped17.batting.hbp,null); // pending must never auto-enter
assert.equal(mapped17.pitching.pitches,null); // unmapped must never auto-enter
assert.equal(mapped17.pitching.walks,0);
assert.equal(mapped17.pitching.hbp,0);
assert.equal(mapped17.pitching.started,null); // pending
assert.equal(mapped17.pitching.decision,'W');
assert.equal(mapped17.pitching.win,true);
const sanitized17=sanitizeParsedGame(mapped17);
assert.equal(sanitized17.batting.position,'P');
assert.equal(sanitized17.batting.lineupSpot,9);
assert.equal(sanitized17.pitching.decision,'W');
assert.equal(sanitized17.pitching.win,true);

const loss17=structuredClone(compare17);loss17.pitching.win=f(false);loss17.pitching.loss=f(true);loss17.pitching.no_decision=f(false);assert.equal(buildParsedFromCompare(loss17).parsed.pitching.decision,'L');
const nd17=structuredClone(compare17);nd17.pitching.win=f(false);nd17.pitching.loss=f(false);nd17.pitching.no_decision=f(true);assert.equal(buildParsedFromCompare(nd17).parsed.pitching.decision,'ND');
const futurePitchCount=structuredClone(compare17);futurePitchCount.pitching.pitch_count=f(88,'confirmed');futurePitchCount.capabilities['game.pitching.pitch_count']='confirmed';assert.equal(buildParsedFromCompare(futurePitchCount).parsed.pitching.pitches,88); // future unmapped→confirmed works without adapter changes

const compare18=structuredClone(compare17);compare18.reader_version='1.8';compare18.batting.position=f('RF','confirmed');compare18.capabilities['game.batting.position']='confirmed';assert.equal(buildParsedFromCompare(compare18).parsed.batting.position,'RF');

console.log('Smoke test passed: game/event boundary + sasagu + reaction-scope platform plan/density + SaveReader Contract schema v1 confirmed-only mapping + W/L/ND + v1.8 position mapping.');
