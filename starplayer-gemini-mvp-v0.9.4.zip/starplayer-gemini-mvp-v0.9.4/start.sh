#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created blank .env. API/model settings can be entered in the first-run wizard."
fi
if [ ! -d node_modules ]; then
  npm install
fi
npm run dev
