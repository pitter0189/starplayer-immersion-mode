import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const dbDir = path.join(root, 'data', 'db');
fs.mkdirSync(dbDir, { recursive: true });
const dbPath = path.join(dbDir, 'starplayer.json');

function emptyStore() {
  return {
    version: 10,
    activePlayerId: null,
    nextPlayerId: 1,
    nextGameId: 1,
    nextEventId: 1,
    nextCharacterId: 1,
    nextMessageId: 1,
    nextInterviewId: 1,
    nextScheduleId: 1,
    players: {}, games: [], events: [], battingLines: {}, pitchingLines: {},
    generatedOutputs: {}, eventOutputs: {}, communityMemory: {}, eventMemory: {},
    characters: {}, messages: [], interviews: {}, schedules: [], readerSeasonStats: {}
  };
}

function clone(v) { return v == null ? v : JSON.parse(JSON.stringify(v)); }
function nowIso() { return new Date().toISOString(); }
function nullableNumber(v) { return Number.isFinite(Number(v)) && v !== '' && v != null ? Number(v) : null; }
function arr(v) { return Array.isArray(v) ? v : []; }
function ymdToEpoch(date) { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || ''))) return null; const t = Date.parse(`${date}T00:00:00Z`); return Number.isFinite(t) ? t : null; }
function dayDiff(a, b) { const aa=ymdToEpoch(a), bb=ymdToEpoch(b); return aa==null||bb==null?null:Math.floor((bb-aa)/86400000); }

export function timeLabelToMinutes(label) {
  const s = String(label || '').trim();
  if (!s || s === '시간 미지정') return null;
  const exact = s.match(/(?:오전|오후)?\s*(\d{1,2})\s*[:시]\s*(\d{1,2})?/);
  if (exact) {
    let h = Number(exact[1]), m = Number(exact[2] || 0);
    if (s.includes('오후') && h < 12) h += 12;
    if (s.includes('오전') && h === 12) h = 0;
    if (h >= 0 && h <= 23 && m >= 0 && m <= 59) return h * 60 + m;
  }
  if (/이른\s*오전/.test(s)) return 7 * 60;
  if (/오전/.test(s)) return 9 * 60;
  if (/낮|정오/.test(s)) return 12 * 60;
  if (/오후/.test(s)) return 15 * 60;
  if (/저녁/.test(s)) return 19 * 60;
  if (/밤/.test(s)) return 22 * 60;
  return null;
}
function normalizeTimeMinutes(v, label) { const n=nullableNumber(v); return n!=null&&n>=0&&n<1440?Math.round(n):timeLabelToMinutes(label); }
function sortTime(v) { return Number.isFinite(Number(v)) ? Number(v) : 720; }
function timeDisplay(label, minutes) {
  if (label) return String(label);
  if (minutes == null) return '시간 미지정';
  const h=Math.floor(minutes/60), m=minutes%60;
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
}

function inferMigratedEventCategory(event = {}) {
  const parsed = event.parsed || {}; const flags = parsed.flags || {};
  const text = [event.summary, parsed.summary, ...(parsed.confirmedFacts || [])].filter(Boolean).join(' ');
  if (flags.relationshipDisclosure || /(?:쌍둥이|남매|누나|동생).*(?:공개|보도|확인|알려|밝혀)/s.test(text)) return 'relationship';
  if (flags.koreanEntertainment || flags.idolConnection || /걸그룹|아이돌|연예|디스패치/.test(text)) return 'entertainment';
  if (/부상|재활|수술|회복|복귀/.test(text)) return 'injury';
  if (/계약|이적|트레이드|등번호|보직|등록|말소/.test(text)) return 'career';
  if (/SNS|인스타|트위터|\bX\b/.test(text)) return 'social';
  return 'other';
}

export function inferEventLifecycle(parsed = {}) {
  const text=[parsed.summary,...arr(parsed.confirmedFacts)].filter(Boolean).join(' ');
  const category=parsed.category || 'other';
  let heatDays = 3;
  let persistence = 'temporary';
  if (parsed.flags?.relationshipDisclosure) { heatDays=7; persistence='permanent_fact'; }
  else if (category === 'entertainment') heatDays=4;
  else if (category === 'social') heatDays=2;
  else if (category === 'career') { heatDays=5; if (/등번호|보직|계약|이적|트레이드|등록|말소/.test(text)) persistence='permanent_fact'; }
  else if (category === 'injury') { heatDays=14; persistence=/복귀|완치|회복 완료/.test(text)?'temporary':'until_resolved'; }
  const persistentFacts = persistence === 'permanent_fact' ? arr(parsed.confirmedFacts).slice(0,8) : [];
  return { persistence, heatDays, persistentFacts };
}

function migrateEventRecord(event) {
  const next = clone(event);
  if (next.category === 'baseball' || next.parsed?.category === 'baseball') {
    const category = inferMigratedEventCategory(next); next.category = category; if (next.parsed) next.parsed.category = category;
  }
  next.world_time_minutes = normalizeTimeMinutes(next.world_time_minutes, next.time_label || next.parsed?.timeLabel);
  next.time_label = next.time_label || next.parsed?.timeLabel || null;
  next.lifecycle = next.lifecycle || inferEventLifecycle(next.parsed || next);
  return next;
}
function migrateGameRecord(game) {
  const next=clone(game);
  next.time_label = next.time_label || next.parsed?.timeLabel || null;
  next.world_time_minutes = normalizeTimeMinutes(next.world_time_minutes, next.time_label);
  if (next.parsed) { next.parsed.timeLabel = next.parsed.timeLabel || next.time_label || null; next.parsed.worldTimeMinutes = normalizeTimeMinutes(next.parsed.worldTimeMinutes, next.parsed.timeLabel); }
  next.interview_required = Boolean(next.interview_required || next.parsed?.specialTriggers?.includes('hero_interview'));
  next.interview_questions = Math.max(2,Math.min(3,Number(next.interview_questions)||3));
  return next;
}

function migrate(raw) {
  const base = emptyStore(); const next = { ...base, ...(raw || {}) }; next.version = 10;
  next.players = raw?.players || {}; next.games = arr(raw?.games).map(migrateGameRecord); next.events = arr(raw?.events).map(migrateEventRecord);
  next.battingLines = raw?.battingLines || {}; next.pitchingLines = raw?.pitchingLines || {}; next.generatedOutputs = raw?.generatedOutputs || {}; next.eventOutputs = raw?.eventOutputs || {};
  next.communityMemory = raw?.communityMemory || {}; next.eventMemory = raw?.eventMemory || {}; next.characters = raw?.characters || {}; next.messages = arr(raw?.messages); next.interviews = raw?.interviews || {}; next.schedules = arr(raw?.schedules); next.readerSeasonStats = raw?.readerSeasonStats || {};
  for (const p of Object.values(next.players)) { if(!p.canon?.reactionScopes)p.canon={...(p.canon||{}),reactionScopes:{japanBaseball:true,koreaBaseball:true,koreaSocial:true,koreaEntertainment:true}}; p.dynamic = {...defaultDynamic(p.canon||{}), ...(p.dynamic||{})}; const ys=arr(p.dynamic.seasons).map(Number).filter(y=>Number.isInteger(y)&&y>=2026); if(!ys.includes(2026))ys.push(2026); p.dynamic.seasons=[...new Set(ys)].sort((a,b)=>a-b); if(!p.dynamic.seasons.includes(Number(p.dynamic.season)))p.dynamic.season=2026; p.sourceDocuments=arr(p.sourceDocuments); }
  if (!next.activePlayerId) next.activePlayerId = Object.keys(next.players)[0] || null;
  next.nextPlayerId = Number(raw?.nextPlayerId || Math.max(0, ...Object.keys(next.players).map(x => Number(String(x).replace(/\D/g,'')) || 0)) + 1 || 1);
  next.nextGameId = Number(raw?.nextGameId || next.games.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1);
  next.nextEventId = Number(raw?.nextEventId || next.events.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1);
  next.nextCharacterId = Number(raw?.nextCharacterId || Math.max(0, ...Object.keys(next.characters).map(x => Number(String(x).replace(/\D/g,'')) || 0)) + 1 || 1);
  next.nextMessageId = Number(raw?.nextMessageId || (next.messages.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1));
  next.nextInterviewId = Number(raw?.nextInterviewId || Math.max(0, ...Object.keys(next.interviews).map(Number)) + 1 || 1);
  next.nextScheduleId = Number(raw?.nextScheduleId || next.schedules.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1);
  return next;
}
function loadStore() {
  try { if (!fs.existsSync(dbPath)) return emptyStore(); const text=fs.readFileSync(dbPath,'utf8').trim(); if(!text||text==='{}')return emptyStore(); return migrate(JSON.parse(text)); }
  catch(error){const broken=`${dbPath}.broken-${Date.now()}`;if(fs.existsSync(dbPath))fs.copyFileSync(dbPath,broken);throw new Error(`저장 데이터 파일을 읽지 못했습니다. 원본은 ${path.basename(broken)} 로 백업했습니다: ${error.message}`);}
}
let store=loadStore();
function persist(){const tmp=`${dbPath}.tmp`;fs.writeFileSync(tmp,JSON.stringify(store,null,2),'utf8');fs.renameSync(tmp,dbPath);}

function normalizeReactionScopes(value = null) {
  const v=value&&typeof value==='object'?value:{};
  return { japanBaseball:v.japanBaseball!==false, koreaBaseball:Boolean(v.koreaBaseball), koreaSocial:Boolean(v.koreaSocial), koreaEntertainment:Boolean(v.koreaEntertainment) };
}
function normalizeCanon(input = {}, id = null) {
  const positions=arr(input.positions).map(x=>String(x).trim()).filter(Boolean);
  const aiKeywords=arr(input.aiKeywords).map(x=>String(x).trim()).filter(Boolean);
  const reactionScopes=normalizeReactionScopes(input.reactionScopes);
  const pitchingRoles=arr(input.pitchingRoles).map(x=>String(x).trim()).filter(x=>['선발','중간계투','셋업맨','마무리'].includes(x));
  const fieldingPositions=arr(input.fieldingPositions).map(x=>String(x).trim()).filter(x=>['포수','1루수','2루수','3루수','유격수','좌익수','중견수','우익수','지명타자'].includes(x));
  return { id:id||input.id||null,name:String(input.name||'').trim(),team:String(input.team||'').trim(),photoDataUrl:String(input.photoDataUrl||'').startsWith('data:image/')?String(input.photoDataUrl):null,number:nullableNumber(input.number),positions,mainPosition:String(input.mainPosition||'').trim()||null,pitchingRoles,fieldingPositions,pitcherType:String(input.pitcherType||'').trim()||null,hitterType:String(input.hitterType||'').trim()||null,playerType:String(input.playerType||'').trim()||null,
    throws:String(input.throws||'').trim()||null,bats:String(input.bats||'').trim()||null,nationality:String(input.nationality||'').trim()||null,heightCm:nullableNumber(input.heightCm),weightKg:nullableNumber(input.weightKg),maxFastballKmh:nullableNumber(input.maxFastballKmh),
    draft:String(input.draft||'').trim()||null,rookieYear:nullableNumber(input.rookieYear),school:String(input.school||'').trim()||null,university:String(input.university||'').trim()||null,personality:String(input.personality||'').trim()||null,
    speechStyle:String(input.speechStyle||'').trim()||null,playStyle:String(input.playStyle||'').trim()||null,background:String(input.background||'').trim()||null,publicFacts:String(input.publicFacts||'').trim()||null,privateFacts:String(input.privateFacts||'').trim()||null,
    writingGuardrails:String(input.writingGuardrails||'').trim()||null,hardRules:String(input.hardRules||'').trim()||null,softGuidance:String(input.softGuidance||'').trim()||null,behaviorStyle:String(input.behaviorStyle||'').trim()||null,interviewStyle:String(input.interviewStyle||'').trim()||null,lineStyle:String(input.lineStyle||'').trim()||null,relationshipGuidance:String(input.relationshipGuidance||'').trim()||null,aiKeywords,reactionScopes,photoDataUrl:String(input.photoDataUrl||'').startsWith('data:image/')?String(input.photoDataUrl):(input.photoDataUrl||null),relationshipState:input.relationshipState||{publicJapan:false,publicKorea:false,publicSince:null} };
}

function validateCanon(canon){if(!canon.name||!canon.team||!canon.positions?.length)throw new Error('선수 이름, 소속팀, 포지션은 필수입니다.');if(canon.photoDataUrl&&canon.photoDataUrl.length>7_000_000)throw new Error('프로필 사진이 너무 큽니다. 5MB 이하 이미지를 사용해 주세요.');}
function defaultDynamic(canon){const roleMap={선발:'선발투수',중간계투:'중간계투',셋업맨:'셋업맨',마무리:'마무리투수'};const pitchingRole=roleMap[arr(canon?.pitchingRoles)[0]]||'미지정';return{season:2026,seasons:[2026],roster:'1군',pitchingRole,battingUsage:'미지정',publicAwarenessJapan:'형성 전',publicAwarenessKorea:'형성 전',relationshipState:clone(canon.relationshipState),currentNarratives:[],currentMemes:[]};}

export function hasActivePlayer(){return Boolean(store.activePlayerId&&store.players[store.activePlayerId]);}
export function getActivePlayerId(){return hasActivePlayer()?store.activePlayerId:null;}
export function createPlayer(input={}){const id=`player-${store.nextPlayerId++}`;const canon=normalizeCanon(input,id);validateCanon(canon);const ts=nowIso();store.players[id]={id,name:canon.name,team:canon.team,canon,dynamic:defaultDynamic(canon),sourceDocuments:arr(input.sourceDocuments).map(x=>({name:String(x?.name||'설정 문서'),content:String(x?.content||'')})).filter(x=>x.content.trim()),created_at:ts,updated_at:ts};store.activePlayerId=id;persist();return clone(store.players[id]);}
export function initDb(player){if(!hasActivePlayer()&&player?.name)return createPlayer(player);return getPlayer(store.activePlayerId);}
export function getPlayer(playerId=store.activePlayerId){const row=store.players[playerId];return row?clone(row):null;}
export function updatePlayerCanon(playerId,patch={}){const player=store.players[playerId];if(!player)throw new Error('Player not found');const merged={...player.canon,...patch};if(Object.prototype.hasOwnProperty.call(patch,'positions'))merged.positions=arr(patch.positions);if(Object.prototype.hasOwnProperty.call(patch,'aiKeywords'))merged.aiKeywords=arr(patch.aiKeywords);const canon=normalizeCanon(merged,playerId);validateCanon(canon);player.canon=canon;player.name=canon.name;player.team=canon.team;player.updated_at=nowIso();persist();return clone(canon);}
export function updatePlayerDynamic(playerId,updater){const p=store.players[playerId];if(!p)throw new Error('Player not found');p.dynamic=clone(updater(clone(p.dynamic)));p.updated_at=nowIso();persist();return clone(p.dynamic);}

function eventSortAsc(a,b){return String(a.date||'').localeCompare(String(b.date||''))||sortTime(a.world_time_minutes)-sortTime(b.world_time_minutes)||Number(a.id)-Number(b.id);}
function rebuildEventDerivedState(playerId){const player=store.players[playerId];if(!player)return;const old=player.dynamic||{};const dynamic={...defaultDynamic(player.canon),...old};dynamic.relationshipState=clone(player.canon.relationshipState||{publicJapan:false,publicKorea:false,publicSince:null});dynamic.publicAwarenessJapan='형성 전';dynamic.publicAwarenessKorea='형성 전';
  for(const event of store.events.filter(e=>e.player_id===playerId).slice().sort(eventSortAsc)){const c=event.parsed?.stateChanges||{};if(c.relationshipPublicJapan===true){dynamic.relationshipState.publicJapan=true;dynamic.relationshipState.publicSince ||= event.date||null;}if(c.relationshipPublicKorea===true){dynamic.relationshipState.publicKorea=true;dynamic.relationshipState.publicSince ||= event.date||null;}if(c.publicAwarenessJapan)dynamic.publicAwarenessJapan=String(c.publicAwarenessJapan);if(c.publicAwarenessKorea)dynamic.publicAwarenessKorea=String(c.publicAwarenessKorea);if(c.pitchingRole)dynamic.pitchingRole=String(c.pitchingRole);}
  player.dynamic=dynamic;player.updated_at=nowIso();}
export function applyEventStateChanges(playerId,parsedEvent){const changes=parsedEvent?.stateChanges||{};return updatePlayerDynamic(playerId,d=>{d.relationshipState||={publicJapan:false,publicKorea:false,publicSince:null};if(changes.relationshipPublicJapan===true){d.relationshipState.publicJapan=true;d.relationshipState.publicSince=parsedEvent.date||d.relationshipState.publicSince||null;}if(changes.relationshipPublicKorea===true){d.relationshipState.publicKorea=true;d.relationshipState.publicSince=parsedEvent.date||d.relationshipState.publicSince||null;}if(changes.publicAwarenessJapan)d.publicAwarenessJapan=String(changes.publicAwarenessJapan);if(changes.publicAwarenessKorea)d.publicAwarenessKorea=String(changes.publicAwarenessKorea);if(changes.pitchingRole)d.pitchingRole=String(changes.pitchingRole);return d;});}

export function findMatchingGame(playerId,parsed){if(!parsed.date||!parsed.opponent)return null;const h=parsed.homeAway||'unknown';return clone(store.games.filter(g=>g.player_id===playerId&&g.date===parsed.date&&g.opponent===parsed.opponent&&g.home_away===h).sort((a,b)=>b.id-a.id)[0]||null);}
export function saveGame(playerId,rawInput,parsed,performanceGrade,attentionLevel,{interviewRequired=false,interviewQuestions=3}={}){const match=findMatchingGame(playerId,parsed),mode=match?'correction':'new',ts=nowIso();let gameId;const common={date:parsed.date??null,time_label:parsed.timeLabel??null,world_time_minutes:normalizeTimeMinutes(parsed.worldTimeMinutes,parsed.timeLabel),opponent:parsed.opponent??null,home_away:parsed.homeAway??'unknown',team_score:nullableNumber(parsed.teamScore),opponent_score:nullableNumber(parsed.opponentScore),result:parsed.result??'unknown',raw_input:rawInput,parsed:clone(parsed),performance_grade:performanceGrade,attention_level:attentionLevel,interview_required:Boolean(interviewRequired),interview_questions:Math.max(2,Math.min(3,Number(interviewQuestions)||3)),updated_at:ts};
  if(match){gameId=match.id;const i=store.games.findIndex(g=>g.id===gameId);store.games[i]={...store.games[i],...common,mode:'correction'};delete store.battingLines[gameId];delete store.pitchingLines[gameId];delete store.generatedOutputs[gameId];delete store.communityMemory[gameId];for(const k of Object.keys(store.interviews))if(store.interviews[k].game_id===gameId)delete store.interviews[k];}
  else{gameId=store.nextGameId++;store.games.push({id:gameId,player_id:playerId,...common,mode:'new',created_at:ts});}
  if(parsed.batting){const b=parsed.batting;store.battingLines[gameId]={game_id:gameId,lineup_spot:nullableNumber(b.lineupSpot),plate_appearances:nullableNumber(b.plateAppearances),at_bats:nullableNumber(b.atBats),hits:nullableNumber(b.hits),singles:nullableNumber(b.singles),doubles:nullableNumber(b.doubles),triples:nullableNumber(b.triples),home_runs:nullableNumber(b.homeRuns),rbi:nullableNumber(b.rbi),runs:nullableNumber(b.runs),walks:nullableNumber(b.walks),hbp:nullableNumber(b.hbp),stolen_bases:nullableNumber(b.stolenBases),grounded_into_double_play:nullableNumber(b.groundedIntoDoublePlay),errors:nullableNumber(b.errors),strikeouts:nullableNumber(b.strikeouts),sac_bunt_candidate:nullableNumber(b.sacBuntCandidate),sac_fly_candidate:nullableNumber(b.sacFlyCandidate)};}
  if(parsed.pitching){const p=parsed.pitching;store.pitchingLines[gameId]={game_id:gameId,outs:nullableNumber(p.outs),batters_faced:nullableNumber(p.battersFaced),hits:nullableNumber(p.hits),home_runs:nullableNumber(p.homeRuns),strikeouts:nullableNumber(p.strikeouts),walks:nullableNumber(p.walks),hbp:nullableNumber(p.hbp),runs:nullableNumber(p.runs),earned_runs:nullableNumber(p.earnedRuns),pitches:nullableNumber(p.pitches),decision:p.decision??'none',win:p.win==null?null:Boolean(p.win),loss:p.loss==null?null:Boolean(p.loss),no_decision:p.noDecision==null?null:Boolean(p.noDecision),hold:p.hold==null?null:Boolean(p.hold),save:p.save==null?null:Boolean(p.save),blown_save:p.blownSave==null?null:Boolean(p.blownSave),started:p.started==null?null:Boolean(p.started),quality_start:p.qualityStart==null?null:Boolean(p.qualityStart),high_quality_start:p.highQualityStart==null?null:Boolean(p.highQualityStart)};}
  persist();return{gameId,mode};}
export function saveGeneratedOutput(gameId,plan,bundle){store.generatedOutputs[gameId]={game_id:gameId,plan:clone(plan),bundle:clone(bundle),created_at:store.generatedOutputs[gameId]?.created_at||nowIso(),updated_at:nowIso()};persist();}
export function saveCommunityMemory(gameId,summary){store.communityMemory[gameId]={game_id:gameId,summary:clone(summary),created_at:store.communityMemory[gameId]?.created_at||nowIso(),updated_at:nowIso()};persist();}
export function saveEvent(playerId,rawInput,parsed,attentionLevel,plan){const id=store.nextEventId++,ts=nowIso();const lifecycle=inferEventLifecycle(parsed);store.events.push({id,player_id:playerId,date:parsed.date??null,time_label:parsed.timeLabel??null,world_time_minutes:normalizeTimeMinutes(parsed.worldTimeMinutes,parsed.timeLabel),category:['relationship','entertainment','injury','career','social','other'].includes(parsed.category)?parsed.category:'other',summary:parsed.summary||'이벤트',raw_input:rawInput,parsed:clone(parsed),lifecycle,attention_level:attentionLevel,plan:clone(plan),created_at:ts,updated_at:ts});persist();return{eventId:id,mode:'new'};}
export function saveEventGeneratedOutput(id,plan,bundle){store.eventOutputs[id]={event_id:id,plan:clone(plan),bundle:clone(bundle),created_at:store.eventOutputs[id]?.created_at||nowIso(),updated_at:nowIso()};persist();}
export function saveEventMemory(id,summary){store.eventMemory[id]={event_id:id,summary:clone(summary),created_at:store.eventMemory[id]?.created_at||nowIso(),updated_at:nowIso()};persist();}
export function deleteGame(id){id=Number(id);const i=store.games.findIndex(g=>g.id===id);if(i<0)return false;store.games.splice(i,1);delete store.battingLines[id];delete store.pitchingLines[id];delete store.generatedOutputs[id];delete store.communityMemory[id];for(const k of Object.keys(store.interviews))if(store.interviews[k].game_id===id)delete store.interviews[k];persist();return true;}
export function deleteEvent(id){id=Number(id);const i=store.events.findIndex(e=>e.id===id);if(i<0)return false;const pid=store.events[i].player_id;store.events.splice(i,1);delete store.eventOutputs[id];delete store.eventMemory[id];rebuildEventDerivedState(pid);persist();return true;}

function sum(rows,key){return rows.reduce((a,r)=>a+(Number(r?.[key])||0),0);}
export function setReaderSeasonStats(playerId,season,stats,asOfDate=null){const y=Number(season);if(!playerId||!Number.isInteger(y)||!stats)return null;const key=`${playerId}:${y}`,prev=store.readerSeasonStats[key];if(prev?.asOfDate&&asOfDate&&String(asOfDate)<String(prev.asOfDate))return clone(prev);store.readerSeasonStats[key]={player_id:playerId,season:y,stats:clone(stats),asOfDate:asOfDate||prev?.asOfDate||null,updated_at:nowIso()};persist();return clone(store.readerSeasonStats[key]);}
export function getReaderSeasonStats(playerId,season){return clone(store.readerSeasonStats[`${playerId}:${Number(season)}`]||null);}
export function getSeasonStats(playerId,seasonOverride=null){
  const season=Number(seasonOverride??store.players[playerId]?.dynamic?.season)||null;
  const seasonGames=store.games.filter(g=>g.player_id===playerId&&(!season||String(g.date||'').startsWith(`${season}-`)));
  const ids=new Set(seasonGames.map(g=>g.id));
  const br=Object.values(store.battingLines).filter(r=>ids.has(Number(r.game_id)));
  const pr=Object.values(store.pitchingLines).filter(r=>ids.has(Number(r.game_id)));
  const ab=sum(br,'at_bats'),h=sum(br,'hits'),d2=sum(br,'doubles'),d3=sum(br,'triples'),hr=sum(br,'home_runs'),bbBat=sum(br,'walks'),hbpBat=sum(br,'hbp'),outs=sum(pr,'outs'),er=sum(pr,'earned_runs'),ph=sum(pr,'hits'),bb=sum(pr,'walks');
  const dm={};for(const r of pr)dm[r.decision]=(dm[r.decision]||0)+1;
  const countFlag=(key,fallbackDecision=null)=>pr.reduce((n,r)=>n+(r[key]===true?1:r[key]===false?0:(fallbackDecision&&r.decision===fallbackDecision?1:0)),0);
  const tb=Math.max(0,h-d2-d3-hr)+2*d2+3*d3+4*hr;
  const pa=br.reduce((n,r)=>n+(r.plate_appearances!=null?(Number(r.plate_appearances)||0):(Number(r.at_bats)||0)+(Number(r.walks)||0)+(Number(r.hbp)||0)+(Number(r.sac_bunt_candidate)||0)+(Number(r.sac_fly_candidate)||0)),0);
  const obpDen=ab+bbBat+hbpBat+sum(br,'sac_fly_candidate');
  const obp=obpDen>0?(h+bbBat+hbpBat)/obpDen:null,slg=ab>0?tb/ab:null;
  const starts=pr.reduce((n,r)=>n+(r.started===true?1:r.started===false?0:(/선발투수/.test(store.games.find(g=>g.id===Number(r.game_id))?.raw_input||'')?1:0)),0);
  const qs=pr.reduce((n,r)=>n+(r.quality_start===true?1:r.quality_start===false?0:((r.outs||0)>=18&&(r.earned_runs||0)<=3?1:0)),0);
  const qsPlus=pr.reduce((n,r)=>n+(r.high_quality_start===true?1:r.high_quality_start===false?0:((r.outs||0)>=21&&(r.earned_runs||0)<=3?1:0)),0);
  const local={batting:{games:br.length,plateAppearances:pa,atBats:ab,hits:h,singles:Math.max(0,h-d2-d3-hr),doubles:d2,triples:d3,average:ab>0?h/ab:null,onBasePercentage:obp,slugging:slg,ops:obp!=null&&slg!=null?obp+slg:null,homeRuns:hr,rbi:sum(br,'rbi'),runs:sum(br,'runs'),walks:bbBat,hbp:hbpBat,stolenBases:sum(br,'stolen_bases'),groundedIntoDoublePlay:sum(br,'grounded_into_double_play'),errors:sum(br,'errors'),strikeouts:sum(br,'strikeouts')},pitching:{games:pr.length,starts,outs,battersFaced:sum(pr,'batters_faced'),era:outs>0?(er*27)/outs:null,whip:outs>0?((ph+bb)*3)/outs:null,hits:ph,homeRuns:sum(pr,'home_runs'),strikeouts:sum(pr,'strikeouts'),walks:bb,hbp:sum(pr,'hbp'),runs:sum(pr,'runs'),earnedRuns:er,pitches:sum(pr,'pitches'),wins:countFlag('win','W'),losses:countFlag('loss','L'),noDecisions:countFlag('no_decision','ND'),saves:countFlag('save','S'),holds:countFlag('hold','H'),blownSaves:countFlag('blown_save','BS'),qs,qsPlus,k9:outs>0?sum(pr,'strikeouts')*27/outs:null,bb9:outs>0?bb*27/outs:null,kbb:bb>0?sum(pr,'strikeouts')/bb:null}};
  const reader=store.readerSeasonStats[`${playerId}:${season}`]?.stats;if(reader?.batting){const r=reader.batting;for(const k of ['games','plateAppearances','atBats','hits','singles','doubles','triples','average','slugging','homeRuns','rbi','runs','walks','hbp','stolenBases','groundedIntoDoublePlay','errors','strikeouts'])if(r[k]!=null)local.batting[k]=r[k];if(local.batting.onBasePercentage!=null&&local.batting.slugging!=null)local.batting.ops=local.batting.onBasePercentage+local.batting.slugging;}if(reader?.pitching){const r=reader.pitching;for(const k of ['games','starts','outs','battersFaced','pitches','era','whip','hits','homeRuns','strikeouts','walks','hbp','runs','earnedRuns','wins','losses','holds','saves','blownSaves','qs','qsPlus','k9','bb9','kbb'])if(r[k]!=null)local.pitching[k]=r[k];}
  return local;
}

function gameSortDesc(a,b){return String(b.date||'').localeCompare(String(a.date||''))||sortTime(b.world_time_minutes)-sortTime(a.world_time_minutes)||Number(b.id)-Number(a.id);}
function eventSortDesc(a,b){return String(b.date||'').localeCompare(String(a.date||''))||sortTime(b.world_time_minutes)-sortTime(a.world_time_minutes)||Number(b.id)-Number(a.id);}
export function listGames(playerId,limit=200){return store.games.filter(g=>g.player_id===playerId).slice().sort(gameSortDesc).slice(0,limit).map(g=>clone({...g,bundle:store.generatedOutputs[g.id]?.bundle??null}));}
export function listEvents(playerId,limit=200){return store.events.filter(e=>e.player_id===playerId).slice().sort(eventSortDesc).slice(0,limit).map(e=>clone({...e,bundle:store.eventOutputs[e.id]?.bundle??null}));}
export function listTimeline(playerId,limit=300){const games=listGames(playerId,limit).map(g=>({type:'game',id:g.id,date:g.date,timeLabel:timeDisplay(g.time_label,g.world_time_minutes),worldTimeMinutes:g.world_time_minutes,label:`vs ${g.opponent||'상대 미제공'}`,sublabel:g.team_score!=null?`${g.team_score}-${g.opponent_score} · ${g.result}`:g.result,createdAt:g.created_at||g.updated_at}));const events=listEvents(playerId,limit).map(e=>({type:'event',id:e.id,date:e.date,timeLabel:timeDisplay(e.time_label,e.world_time_minutes),worldTimeMinutes:e.world_time_minutes,label:e.summary||'이벤트',sublabel:'EVENT',createdAt:e.created_at}));const schedules=store.schedules.filter(x=>x.player_id===playerId).map(x=>({type:x.kind,id:x.id,date:x.date,timeLabel:timeDisplay(x.time_label,x.world_time_minutes),worldTimeMinutes:x.world_time_minutes,label:x.kind==='offday'?'휴일':`미출전${x.opponent?` · vs ${x.opponent}`:''}`,sublabel:x.reason||'',createdAt:x.created_at}));return[...games,...events,...schedules].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||sortTime(b.worldTimeMinutes)-sortTime(a.worldTimeMinutes)||String(b.createdAt||'').localeCompare(String(a.createdAt||''))).slice(0,limit);}
export function listTimelineDays(playerId,limit=300){const flat=listTimeline(playerId,limit),map=new Map();for(const item of flat){const date=item.date||'날짜 미제공';if(!map.has(date))map.set(date,{date,entries:[]});map.get(date).entries.push(item);}return[...map.values()].map(day=>({...day,entries:day.entries.sort((a,b)=>sortTime(a.worldTimeMinutes)-sortTime(b.worldTimeMinutes)||String(a.createdAt||'').localeCompare(String(b.createdAt||'')))})).sort((a,b)=>String(b.date).localeCompare(String(a.date)));}
export function getGame(id){const g=store.games.find(x=>x.id===Number(id));if(!g)return null;return clone({...g,batting:store.battingLines[g.id]||null,pitching:store.pitchingLines[g.id]||null,plan:store.generatedOutputs[g.id]?.plan||null,bundle:store.generatedOutputs[g.id]?.bundle||null});}
export function getEvent(id){const e=store.events.find(x=>x.id===Number(id));if(!e)return null;return clone({...e,plan:store.eventOutputs[e.id]?.plan||e.plan||null,bundle:store.eventOutputs[e.id]?.bundle||null});}
export function getDayEntries(playerId,date){const entries=[];for(const g of store.games.filter(x=>x.player_id===playerId&&x.date===date))entries.push({type:'game',worldTimeMinutes:g.world_time_minutes,id:g.id,data:getGame(g.id)});for(const e of store.events.filter(x=>x.player_id===playerId&&x.date===date))entries.push({type:'event',worldTimeMinutes:e.world_time_minutes,id:e.id,data:getEvent(e.id)});for(const x of store.schedules.filter(x=>x.player_id===playerId&&x.date===date))entries.push({type:x.kind,worldTimeMinutes:x.world_time_minutes,id:x.id,data:clone(x)});return entries.sort((a,b)=>sortTime(a.worldTimeMinutes)-sortTime(b.worldTimeMinutes)||a.id-b.id).map(clone);}
export function getRecentContentMemory(playerId,limit=3,exclude=null){const rows=[];for(const g of store.games.filter(x=>x.player_id===playerId)){if(exclude?.type==='game'&&exclude.id===g.id)continue;const m=store.communityMemory[g.id]?.summary;if(m)rows.push({type:'game',id:g.id,date:g.date,worldTimeMinutes:g.world_time_minutes,createdAt:g.updated_at||g.created_at,...clone(m)});}for(const e of store.events.filter(x=>x.player_id===playerId)){if(exclude?.type==='event'&&exclude.id===e.id)continue;const m=store.eventMemory[e.id]?.summary;if(m)rows.push({type:'event',id:e.id,date:e.date,worldTimeMinutes:e.world_time_minutes,createdAt:e.updated_at||e.created_at,...clone(m)});}return rows.sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||sortTime(b.worldTimeMinutes)-sortTime(a.worldTimeMinutes)||String(b.createdAt||'').localeCompare(String(a.createdAt||''))).slice(0,limit);}
export function countPreviousHomeRuns(playerId,excludeGameId=null){const ids=new Set(store.games.filter(g=>g.player_id===playerId&&g.id!==excludeGameId).map(g=>g.id));return Object.values(store.battingLines).filter(r=>ids.has(Number(r.game_id))).reduce((a,r)=>a+(Number(r.home_runs)||0),0);}
export function countPreviousPitchingGames(playerId,excludeGameId=null){return store.games.filter(g=>g.player_id===playerId&&g.id!==excludeGameId&&store.pitchingLines[g.id]).length;}

function latestSimulationDate(playerId){return [...store.games.filter(g=>g.player_id===playerId).map(g=>g.date),...store.events.filter(e=>e.player_id===playerId).map(e=>e.date)].filter(Boolean).sort().pop()||null;}
function eventIsBefore(e,targetDate,targetMinutes){if(!targetDate||!e.date)return false;if(e.date<targetDate)return true;if(e.date>targetDate)return false;if(targetMinutes==null)return false;if(e.world_time_minutes==null)return false;return Number(e.world_time_minutes)<Number(targetMinutes);}
function unresolvedInjury(playerId,event){if(event.lifecycle?.persistence!=='until_resolved')return false;return !store.events.some(e=>e.player_id===playerId&&e.id!==event.id&&e.date>=event.date&&e.category==='injury'&&/복귀|완치|회복 완료|재활 종료/.test(`${e.summary||''} ${(e.parsed?.confirmedFacts||[]).join(' ')}`));}
export function getTemporalEventContext(playerId,targetDate,targetMinutes,{includeSameDayOnly=false}={}){const prior=store.events.filter(e=>e.player_id===playerId&&eventIsBefore(e,targetDate,targetMinutes)).sort(eventSortAsc);const sameDay=[],activeTopics=[],persistentFacts=[];for(const e of prior){const diff=dayDiff(e.date,targetDate);if(e.date===targetDate)sameDay.push(e);const lc=e.lifecycle||inferEventLifecycle(e.parsed||e);const active=(diff!=null&&diff>=0&&diff<=Number(lc.heatDays||0))||unresolvedInjury(playerId,e);if(active&&!includeSameDayOnly)activeTopics.push(e);for(const f of arr(lc.persistentFacts))persistentFacts.push({date:e.date,fact:f,eventId:e.id});}
  const map=new Map();for(const f of persistentFacts)map.set(f.fact,f);return{sameDayPrior:sameDay.map(e=>({id:e.id,date:e.date,timeLabel:timeDisplay(e.time_label,e.world_time_minutes),summary:e.summary,confirmedFacts:e.parsed?.confirmedFacts||[],category:e.category})),activeTopics:activeTopics.slice(-8).map(e=>({id:e.id,date:e.date,timeLabel:timeDisplay(e.time_label,e.world_time_minutes),summary:e.summary,category:e.category})),persistentFacts:[...map.values()].slice(-20)};}
export function getActiveEventTopics(playerId,referenceDate=latestSimulationDate(playerId)){if(!referenceDate)return[];return store.events.filter(e=>e.player_id===playerId).filter(e=>{const d=dayDiff(e.date,referenceDate),lc=e.lifecycle||inferEventLifecycle(e.parsed||e);return(d!=null&&d>=0&&d<=Number(lc.heatDays||0))||unresolvedInjury(playerId,e);}).sort(eventSortDesc).slice(0,8).map(e=>({date:e.date,timeLabel:timeDisplay(e.time_label,e.world_time_minutes),summary:e.summary,category:e.category}));}
export function getPlayerRuntime(playerId=store.activePlayerId){const p=getPlayer(playerId);if(!p)return null;p.dynamic.currentNarratives=getActiveEventTopics(playerId).map(x=>`${x.date} ${x.timeLabel}: ${x.summary}`);return p;}

function normalizeCharacter(input={},id=null){return{id:id||input.id||null,name:String(input.name||'').trim(),displayName:String(input.displayName||input.name||'').trim(),relation:String(input.relation||'').trim(),organization:String(input.organization||'').trim(),personality:String(input.personality||'').trim(),speechStyle:String(input.speechStyle||'').trim(),behavior:String(input.behavior||'').trim(),likes:String(input.likes||'').trim(),dislikes:String(input.dislikes||'').trim(),interactionStyle:String(input.interactionStyle||'').trim(),publicFacts:String(input.publicFacts||'').trim(),privateFacts:String(input.privateFacts||'').trim(),lineStyle:String(input.lineStyle||'').trim(),notes:String(input.notes||'').trim(),keywords:arr(input.keywords).map(x=>String(x).trim()).filter(Boolean),photoDataUrl:String(input.photoDataUrl||'').startsWith('data:image/')?String(input.photoDataUrl):(input.photoDataUrl||null),messagingEnabled:input.messagingEnabled!==false};}
export function listCharacters(){return Object.values(store.characters).map(clone).sort((a,b)=>a.name.localeCompare(b.name,'ko'));}
export function getCharacter(id){return store.characters[id]?clone(store.characters[id]):null;}
export function saveCharacter(input={}){let id=input.id&&store.characters[input.id]?input.id:`char-${store.nextCharacterId++}`;const c=normalizeCharacter(input,id);if(!c.name)throw new Error('캐릭터 이름은 필수입니다.');if(c.photoDataUrl&&c.photoDataUrl.length>7_000_000)throw new Error('프로필 사진이 너무 큽니다.');c.created_at=store.characters[id]?.created_at||nowIso();c.updated_at=nowIso();store.characters[id]=c;persist();return clone(c);}
export function deleteCharacter(id){if(!store.characters[id])return false;delete store.characters[id];store.messages=store.messages.filter(m=>m.character_id!==id);persist();return true;}
export function getRelevantCharacters(text='',limit=8){const t=String(text).toLowerCase();const all=listCharacters();const scored=all.map(c=>{let s=0;if(t.includes(c.name.toLowerCase()))s+=8;if(c.displayName&&t.includes(c.displayName.toLowerCase()))s+=6;for(const k of c.keywords||[])if(k&&t.includes(k.toLowerCase()))s+=3;if(c.relation)s+=0.2;return{c,s};}).sort((a,b)=>b.s-a.s);return scored.filter(x=>x.s>0).slice(0,limit).map(x=>x.c);}
export function listConversationThreads(playerId){return listCharacters().filter(c=>c.messagingEnabled).map(c=>{const msgs=store.messages.filter(m=>m.player_id===playerId&&m.character_id===c.id);const last=msgs[msgs.length-1]||null;return{character:c,lastMessage:last?clone(last):null,unread:msgs.filter(m=>m.sender==='character'&&m.unread).length};}).sort((a,b)=>String(b.lastMessage?.created_at||'').localeCompare(String(a.lastMessage?.created_at||''))||a.character.name.localeCompare(b.character.name,'ko'));}
export function getConversation(playerId,characterId,limit=100){return store.messages.filter(m=>m.player_id===playerId&&m.character_id===characterId).slice(-limit).map(clone);}
export function addMessage(playerId,characterId,sender,body,{unread=false,meta=null}={}){if(!store.characters[characterId])throw new Error('캐릭터를 찾지 못했습니다.');const m={id:store.nextMessageId++,player_id:playerId,character_id:characterId,sender,body:String(body||'').trim(),unread:Boolean(unread),meta:clone(meta),created_at:nowIso()};if(!m.body)throw new Error('메시지가 비어 있습니다.');store.messages.push(m);persist();return clone(m);}
export function markConversationRead(playerId,characterId){for(const m of store.messages)if(m.player_id===playerId&&m.character_id===characterId&&m.sender==='character')m.unread=false;persist();}
export function unreadMessageCount(playerId){return store.messages.filter(m=>m.player_id===playerId&&m.sender==='character'&&m.unread).length;}

export function createInterview(playerId,gameId,maxQuestions=3){const game=getGame(gameId);if(!game||game.player_id!==playerId)throw new Error('인터뷰할 경기를 찾지 못했습니다.');const id=store.nextInterviewId++;store.interviews[id]={id,player_id:playerId,game_id:Number(gameId),status:'active',maxQuestions:Math.max(2,Math.min(3,Number(maxQuestions)||3)),currentQuestion:null,transcript:[],created_at:nowIso(),updated_at:nowIso()};persist();return clone(store.interviews[id]);}
export function getInterview(id){return store.interviews[id]?clone(store.interviews[id]):null;}
export function updateInterview(id,patch={}){const s=store.interviews[id];if(!s)throw new Error('인터뷰 세션을 찾지 못했습니다.');Object.assign(s,clone(patch),{updated_at:nowIso()});persist();return clone(s);}
export function listInterviewsForGame(gameId){return Object.values(store.interviews).filter(x=>x.game_id===Number(gameId)).map(clone).sort((a,b)=>b.id-a.id);}

export function resetSimulation({keepPlayer=true,keepCharacters=true}={}){const players=keepPlayer?clone(store.players):{},active=keepPlayer?store.activePlayerId:null,chars=keepCharacters?clone(store.characters):{},nextChar=keepCharacters?store.nextCharacterId:1;store=emptyStore();store.players=players;store.activePlayerId=active;store.characters=chars;store.nextCharacterId=nextChar;if(keepPlayer&&active&&store.players[active]){store.players[active].dynamic=defaultDynamic(store.players[active].canon);store.players[active].updated_at=nowIso();}persist();return true;}
export function replaceActivePlayerCanon(input={}){const id=getActivePlayerId();if(!id)return createPlayer(input);const canon=normalizeCanon({...input,id},id);validateCanon(canon);const row=store.players[id];const seasons=arr(row.dynamic?.seasons).length?arr(row.dynamic.seasons):[2026];row.canon=canon;row.name=canon.name;row.team=canon.team;row.dynamic={...defaultDynamic(canon),seasons,season:seasons.includes(Number(row.dynamic?.season))?Number(row.dynamic.season):2026};if(Array.isArray(input.sourceDocuments))row.sourceDocuments=clone(input.sourceDocuments);row.updated_at=nowIso();persist();return clone(row);}
export function clearCharacters(){store.characters={};store.nextCharacterId=1;store.messages=[];persist();return true;}

export function saveScheduleEntry(playerId,input={}){const kind=['dnp','offday'].includes(input.kind)?input.kind:'offday';const id=store.nextScheduleId++,ts=nowIso();const row={id,player_id:playerId,kind,date:String(input.date||'').trim()||null,time_label:String(input.timeLabel||'').trim()||null,world_time_minutes:normalizeTimeMinutes(input.worldTimeMinutes,input.timeLabel),opponent:String(input.opponent||'').trim()||null,home_away:String(input.homeAway||'unknown'),team_score:nullableNumber(input.teamScore),opponent_score:nullableNumber(input.opponentScore),result:String(input.result||'unknown'),reason:String(input.reason||'').trim()||null,memo:String(input.memo||'').trim()||null,created_at:ts,updated_at:ts};if(!/^\d{4}-\d{2}-\d{2}$/.test(row.date||''))throw new Error('날짜를 YYYY-MM-DD 형식으로 입력해 주세요.');store.schedules.push(row);persist();return clone(row);}
export function deleteScheduleEntry(id){const i=store.schedules.findIndex(x=>x.id===Number(id));if(i<0)return false;store.schedules.splice(i,1);persist();return true;}
export function listScheduleEntries(playerId,limit=500){return store.schedules.filter(x=>x.player_id===playerId).slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||sortTime(b.world_time_minutes)-sortTime(a.world_time_minutes)).slice(0,limit).map(clone);}


export function listSeasons(playerId=store.activePlayerId){const p=store.players[playerId];if(!p)return[];const ys=arr(p.dynamic?.seasons).map(Number).filter(y=>Number.isInteger(y)&&y>=2026);if(!ys.includes(2026))ys.push(2026);return [...new Set(ys)].sort((a,b)=>a-b);}
export function addSeason(playerId,year){const p=store.players[playerId];if(!p)throw new Error('Player not found');const y=Number(year);if(!Number.isInteger(y)||y<2026||y>2200)throw new Error('시즌 연도는 2026~2200 사이로 입력해 주세요.');const ys=listSeasons(playerId);if(!ys.includes(y))ys.push(y);p.dynamic.seasons=[...new Set(ys)].sort((a,b)=>a-b);p.dynamic.season=y;p.updated_at=nowIso();persist();return clone(p.dynamic.seasons);}
function backupStore(){const dir=path.join(root,'data','backups');fs.mkdirSync(dir,{recursive:true});const stamp=new Date().toISOString().replace(/[:.]/g,'-');const file=path.join(dir,`starplayer_backup_${stamp}.json`);fs.writeFileSync(file,JSON.stringify(store,null,2),'utf8');return path.basename(file);}
export function startFreshSimulation({canon,characters=[],sourceDocuments=[]}={}){let backup=null;if(store.activePlayerId||store.games.length||store.events.length||Object.keys(store.characters).length)backup=backupStore();store=emptyStore();const player=createPlayer({...canon,sourceDocuments});for(const c of arr(characters))saveCharacter(c);return{player,backup};}
function writeGameLines(gameId,parsed){delete store.battingLines[gameId];delete store.pitchingLines[gameId];if(parsed?.batting){const b=parsed.batting;store.battingLines[gameId]={game_id:gameId,lineup_spot:nullableNumber(b.lineupSpot),plate_appearances:nullableNumber(b.plateAppearances),at_bats:nullableNumber(b.atBats),hits:nullableNumber(b.hits),singles:nullableNumber(b.singles),doubles:nullableNumber(b.doubles),triples:nullableNumber(b.triples),home_runs:nullableNumber(b.homeRuns),rbi:nullableNumber(b.rbi),runs:nullableNumber(b.runs),walks:nullableNumber(b.walks),hbp:nullableNumber(b.hbp),stolen_bases:nullableNumber(b.stolenBases),grounded_into_double_play:nullableNumber(b.groundedIntoDoublePlay),errors:nullableNumber(b.errors),strikeouts:nullableNumber(b.strikeouts),sac_bunt_candidate:nullableNumber(b.sacBuntCandidate),sac_fly_candidate:nullableNumber(b.sacFlyCandidate)};}if(parsed?.pitching){const p=parsed.pitching;store.pitchingLines[gameId]={game_id:gameId,outs:nullableNumber(p.outs),batters_faced:nullableNumber(p.battersFaced),hits:nullableNumber(p.hits),home_runs:nullableNumber(p.homeRuns),strikeouts:nullableNumber(p.strikeouts),walks:nullableNumber(p.walks),hbp:nullableNumber(p.hbp),runs:nullableNumber(p.runs),earned_runs:nullableNumber(p.earnedRuns),pitches:nullableNumber(p.pitches),decision:p.decision??'none',win:p.win==null?null:Boolean(p.win),loss:p.loss==null?null:Boolean(p.loss),no_decision:p.noDecision==null?null:Boolean(p.noDecision),hold:p.hold==null?null:Boolean(p.hold),save:p.save==null?null:Boolean(p.save),blown_save:p.blownSave==null?null:Boolean(p.blownSave),started:p.started==null?null:Boolean(p.started),quality_start:p.qualityStart==null?null:Boolean(p.qualityStart),high_quality_start:p.highQualityStart==null?null:Boolean(p.highQualityStart)};}}
export function updateGameRecord(id,{parsed,rawInput,performanceGrade,attentionLevel,markOutputStale=true}={}){id=Number(id);const i=store.games.findIndex(g=>g.id===id);if(i<0)throw new Error('경기를 찾지 못했습니다.');const g=store.games[i],p=clone(parsed||g.parsed||{});g.date=p.date??g.date;g.time_label=p.timeLabel??g.time_label;g.world_time_minutes=normalizeTimeMinutes(p.worldTimeMinutes,p.timeLabel);g.opponent=p.opponent??g.opponent;g.home_away=p.homeAway??g.home_away;g.team_score=nullableNumber(p.teamScore);g.opponent_score=nullableNumber(p.opponentScore);g.result=p.result??g.result;g.parsed=p;if(rawInput!=null)g.raw_input=String(rawInput);if(performanceGrade!=null)g.performance_grade=performanceGrade;if(attentionLevel!=null)g.attention_level=attentionLevel;g.mode='correction';g.output_stale=Boolean(markOutputStale&&store.generatedOutputs[id]);g.updated_at=nowIso();writeGameLines(id,p);delete store.communityMemory[id];persist();return getGame(id);}
export function updateEventRecord(id,{parsed,rawInput,attentionLevel,plan,markOutputStale=true}={}){id=Number(id);const i=store.events.findIndex(e=>e.id===id);if(i<0)throw new Error('이벤트를 찾지 못했습니다.');const e=store.events[i],p=clone(parsed||e.parsed||{});e.date=p.date??e.date;e.time_label=p.timeLabel??e.time_label;e.world_time_minutes=normalizeTimeMinutes(p.worldTimeMinutes,p.timeLabel);e.category=p.category||e.category;e.summary=p.summary||e.summary;e.parsed=p;e.lifecycle=inferEventLifecycle(p);if(rawInput!=null)e.raw_input=String(rawInput);if(attentionLevel!=null)e.attention_level=attentionLevel;if(plan)e.plan=clone(plan);e.output_stale=Boolean(markOutputStale&&store.eventOutputs[id]);e.updated_at=nowIso();delete store.eventMemory[id];rebuildEventDerivedState(e.player_id);persist();return getEvent(id);}
export function clearGameOutputStale(id){const g=store.games.find(x=>x.id===Number(id));if(g){g.output_stale=false;g.updated_at=nowIso();persist();}}
export function clearEventOutputStale(id){const e=store.events.find(x=>x.id===Number(id));if(e){e.output_stale=false;e.updated_at=nowIso();persist();}}

export function getDbPath(){return dbPath;}
