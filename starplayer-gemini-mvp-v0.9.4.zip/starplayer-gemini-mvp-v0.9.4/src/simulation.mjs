function n(value) {
  if (value === null || value === undefined || value === '') return null;
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

export function inningsTextToOuts(value) {
  if (value === null || value === undefined) return null;
  const text = String(value).trim();
  const m = text.match(/^(\d+)(?:\.(\d))?$/);
  if (!m) return null;
  const whole = Number(m[1]);
  const partial = m[2] ? Number(m[2]) : 0;
  if (![0, 1, 2].includes(partial)) return null;
  return whole * 3 + partial;
}

export function outsToInnings(outs) {
  if (!Number.isFinite(outs)) return '—';
  return `${Math.floor(outs / 3)}.${outs % 3}`;
}

function findStat(text, pattern) {
  const match = text.match(pattern);
  return match ? Number(match[1]) : null;
}

function findNamedCount(text, word) {
  const token = word === '사구' ? '(?<!사)사구' : word;
  const a = text.match(new RegExp(`${token}\\s*(\\d+)\\s*개?`));
  if (a) return Number(a[1]);
  const b = text.match(new RegExp(`(\\d+)\\s*${token}`));
  return b ? Number(b[1]) : null;
}

export function offlineParseGameInput(raw) {
  const text = raw.replace(/\r/g, '').trim();
  const lines = text.split('\n').map(s => s.trim()).filter(Boolean);

  const dateMatch = text.match(/(20\d{2})년\s*(\d{1,2})월\s*(\d{1,2})일/);
  const date = dateMatch
    ? `${dateMatch[1]}-${String(dateMatch[2]).padStart(2, '0')}-${String(dateMatch[3]).padStart(2, '0')}`
    : null;
  const timeMatch = text.match(/(이른\s*오전|오전|낮|정오|오후|저녁|밤)(?:\s*(\d{1,2})(?::|시)?\s*(\d{1,2})?분?)?/);
  const timeLabel = timeMatch ? [timeMatch[1], timeMatch[2] ? `${timeMatch[2]}${timeMatch[3] ? `:${String(timeMatch[3]).padStart(2,'0')}` : '시'}` : ''].filter(Boolean).join(' ') : null;

  const opponentMatch = text.match(/-\s*([^\n(]+?)\s*\((홈|원정)\)/);
  const opponent = opponentMatch ? opponentMatch[1].trim() : null;
  const homeAway = opponentMatch ? (opponentMatch[2] === '홈' ? 'home' : 'away') : 'unknown';

  let teamScore = null;
  let opponentScore = null;
  let result = 'unknown';
  for (const line of lines) {
    const score = line.match(/(\d+)\s*-\s*(\d+)\s*(승리|패배|무승부)?/);
    if (score && /승리|패배|무승부|이김|짐|경기/.test(line)) {
      teamScore = Number(score[1]);
      opponentScore = Number(score[2]);
      if (line.includes('승리')) result = 'W';
      else if (line.includes('패배')) result = 'L';
      else if (line.includes('무승부')) result = 'T';
      break;
    }
  }

  const pSection = text.match(/\[투수 기록\]([\s\S]*?)(?=\[타자 기록\]|$)/)?.[1] ?? '';
  const bSection = text.match(/\[타자 기록\]([\s\S]*?)(?=\n\d+회:|$)/)?.[1] ?? '';

  let pitching = null;
  if (pSection) {
    const ip = pSection.match(/(\d+(?:\.\d)?)이닝/);
    const decision = /승패 결정 없음|승패\s*없음/.test(text) ? 'ND'
      : /승리투수/.test(text) ? 'W'
      : /패전투수/.test(text) ? 'L'
      : /세이브/.test(text) ? 'S'
      : /홀드/.test(text) ? 'H'
      : 'none';
    pitching = {
      outs: ip ? inningsTextToOuts(ip[1]) : null,
      battersFaced: findStat(pSection, /상대\s*타자\s*(\d+)명/),
      hits: findStat(pSection, /(\d+)피안타/),
      homeRuns: findStat(pSection, /(\d+)피홈런/),
      strikeouts: findStat(pSection, /(\d+)탈삼진/),
      ...(() => {
        const explicitWalks = findNamedCount(pSection, '볼넷');
        const totalFreePasses = findNamedCount(pSection, '사사구');
        const explicitHbp = findNamedCount(pSection, '사구');
        if (explicitWalks != null) return { walks: explicitWalks, hbp: explicitHbp };
        if (totalFreePasses != null && explicitHbp != null) return { walks: Math.max(0, totalFreePasses - explicitHbp), hbp: explicitHbp };
        if (totalFreePasses != null) return { walks: totalFreePasses, hbp: 0 };
        return { walks: null, hbp: explicitHbp };
      })(),
      runs: findStat(pSection, /(\d+)실점/),
      earnedRuns: findStat(pSection, /(\d+)자책점/),
      pitches: findStat(text, /투구\s*수\s*:\s*(\d+)개/),
      decision
    };
  }

  let batting = null;
  if (bSection) {
    batting = {
      lineupSpot: findStat(bSection, /(\d+)번타자/),
      atBats: findStat(bSection, /(\d+)타수/),
      hits: findStat(bSection, /(\d+)안타/),
      doubles: findStat(bSection, /(\d+)2루타/),
      triples: findStat(bSection, /(\d+)3루타/),
      homeRuns: findStat(bSection, /(\d+)홈런/),
      rbi: findStat(bSection, /(\d+)타점/),
      runs: findStat(bSection, /(\d+)득점/),
      walks: findStat(bSection, /(\d+)볼넷/),
      hbp: findStat(bSection, /(\d+)사구/),
      stolenBases: findStat(bSection, /(\d+)도루/),
      strikeouts: findStat(bSection, /(\d+)삼진/)
    };
  }

  const highlights = lines
    .filter(line => /^\d+회\s*:/.test(line) || /강판|끝내기|역전|결승|인터뷰/.test(line))
    .map(line => ({ description: line }));

  const exitLine = lines.find(line => /강판/.test(line)) ?? null;
  const triggers = [];
  if (/인터뷰함|인터뷰\s*있음|인터뷰있음|히어로\s*인터뷰/.test(text)) triggers.push('hero_interview');

  return sanitizeParsedGame({
    date,
    timeLabel,
    worldTimeMinutes: null,
    opponent,
    homeAway,
    teamScore,
    opponentScore,
    result,
    pitching,
    batting,
    highlights,
    exitContext: exitLine,
    specialTriggers: triggers,
    parser: 'offline'
  });
}

export function sanitizeParsedGame(input) {
  const b = input.batting ? {
    lineupSpot: n(input.batting.lineupSpot),
    appearanceCode: n(input.batting.appearanceCode),
    positionCode: n(input.batting.positionCode),
    position: input.batting.position ? String(input.batting.position) : null,
    plateAppearances: n(input.batting.plateAppearances),
    atBats: n(input.batting.atBats),
    hits: n(input.batting.hits),
    singles: n(input.batting.singles),
    doubles: n(input.batting.doubles),
    triples: n(input.batting.triples),
    homeRuns: n(input.batting.homeRuns),
    rbi: n(input.batting.rbi),
    runs: n(input.batting.runs),
    walks: n(input.batting.walks),
    hbp: n(input.batting.hbp),
    stolenBases: n(input.batting.stolenBases),
    groundedIntoDoublePlay: n(input.batting.groundedIntoDoublePlay),
    errors: n(input.batting.errors),
    strikeouts: n(input.batting.strikeouts),
    sacBuntCandidate: n(input.batting.sacBuntCandidate),
    sacFlyCandidate: n(input.batting.sacFlyCandidate)
  } : null;
  const p = input.pitching ? {
    outs: n(input.pitching.outs),
    battersFaced: n(input.pitching.battersFaced),
    hits: n(input.pitching.hits),
    homeRuns: n(input.pitching.homeRuns),
    strikeouts: n(input.pitching.strikeouts),
    walks: n(input.pitching.walks),
    hbp: n(input.pitching.hbp),
    walksPlusHbp: n(input.pitching.walksPlusHbp),
    runs: n(input.pitching.runs),
    earnedRuns: n(input.pitching.earnedRuns),
    pitches: n(input.pitching.pitches),
    started: input.pitching.started == null ? null : Boolean(input.pitching.started),
    qualityStart: input.pitching.qualityStart == null ? null : Boolean(input.pitching.qualityStart),
    highQualityStart: input.pitching.highQualityStart == null ? null : Boolean(input.pitching.highQualityStart),
    win: input.pitching.win == null ? null : Boolean(input.pitching.win),
    loss: input.pitching.loss == null ? null : Boolean(input.pitching.loss),
    noDecision: input.pitching.noDecision == null ? null : Boolean(input.pitching.noDecision),
    hold: input.pitching.hold == null ? null : Boolean(input.pitching.hold),
    save: input.pitching.save == null ? null : Boolean(input.pitching.save),
    blownSave: input.pitching.blownSave == null ? null : Boolean(input.pitching.blownSave),
    decisionCode: n(input.pitching.decisionCode),
    decision: ['W','L','ND','S','H','BS','none'].includes(input.pitching.decision) ? input.pitching.decision : 'none'
  } : null;

  return {
    date: input.date || null,
    timeLabel: input.timeLabel ? String(input.timeLabel) : null,
    worldTimeMinutes: n(input.worldTimeMinutes),
    opponent: input.opponent || null,
    homeAway: ['home','away','unknown'].includes(input.homeAway) ? input.homeAway : 'unknown',
    teamScore: n(input.teamScore),
    opponentScore: n(input.opponentScore),
    result: ['W','L','T','unknown'].includes(input.result) ? input.result : 'unknown',
    pitching: p,
    batting: b,
    highlights: Array.isArray(input.highlights)
      ? input.highlights.map(h => ({ description: String(h.description || '').trim() })).filter(h => h.description)
      : [],
    exitContext: input.exitContext ? String(input.exitContext) : null,
    specialTriggers: Array.isArray(input.specialTriggers) ? input.specialTriggers.map(String) : [],
    parser: input.parser || 'gemini'
  };
}

function battingGrade(b) {
  if (!b) return null;
  const ab = b.atBats ?? 0;
  const h = b.hits ?? 0;
  const hr = b.homeRuns ?? 0;
  const rbi = b.rbi ?? 0;
  const k = b.strikeouts ?? 0;
  if (hr >= 1 || h >= 2 || rbi >= 2) return '활약';
  if (ab >= 4 && h === 0 && k >= 2) return '부진';
  if (ab >= 5 && h === 0 && k >= 3) return '아주 부진';
  return '애매';
}

function pitchingGrade(p) {
  if (!p) return null;
  const outs = p.outs ?? 0;
  const er = p.earnedRuns ?? p.runs ?? 0;
  const k = p.strikeouts ?? 0;
  const bb = p.walks ?? 0;
  if ((outs >= 18 && er <= 2) || (outs >= 21 && er <= 3) || k >= 9) return '활약';
  if ((er >= 6) || (outs <= 12 && er >= 5)) return '아주 부진';
  if ((outs < 15 && er >= 4) || (bb >= 5 && outs < 18)) return '부진';
  return '애매';
}

export function judgePerformance(parsed) {
  const bg = battingGrade(parsed.batting);
  const pg = pitchingGrade(parsed.pitching);
  if (bg && !pg) return bg;
  if (pg && !bg) return pg;
  if (!bg && !pg) return '애매';
  if (bg === pg) return bg;
  if ([bg, pg].includes('아주 부진') && [bg, pg].includes('활약')) return '애매';
  if ([bg, pg].includes('활약')) return '활약';
  if ([bg, pg].includes('아주 부진')) return '아주 부진';
  if ([bg, pg].includes('부진')) return '부진';
  return '애매';
}

function hasKeyword(parsed, words) {
  const haystack = [
    parsed.exitContext,
    ...parsed.highlights.map(h => h.description)
  ].filter(Boolean).join(' ');
  return words.some(w => haystack.includes(w));
}

export function judgeAttention(parsed, context = {}) {
  if (!parsed.pitching && !parsed.batting) return 0;
  const b = parsed.batting;
  const p = parsed.pitching;

  const majorKeyword = hasKeyword(parsed, ['끝내기', '노히트', '퍼펙트', '완봉', '완투', '우승', '포스트시즌', '신기록', '역사적']);
  const firstCareerHr = (b?.homeRuns ?? 0) > 0 && (context.previousHomeRuns ?? 0) === 0;
  const dominantPitch = (p?.outs ?? 0) >= 24 && (p?.earnedRuns ?? 99) <= 1;
  const hugeBat = (b?.homeRuns ?? 0) >= 2 || (b?.rbi ?? 0) >= 4 || (b?.hits ?? 0) >= 4;
  if (majorKeyword || firstCareerHr || dominantPitch || hugeBat) return 3;

  const notablePitch = ((p?.outs ?? 0) >= 18 && (p?.earnedRuns ?? 99) <= 3) || (p?.strikeouts ?? 0) >= 8;
  const notableBat = (b?.homeRuns ?? 0) >= 1 || (b?.hits ?? 0) >= 2 || (b?.rbi ?? 0) >= 2;
  const negativeStory = hasKeyword(parsed, ['조기 강판', '블론세이브', '실책']) || ((p?.earnedRuns ?? 0) >= 5);
  if (notablePitch || notableBat || negativeStory) return 2;

  return 1;
}

function reactionScopesOf(playerCanon = {}) {
  const s=playerCanon?.reactionScopes || {};
  return { japanBaseball:s.japanBaseball!==false, koreaBaseball:Boolean(s.koreaBaseball), koreaSocial:Boolean(s.koreaSocial), koreaEntertainment:Boolean(s.koreaEntertainment) };
}

const communityBaseRanges = {
  jp_analysis:[7,8], baseball_ch:[9,11], team_fans:[8,10], x_jp:[3,4],
  mlbpark:[7,8], dc_baseball:[9,11], x_kr:[3,4], theqoo:[7,9], dc_idol:[8,10]
};
const nestedShares = { jp_analysis:.2, baseball_ch:.55, team_fans:.35, x_jp:0, mlbpark:.2, dc_baseball:.6, x_kr:0, theqoo:.15, dc_idol:.45 };
const angleHints = {
  jp_analysis:'리그 전체 관점의 기록·전력·기용 분석',
  baseball_ch:'경기 중 순간 반응과 짧은 실황성 논쟁',
  team_fans:'우리 팀 선수라는 관점의 기대·불안·감독/불펜/다음 경기 이야기',
  x_jp:'일본 야구팬의 짧은 즉시 반응과 확산',
  mlbpark:'한국 야구팬의 비교적 긴 기록 해석·시즌 가치·리그/선수 비교',
  dc_baseball:'한국 야구 익명 커뮤니티의 과대평가/저평가·기용 가치 논쟁',
  x_kr:'한국 야구팬·대중의 짧은 SNS 반응과 한국어권 확산',
  theqoo:'한국 대중·라이트 팬의 공감·관계성·가벼운 야구 반응',
  dc_idol:'한국 아이돌/연예 팬덤·보도·업계 맥락 중심 논쟁'
};
function enabledScopeCount(scopes){return Object.values(scopes).filter(Boolean).length||1;}
function addCommunity(plan,platform,posts=1,{attentionLevel=1,scopeCount=1}={}){
  const base=communityBaseRanges[platform]||[5,7];
  const scopeBonus=scopeCount>=4?1:0;
  const attentionBonus=attentionLevel>=3?1:0;
  const min=Math.max(3,base[0]+scopeBonus+attentionBonus),max=Math.max(min,base[1]+scopeBonus+attentionBonus);
  plan.communities.push({platform,posts,commentsMin:min,commentsMax:max,nestedShare:nestedShares[platform]??.2,angleHint:angleHints[platform]||''});
}

export function chooseOutputPlan(parsed, performanceGrade, attentionLevel, playerDynamic = {}, playerCanon = {}) {
  const p = parsed.pitching;
  const b = parsed.batting;
  const scopes=reactionScopesOf(playerCanon),scopeCount=enabledScopeCount(scopes);
  const plan = { attentionLevel, performanceGrade, articles: [], communities: [], personalContact: false, reactionScopes:scopes, enabledScopeCount:scopeCount };
  if (attentionLevel === 0) return plan;

  const analysisMaterial = (p?.outs ?? 0) >= 18 || (b?.hits ?? 0) >= 2 || (b?.homeRuns ?? 0) >= 1;
  const immediacy = (b?.homeRuns ?? 0) >= 1 || parsed.highlights.length > 0 || Boolean(parsed.exitContext);
  const basicNewsValue = (p?.outs ?? 0) >= 15 || (b?.homeRuns ?? 0) >= 1 || (b?.hits ?? 0) >= 2 || performanceGrade !== '애매';

  if (attentionLevel === 1) { if (basicNewsValue) plan.articles.push({ platform: 'sponichi', count: 1 }); }
  if (attentionLevel === 2) { if (analysisMaterial) plan.articles.push({ platform: 'analysis', count: 1 }); if (immediacy || !analysisMaterial) plan.articles.push({ platform: 'sponichi', count: 1 }); }
  if (attentionLevel === 3) plan.articles.push({ platform: 'analysis', count: 1 }, { platform: 'sponichi', count: 1 });

  if(scopes.japanBaseball){
    addCommunity(plan,'jp_analysis',1,{attentionLevel,scopeCount});
    addCommunity(plan,'baseball_ch',1,{attentionLevel,scopeCount});
    addCommunity(plan,'team_fans',1,{attentionLevel,scopeCount});
    addCommunity(plan,'x_jp',2,{attentionLevel,scopeCount});
  }
  if(scopes.koreaBaseball){
    addCommunity(plan,'mlbpark',1,{attentionLevel,scopeCount});
    addCommunity(plan,'dc_baseball',1,{attentionLevel,scopeCount});
  }
  if(scopes.koreaSocial){
    addCommunity(plan,'x_kr',2,{attentionLevel,scopeCount});
    addCommunity(plan,'theqoo',1,{attentionLevel,scopeCount});
  }

  const idolConnection = parsed.specialTriggers.includes('idol_connection');
  if(scopes.koreaEntertainment && idolConnection) addCommunity(plan,'dc_idol',1,{attentionLevel,scopeCount});
  return plan;
}

export function formatGameForPrompt(parsed) {
  const parts = [];
  if (parsed.date) parts.push(`날짜: ${parsed.date}${parsed.timeLabel ? ` ${parsed.timeLabel}` : ''}`);
  if (parsed.opponent) parts.push(`상대: ${parsed.opponent} (${parsed.homeAway})`);
  if (parsed.teamScore !== null && parsed.opponentScore !== null) parts.push(`스코어: ${parsed.teamScore}-${parsed.opponentScore} / 결과 ${parsed.result}`);
  if (parsed.pitching) {
    const p = parsed.pitching;
    parts.push(`투수: ${outsToInnings(p.outs)}이닝, ${p.hits ?? '미제공'}피안타, ${p.homeRuns ?? '미제공'}피홈런, ${p.strikeouts ?? '미제공'}K, ${p.walks ?? '미제공'}BB, ${p.hbp ?? '미제공'}HBP, ${p.runs ?? '미제공'}실점, ${p.earnedRuns ?? '미제공'}자책, ${p.pitches ?? '미제공'}구, 결정 ${p.decision}`);
  }
  if (parsed.batting) {
    const b = parsed.batting;
    parts.push(`타자: ${b.lineupSpot ?? '미제공'}번, ${b.atBats ?? '미제공'}타수 ${b.hits ?? '미제공'}안타 ${b.homeRuns ?? '미제공'}홈런 ${b.rbi ?? '미제공'}타점 ${b.runs ?? '미제공'}득점 ${b.walks ?? '미제공'}볼넷 ${b.hbp ?? '미제공'}사구 ${b.stolenBases ?? '미제공'}도루 ${b.strikeouts ?? '미제공'}삼진`);
  }
  if (parsed.highlights.length) parts.push(`사용자 제공 장면:\n- ${parsed.highlights.map(h => h.description).join('\n- ')}`);
  if (parsed.exitContext) parts.push(`교체/맥락: ${parsed.exitContext}`);
  return parts.join('\n');
}

function compactText(value, max = 170) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  return text.length > max ? `${text.slice(0, max)}…` : text;
}

function bundleStyleSamples(bundle) {
  const samples = [];
  for (const article of bundle?.articles || []) {
    if (article.title) samples.push(`[${article.platform}/제목] ${compactText(article.title, 120)}`);
    if (article.body) samples.push(`[${article.platform}/도입] ${compactText(article.body, 170)}`);
  }
  for (const group of bundle?.communities || []) {
    for (const post of group.posts || []) {
      if (post.title) samples.push(`[${group.platform}/제목] ${compactText(post.title, 110)}`);
      if (post.body) samples.push(`[${group.platform}/본문] ${compactText(post.body, 150)}`);
      for (const comment of (post.comments || []).slice(0, 2)) {
        samples.push(`[${group.platform}/댓글] ${compactText(comment.body, 100)}`);
      }
    }
  }
  return samples.filter(Boolean).slice(0, 28);
}

export function buildMemorySummary(parsed, plan, bundle) {
  const topics = [];
  if ((parsed.batting?.homeRuns ?? 0) > 0) topics.push('홈런');
  if ((parsed.batting?.hits ?? 0) >= 2) topics.push('멀티히트');
  if ((parsed.pitching?.outs ?? 0) >= 18) topics.push('선발 투구');
  if (parsed.exitContext) topics.push('교체 시점');
  const titles = [
    ...(bundle?.articles || []).map(a => a.title),
    ...(bundle?.communities || []).flatMap(c => (c.posts || []).map(p => p.title)).filter(Boolean)
  ].slice(0, 10);
  return {
    date: parsed.date,
    timeLabel: parsed.timeLabel || null,
    opponent: parsed.opponent,
    topics,
    performanceGrade: plan.performanceGrade,
    attentionLevel: plan.attentionLevel,
    generatedPlatforms: [
      ...plan.articles.map(a => a.platform),
      ...plan.communities.filter(c => c.posts > 0).map(c => c.platform)
    ],
    representativeTitles: titles,
    avoidStyleSamples: bundleStyleSamples(bundle)
  };
}

export function classifyRawInputKind(raw) {
  const text = String(raw || '').replace(/\r/g, '').trim();
  if (!text) return 'unknown';

  let gameScore = 0;
  let eventScore = 0;

  // 경기 입력에서만 자주 등장하는 구조적 증거. 단순히 "8이닝 1실점" 한 줄만 있다고 경기를 확정하지 않는다.
  if (/\[투수 기록\]/.test(text)) gameScore += 4;
  if (/\[타자 기록\]/.test(text)) gameScore += 4;
  if (/^[^\n:]{1,40}:\s*(?:선발투수|투수|\d+번타자|선발)/m.test(text)) gameScore += 2;
  if (/[^\n]{1,40}\s+\d+\s*-\s*\d+\s*(?:승리|패배|무승부)?/.test(text)) gameScore += 2;
  if (/\d+\s*-\s*\d+\s*(?:승리|패배|무승부)/.test(text)) gameScore += 2;
  if (/\d+(?:\.\d)?이닝[^\n]{0,90}(?:피안타|탈삼진|자책|실점)/.test(text)) gameScore += 1;

  // 경기 밖 사건의 강한 증거. 이벤트 안에 직전 경기 기록이 배경으로 들어가도 EVENT가 우선되도록 별도 점수화한다.
  if (/(?:쌍둥이|남매|누나|동생|가족관계).*(?:공개|보도|확인|알려|밝혀)/s.test(text)) eventScore += 6;
  if (/(?:디스패치|연예매체|단독\s*보도|기사화|보도됨|취재)/.test(text)) eventScore += 4;
  if (/(?:공식\s*(?:입장|확인|발표)|구단\s*(?:발표|공지|확인))/.test(text)) eventScore += 3;
  if (/(?:계약|재계약|이적|트레이드|방출|은퇴|수상|징계|등록|말소|보직\s*변경|등번호\s*(?:변경|확정)|부상|수술|재활)/.test(text)) eventScore += 3;
  if (/(?:SNS|인스타|트위터|\bX\b|방송|광고|화보|팬미팅|열애설|논란)/.test(text)) eventScore += 2;
  if (/(?:최고구속|프로필|신장|체중).*(?:변경|갱신|수정|공개|확정)/.test(text)) eventScore += 4;
  if (/(?:전날|직전|지난\s*경기|전 경기|앞선 경기)[^\n]{0,100}(?:이닝|탈삼진|홈런|첫 승|첫 홈런|승리|패배)/.test(text)) eventScore += 2;

  if (eventScore >= 4 && eventScore >= gameScore) return 'event';
  if (gameScore >= 4 && gameScore > eventScore) return 'game';
  if (eventScore >= 3 && gameScore <= 1) return 'event';
  if (gameScore >= 3 && eventScore === 0) return 'game';
  return 'unknown';
}

export function isLikelySpecialEventInput(raw) {
  return classifyRawInputKind(raw) === 'event';
}

export function isLikelyGameInput(raw) {
  return classifyRawInputKind(raw) === 'game';
}

export function offlineParseEventInput(raw) {
  const text = String(raw || '').replace(/\r/g, '').trim();
  const dateMatch = text.match(/(20\d{2})년\s*(\d{1,2})월\s*(\d{1,2})일/);
  const date = dateMatch
    ? `${dateMatch[1]}-${String(dateMatch[2]).padStart(2, '0')}-${String(dateMatch[3]).padStart(2, '0')}`
    : null;
  const timeMatch = text.match(/(이른\s*오전|오전|낮|정오|오후|저녁|밤|새벽)(?:\s*(\d{1,2})(?::|시)?\s*(\d{1,2})?분?)?/);
  const timeLabel = timeMatch ? [timeMatch[1], timeMatch[2] ? `${timeMatch[2]}${timeMatch[3] ? `:${String(timeMatch[3]).padStart(2,'0')}` : '시'}` : ''].filter(Boolean).join(' ') : null;
  const idolConnection = /걸그룹|아이돌|멤버|소속사|팬덤|디스패치|연예/.test(text);
  const koreanEntertainment = /걸그룹|아이돌|멤버|소속사|팬덤|디스패치|연예매체|연예계/.test(text);
  const baseballConnection = /야구|NPB|프로야구|투수|타자|홈런|이닝|탈삼진|경기|선발|보직|부상|계약|이적|트레이드/.test(text);
  const relationshipDisclosure = /(쌍둥이|남매|동생|누나).*(공개|보도|확인|밝혀|알려)|(?:공개|보도|확인).*(쌍둥이|남매|동생|누나)/s.test(text);
  const officialConfirmation = /공식.*(확인|발표|입장)|구단.*(확인|발표|입장)/s.test(text);
  const koreanSpread = koreanEntertainment || /한국|한국어권/.test(text);
  const lines = text.split('\n').map(x => x.trim()).filter(Boolean).filter(x => !/^20\d{2}년/.test(x));
  const summary = compactText(lines[0] || '특별 이벤트', 120);
  let category = 'other';
  if (relationshipDisclosure) category = 'relationship';
  else if (koreanEntertainment) category = 'entertainment';
  else if (/부상/.test(text)) category = 'injury';
  else if (/계약|이적|트레이드/.test(text)) category = 'career';
  else if (/SNS|인스타|X\b|트위터/.test(text)) category = 'social';
  else category = 'other';

  const confirmedFacts = text.split(/\n|(?<=[.!?])\s+/).map(x => x.trim()).filter(x => x && !/^20\d{2}년/.test(x)).slice(0, 12);
  return sanitizeParsedEvent({
    date, timeLabel, worldTimeMinutes: null, category, summary, confirmedFacts,
    flags: { koreanEntertainment, idolConnection, baseballConnection, relationshipDisclosure, officialConfirmation, koreanSpread },
    stateChanges: {
      relationshipPublicJapan: relationshipDisclosure ? true : false,
      relationshipPublicKorea: relationshipDisclosure ? true : false,
      publicAwarenessJapan: null,
      publicAwarenessKorea: null,
      pitchingRole: /(?:선발투수|선발\s*전환)/.test(text) ? '선발투수' : /마무리/.test(text) ? '마무리투수' : /셋업/.test(text) ? '셋업맨' : /중간계투|불펜/.test(text) ? '중간계투' : null
    },
    parser: 'offline'
  });
}

export function sanitizeParsedEvent(input) {
  const flags = input.flags || {};
  const stateChanges = input.stateChanges || {};
  return {
    date: input.date || null,
    timeLabel: input.timeLabel ? String(input.timeLabel) : null,
    worldTimeMinutes: n(input.worldTimeMinutes),
    category: flags.relationshipDisclosure ? 'relationship' : (flags.koreanEntertainment || flags.idolConnection) ? 'entertainment' : ['relationship','entertainment','injury','career','social','other'].includes(input.category) ? input.category : 'other',
    summary: String(input.summary || '특별 이벤트').trim(),
    confirmedFacts: Array.isArray(input.confirmedFacts) ? input.confirmedFacts.map(x => String(x).trim()).filter(Boolean).slice(0, 20) : [],
    flags: {
      koreanEntertainment: Boolean(flags.koreanEntertainment),
      idolConnection: Boolean(flags.idolConnection),
      baseballConnection: Boolean(flags.baseballConnection),
      relationshipDisclosure: Boolean(flags.relationshipDisclosure),
      officialConfirmation: Boolean(flags.officialConfirmation),
      koreanSpread: Boolean(flags.koreanSpread)
    },
    stateChanges: {
      relationshipPublicJapan: stateChanges.relationshipPublicJapan === true,
      relationshipPublicKorea: stateChanges.relationshipPublicKorea === true,
      publicAwarenessJapan: stateChanges.publicAwarenessJapan ? String(stateChanges.publicAwarenessJapan) : null,
      publicAwarenessKorea: stateChanges.publicAwarenessKorea ? String(stateChanges.publicAwarenessKorea) : null,
      pitchingRole: stateChanges.pitchingRole ? String(stateChanges.pitchingRole) : null
    },
    parser: input.parser || 'gemini'
  };
}

export function judgeEventAttention(event) {
  const text = [event.summary, ...(event.confirmedFacts || [])].join(' ');
  if (event.flags.relationshipDisclosure) return 3;
  if (/은퇴|대형\s*부상|시즌\s*아웃|트레이드|이적|징계|열애설|공식\s*인정|신기록|수상|논란/.test(text)) return 3;
  if (event.flags.officialConfirmation || event.flags.koreanEntertainment || /부상|계약|보직|SNS|인터뷰|방송|광고/.test(text)) return 2;
  return 1;
}

export function chooseEventOutputPlan(event, attentionLevel, playerDynamic = {}, playerCanon = {}) {
  const scopes=reactionScopesOf(playerCanon),scopeCount=enabledScopeCount(scopes);
  const plan = { attentionLevel, performanceGrade: null, articles: [], communities: [], personalContact: false, event: true, reactionScopes:scopes, enabledScopeCount:scopeCount };
  const f = event.flags;
  const text = [event.summary, ...(event.confirmedFacts || [])].join(' ');
  const analysisMaterial = f.baseballConnection && /기록|성적|경기|이닝|탈삼진|홈런|부상|보직|기용|계약|이적|투타겸업/.test(text);

  if (scopes.koreaEntertainment && f.koreanEntertainment) plan.articles.push({ platform: 'dispatch', count: 1 });
  if (f.baseballConnection && attentionLevel >= 2) plan.articles.push({ platform: 'sponichi', count: 1 });
  if (analysisMaterial && attentionLevel >= 2) plan.articles.unshift({ platform: 'analysis', count: 1 });

  if (f.baseballConnection && scopes.japanBaseball) {
    addCommunity(plan,'jp_analysis',1,{attentionLevel,scopeCount});
    addCommunity(plan,'baseball_ch',1,{attentionLevel,scopeCount});
    addCommunity(plan,'team_fans',1,{attentionLevel,scopeCount});
    addCommunity(plan,'x_jp',2,{attentionLevel,scopeCount});
  }
  if (f.baseballConnection && scopes.koreaBaseball) {
    addCommunity(plan,'mlbpark',1,{attentionLevel,scopeCount});
    addCommunity(plan,'dc_baseball',1,{attentionLevel,scopeCount});
  }
  if (scopes.koreaEntertainment && f.idolConnection) addCommunity(plan,'dc_idol',1,{attentionLevel,scopeCount});
  if (scopes.koreaSocial && (f.baseballConnection || f.koreanEntertainment || f.koreanSpread || f.idolConnection || playerDynamic?.relationshipState?.publicKorea)) {
    addCommunity(plan,'x_kr',2,{attentionLevel,scopeCount});
    addCommunity(plan,'theqoo',1,{attentionLevel,scopeCount});
  }
  return plan;
}

export function formatEventForPrompt(event) {
  const parts = [];
  if (event.date) parts.push(`날짜: ${event.date}${event.timeLabel ? ` ${event.timeLabel}` : ''}`);
  parts.push(`이벤트 요약: ${event.summary}`);
  if (event.confirmedFacts?.length) parts.push(`사용자가 제공한 확정 사실:\n- ${event.confirmedFacts.join('\n- ')}`);
  parts.push(`이벤트 분류: ${event.category}`);
  parts.push(`플래그: ${JSON.stringify(event.flags)}`);
  return parts.join('\n');
}

export function buildEventMemorySummary(event, plan, bundle) {
  return {
    date: event.date,
    timeLabel: event.timeLabel || null,
    eventSummary: event.summary,
    topics: [event.category, ...(event.flags.relationshipDisclosure ? ['가족관계 공개'] : []), ...(event.flags.idolConnection ? ['아이돌 이슈'] : [])],
    attentionLevel: plan.attentionLevel,
    generatedPlatforms: [
      ...plan.articles.map(a => a.platform),
      ...plan.communities.filter(c => c.posts > 0).map(c => c.platform)
    ],
    representativeTitles: [
      ...(bundle?.articles || []).map(a => a.title),
      ...(bundle?.communities || []).flatMap(c => (c.posts || []).map(p => p.title)).filter(Boolean)
    ].slice(0, 10),
    avoidStyleSamples: bundleStyleSamples(bundle)
  };
}
