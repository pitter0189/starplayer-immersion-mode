import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const configDir = path.join(root, 'data', 'config');
const secretsPath = path.join(configDir, 'secrets.json');
fs.mkdirSync(configDir, { recursive: true });

function readJson(file, fallback = {}) { try { if(!fs.existsSync(file))return fallback; return JSON.parse(fs.readFileSync(file,'utf8')); } catch { return fallback; } }
function writeJson(file,data){const tmp=`${file}.tmp`;fs.writeFileSync(tmp,JSON.stringify(data,null,2),'utf8');fs.renameSync(tmp,file);}
function clean(value){return value==null?'':String(value).trim();}
function mask(key){const s=clean(key);if(!s)return'';if(s.length<=8)return'••••••••';return `${'•'.repeat(Math.min(16,Math.max(8,s.length-4)))}${s.slice(-4)}`;}

export function getRuntimeConfig(){const saved=readJson(secretsPath,{});const lineApiKey=clean(saved.lineApiKey)||clean(process.env.LINE_GEMINI_API_KEY);return{
  mainApiKey:clean(saved.mainApiKey)||clean(process.env.GEMINI_API_KEY),
  mainModel:clean(saved.mainModel)||clean(process.env.GEMINI_MODEL),
  interviewApiKey:clean(saved.interviewApiKey)||clean(process.env.INTERVIEW_GEMINI_API_KEY),
  interviewModel:clean(saved.interviewModel)||clean(process.env.INTERVIEW_GEMINI_MODEL),
  lineEnabled:typeof saved.lineEnabled==='boolean'?saved.lineEnabled:Boolean(lineApiKey),
  lineApiKey,
  lineModel:clean(saved.lineModel)||clean(process.env.LINE_GEMINI_MODEL),
  lineMode:['auto','direct'].includes(saved.lineMode)?saved.lineMode:'auto'
};}
export function getPublicApiSettings(){const c=getRuntimeConfig();return{
  mainConfigured:Boolean(c.mainApiKey),mainApiKeyMasked:mask(c.mainApiKey),mainModel:c.mainModel,
  interviewConfigured:Boolean(c.interviewApiKey),interviewApiKeyMasked:mask(c.interviewApiKey),interviewModel:c.interviewModel,
  lineEnabled:Boolean(c.lineEnabled),lineConfigured:Boolean(c.lineApiKey),lineApiKeyMasked:mask(c.lineApiKey),lineModel:c.lineModel,lineMode:c.lineMode
};}
export function saveApiSettings(patch={}){const next={...readJson(secretsPath,{})};
  if(Object.prototype.hasOwnProperty.call(patch,'mainApiKey')){const v=clean(patch.mainApiKey);if(v)next.mainApiKey=v;} if(patch.clearMainApiKey===true)delete next.mainApiKey; if(Object.prototype.hasOwnProperty.call(patch,'mainModel')){const v=clean(patch.mainModel);if(v)next.mainModel=v;else delete next.mainModel;}
  if(Object.prototype.hasOwnProperty.call(patch,'interviewApiKey')){const v=clean(patch.interviewApiKey);if(v)next.interviewApiKey=v;} if(patch.clearInterviewApiKey===true)delete next.interviewApiKey; if(Object.prototype.hasOwnProperty.call(patch,'interviewModel')){const v=clean(patch.interviewModel);if(v)next.interviewModel=v;else delete next.interviewModel;}
  if(Object.prototype.hasOwnProperty.call(patch,'lineEnabled'))next.lineEnabled=Boolean(patch.lineEnabled);
  if(Object.prototype.hasOwnProperty.call(patch,'lineApiKey')){const v=clean(patch.lineApiKey);if(v)next.lineApiKey=v;} if(patch.clearLineApiKey===true)delete next.lineApiKey; if(Object.prototype.hasOwnProperty.call(patch,'lineModel')){const v=clean(patch.lineModel);if(v)next.lineModel=v;else delete next.lineModel;}
  if(Object.prototype.hasOwnProperty.call(patch,'lineMode'))next.lineMode=['auto','direct'].includes(patch.lineMode)?patch.lineMode:'auto';
  writeJson(secretsPath,next);return getPublicApiSettings();}
export function clearApiSettings(){writeJson(secretsPath,{});return getPublicApiSettings();}
export function getSecretsPath(){return secretsPath;}
