import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  getActivePlayerId,getPlayer,getPlayerRuntime,updatePlayerCanon,updatePlayerDynamic,
  getSeasonStats,listGames,listEvents,listTimelineDays,getDayEntries,getGame,getEvent,findMatchingGame,
  saveGame,saveGeneratedOutput,saveCommunityMemory,getRecentContentMemory,countPreviousHomeRuns,
  saveEvent,saveEventGeneratedOutput,saveEventMemory,applyEventStateChanges,deleteGame,deleteEvent,
  listCharacters,getCharacter,saveCharacter,deleteCharacter,getRelevantCharacters,
  listConversationThreads,getConversation,addMessage,markConversationRead,unreadMessageCount,
  createInterview,getInterview,updateInterview,listInterviewsForGame,resetSimulation,
  getTemporalEventContext,timeLabelToMinutes,inferEventLifecycle,saveScheduleEntry,deleteScheduleEntry,listScheduleEntries,
  listSeasons,addSeason,startFreshSimulation,updateGameRecord,updateEventRecord,clearGameOutputStale,clearEventOutputStale,setReaderSeasonStats
} from './db.mjs';
import {
  offlineParseGameInput,sanitizeParsedGame,judgePerformance,judgeAttention,chooseOutputPlan,formatGameForPrompt,buildMemorySummary,
  offlineParseEventInput,sanitizeParsedEvent,judgeEventAttention,chooseEventOutputPlan,formatEventForPrompt,buildEventMemorySummary,isLikelySpecialEventInput,isLikelyGameInput
} from './simulation.mjs';
import {
  parseGameWithGemini,generateGameContent,parseEventWithGemini,generateEventContent,
  generateLineReply,generateAutoLineConversation,generateInterviewQuestion,generateFullInterview,testGeminiConnection,analyzeCharacterSetup
} from './gemini.mjs';
import { getRuntimeConfig,getPublicApiSettings,saveApiSettings,clearApiSettings } from './config.mjs';
import {
  getSaveReaderStatus,setSaveReaderNotifier,setSavePath,inspectSave,linkCurrentSave,pauseSaveReader,
  unlinkSaveReader,rebaselineCurrentSave,listPending,getPending,acknowledgePending,completePending,manualScanNow,startWatcher,resetSaveReaderLinkage,installSaveReaderBundle
} from './save-reader.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(__dirname,'..');
const publicDir=path.join(root,'public');
function loadEnvFile(){const p=path.join(root,'.env');if(!fs.existsSync(p))return;for(const line of fs.readFileSync(p,'utf8').split(/\r?\n/)){const t=line.trim();if(!t||t.startsWith('#'))continue;const i=t.indexOf('=');if(i<0)continue;const k=t.slice(0,i).trim(),v=t.slice(i+1).trim().replace(/^['"]|['"]$/g,'');if(!(k in process.env))process.env[k]=v;}}
loadEnvFile();
const liveClients=new Set();
function sendLive(type,payload={}){const data=`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`;for(const res of [...liveClients]){try{res.write(data)}catch{liveClients.delete(res)}}}
function handleLive(req,res){res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive'});res.write(`event: hello\ndata: ${JSON.stringify({saveReader:getSaveReaderStatus()})}\n\n`);liveClients.add(res);req.on('close',()=>liveClients.delete(res));}
setSaveReaderNotifier(sendLive);
function json(res,status,payload){const b=JSON.stringify(payload);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(b),'Cache-Control':'no-store'});res.end(b);}
async function readBody(req){const chunks=[];let bytes=0;for await(const c of req){bytes+=c.length;if(bytes>12_000_000)throw new Error('요청 본문이 너무 큽니다.');chunks.push(c);}const t=Buffer.concat(chunks).toString('utf8');return t?JSON.parse(t):{};}
async function readRawBody(req,maxBytes=20_000_000){const chunks=[];let bytes=0;for await(const c of req){bytes+=c.length;if(bytes>maxBytes)throw new Error('업데이트 파일이 너무 큽니다.');chunks.push(c);}return Buffer.concat(chunks);}
async function chooseSaveFolder(){
  if(process.platform!=='win32')throw new Error('폴더 선택 창은 Windows 실행 환경에서 사용할 수 있습니다.');
  const current=getSaveReaderStatus()?.savePath||'';const initial=current&&fs.existsSync(current)?(fs.statSync(current).isDirectory()?current:path.dirname(current)):'';
  const script=[
    "Add-Type -AssemblyName System.Windows.Forms",
    "Add-Type -AssemblyName System.Drawing",
    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
    "$d = New-Object System.Windows.Forms.FolderBrowserDialog",
    "$d.Description = 'StarPlayer.dat가 들어 있는 세이브 폴더를 선택하세요.'",
    "$d.ShowNewFolderButton = $false",
    "if ($env:STARPLAYER_INITIAL_FOLDER -and (Test-Path -LiteralPath $env:STARPLAYER_INITIAL_FOLDER)) { $d.SelectedPath = $env:STARPLAYER_INITIAL_FOLDER }",
    "$owner = New-Object System.Windows.Forms.Form",
    "$owner.TopMost = $true",
    "$owner.ShowInTaskbar = $false",
    "$owner.StartPosition = 'Manual'",
    "$owner.Location = New-Object System.Drawing.Point(-32000,-32000)",
    "$owner.Size = New-Object System.Drawing.Size(1,1)",
    "$owner.Show()",
    "$r = $d.ShowDialog($owner)",
    "$owner.Close()",
    "if ($r -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }"
  ].join('; ');
  const folder=await new Promise((resolve,reject)=>{const child=spawn('powershell.exe',['-NoProfile','-STA','-Command',script],{windowsHide:true,env:{...process.env,STARPLAYER_INITIAL_FOLDER:initial}});let out='',err='';child.stdout.on('data',c=>out+=c.toString('utf8'));child.stderr.on('data',c=>err+=c.toString('utf8'));child.on('error',reject);child.on('close',code=>{if(code!==0)return reject(new Error(err.trim()||`폴더 선택 프로세스 종료 코드 ${code}`));resolve(out.trim());});});
  if(!folder)return null;
  if(!fs.existsSync(folder)||!fs.statSync(folder).isDirectory())throw new Error('선택한 폴더를 확인할 수 없습니다.');
  const entry=fs.readdirSync(folder).find(x=>x.toLowerCase()==='starplayer.dat');
  if(!entry)throw new Error('선택한 폴더에서 StarPlayer.dat를 찾지 못했습니다. 세이브 번호 폴더를 선택해 주세요.');
  const savePath=path.join(folder,entry);
  return {folder,savePath};
}
function mimeType(file){return({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'})[path.extname(file).toLowerCase()]||'application/octet-stream';}
function serveStatic(req,res){let pn=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(pn==='/')pn='/index.html';const f=path.normalize(path.join(publicDir,pn));if(!f.startsWith(publicDir)){res.writeHead(403);res.end('Forbidden');return;}if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){const fb=path.join(publicDir,'index.html');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(fs.readFileSync(fb));return;}res.writeHead(200,{'Content-Type':mimeType(f),'Cache-Control':'no-cache'});res.end(fs.readFileSync(f));}
function requirePlayer(res){const id=getActivePlayerId();if(!id){json(res,409,{error:'메인 캐릭터 설정이 필요합니다.',needsOnboarding:true});return null;}return id;}
function runtime(){const c=getRuntimeConfig();return{geminiConfigured:Boolean(c.mainApiKey),model:c.mainModel,interviewConfigured:Boolean(c.interviewApiKey),interviewModel:c.interviewModel,lineEnabled:Boolean(c.lineEnabled),lineConfigured:Boolean(c.lineApiKey),lineModel:c.lineModel,lineMode:c.lineMode};}
function playerRuntime(id){return getPlayerRuntime(id)||getPlayer(id);}
function buildRuntimeJudgement(playerId,parsed){const match=findMatchingGame(playerId,parsed),previousHomeRuns=countPreviousHomeRuns(playerId,match?.id??null),performanceGrade=judgePerformance(parsed),attentionLevel=judgeAttention(parsed,{previousHomeRuns}),player=playerRuntime(playerId),plan=chooseOutputPlan(parsed,performanceGrade,attentionLevel,player.dynamic,player.canon);return{match,performanceGrade,attentionLevel,plan};}
function buildEventJudgement(playerId,parsed){const attentionLevel=judgeEventAttention(parsed),player=playerRuntime(playerId),plan=chooseEventOutputPlan(parsed,attentionLevel,player.dynamic,player.canon);return{attentionLevel,plan};}
function charPromptList(raw){return getRelevantCharacters(raw,8);}
function overrideTime(parsed,b={}){const label=String(b.timeLabel||parsed.timeLabel||'').trim()||null;let minutes=b.worldTimeMinutes===null||b.worldTimeMinutes===''||b.worldTimeMinutes===undefined?parsed.worldTimeMinutes:Number(b.worldTimeMinutes);if(!Number.isFinite(minutes))minutes=timeLabelToMinutes(label);parsed.timeLabel=label;parsed.worldTimeMinutes=Number.isFinite(minutes)?minutes:null;return parsed;}
function sourceContextText(type,parsed){return `${type==='game'?formatGameForPrompt(parsed):formatEventForPrompt(parsed)}\n발생 시점: ${parsed.date||'날짜 미제공'} ${parsed.timeLabel||'시간 미지정'}`;}

async function maybeAutoLine(playerId,sourceContext,attentionLevel,{sourceDate=null,sourceType=null}={}){
  const cfg=getRuntimeConfig();if(attentionLevel<2||!cfg.lineEnabled||!cfg.lineApiKey)return[];
  let chars=getRelevantCharacters(sourceContext,4).filter(c=>c.messagingEnabled);
  if(!chars.length&&attentionLevel>=3)chars=listCharacters().filter(c=>c.messagingEnabled&&/(가족|쌍둥이|누나|형|동생|부모|친구)/.test(c.relation||'')).slice(0,1);
  const player=playerRuntime(playerId),sent=[];
  for(const c of chars.slice(0,2)){
    try{
      const recent=getConversation(playerId,c.id,18);
      if(recent.slice(-6).some(m=>m.meta?.auto&&m.meta?.sourceDate===sourceDate))continue;
      const d=await generateAutoLineConversation({playerCanon:player.canon,character:c,sourceContext,recentMessages:recent,mode:cfg.lineMode});
      if(!d.send||!Array.isArray(d.messages)||!d.messages.length)continue;
      let unreadSet=false;
      for(const x of d.messages.slice(0,cfg.lineMode==='auto'?12:1)){
        if(!x?.message?.trim())continue;
        const sender=x.sender==='player'?'player':'character';const unread=sender==='character'&&!unreadSet;if(unread)unreadSet=true;
        addMessage(playerId,c.id,sender,x.message,{unread,meta:{auto:true,autoGenerated:true,reason:d.reason||null,sourceDate,sourceType}});
      }
      sent.push({characterId:c.id,characterName:c.displayName||c.name});
    }catch{/* LINE failure never breaks game/event save */}
  }
  return sent;
}

async function generateGameBundle(playerId,gameId,parsed,judgement,{interviewTranscript=null}={}){
  const season=Number(String(parsed.date||'').slice(0,4))||playerRuntime(playerId).dynamic.season;
  const seasonStats=getSeasonStats(playerId,season),player=playerRuntime(playerId);let bundle={articles:[],communities:[],note:null},generationError=null;
  const temporalContext=getTemporalEventContext(playerId,parsed.date,parsed.worldTimeMinutes);
  if(getRuntimeConfig().mainApiKey&&judgement.attentionLevel>0){
    try{const recentMemory=getRecentContentMemory(playerId,3,{type:'game',id:gameId});const summary=formatGameForPrompt(parsed);bundle=await generateGameContent({gameSummary:summary,seasonStats,plan:judgement.plan,recentMemory,playerDynamic:player.dynamic,playerCanon:player.canon,characters:charPromptList(`${summary} ${JSON.stringify(temporalContext)}`),temporalContext,officialInterview:interviewTranscript||[]});}
    catch(e){generationError=e.message;bundle.note='경기는 저장됐지만 Gemini 콘텐츠 생성에 실패했습니다.';}
  }else if(!getRuntimeConfig().mainApiKey)bundle.note='메인 Gemini API 키 미설정: 경기와 누적 기록만 저장했습니다.';
  saveGeneratedOutput(gameId,judgement.plan,bundle);saveCommunityMemory(gameId,buildMemorySummary(parsed,judgement.plan,bundle));clearGameOutputStale(gameId);return{bundle,generationError,temporalContext};
}
async function generateEventBundle(playerId,eventId,parsed,judgement){
  const season=Number(String(parsed.date||'').slice(0,4))||playerRuntime(playerId).dynamic.season;
  let bundle={articles:[],communities:[],note:null},generationError=null;const temporalContext=getTemporalEventContext(playerId,parsed.date,parsed.worldTimeMinutes);
  if(getRuntimeConfig().mainApiKey&&judgement.attentionLevel>0){try{const recentMemory=getRecentContentMemory(playerId,3,{type:'event',id:eventId}),p=playerRuntime(playerId);bundle=await generateEventContent({eventSummary:formatEventForPrompt(parsed),seasonStats:getSeasonStats(playerId,season),plan:judgement.plan,recentMemory,playerDynamic:p.dynamic,playerCanon:p.canon,characters:charPromptList(JSON.stringify(parsed)),temporalContext});}catch(e){generationError=e.message;bundle.note='이벤트는 저장됐지만 Gemini 콘텐츠 생성에 실패했습니다.';}}
  else if(!getRuntimeConfig().mainApiKey)bundle.note='메인 Gemini API 키 미설정: 이벤트와 상태만 저장했습니다.';
  saveEventGeneratedOutput(eventId,judgement.plan,bundle);saveEventMemory(eventId,buildEventMemorySummary(parsed,judgement.plan,bundle));clearEventOutputStale(eventId);return{bundle,generationError};
}
async function beginInterview(playerId,gameId,maxQuestions){const s=createInterview(playerId,gameId,maxQuestions);try{const game=getGame(gameId),q=await generateInterviewQuestion({playerCanon:playerRuntime(playerId).canon,gameContext:formatGameForPrompt(game.parsed),transcript:[],questionIndex:1,maxQuestions:s.maxQuestions});return updateInterview(s.id,{currentQuestion:q.question});}catch(e){updateInterview(s.id,{status:'error'});throw e;}}
async function beginAutoInterview(playerId,gameId,maxQuestions){const s=createInterview(playerId,gameId,maxQuestions);try{const game=getGame(gameId),out=await generateFullInterview({playerCanon:playerRuntime(playerId).canon,gameContext:formatGameForPrompt(game.parsed),maxQuestions:s.maxQuestions});return updateInterview(s.id,{status:'completed',currentQuestion:null,transcript:out.transcript||[]});}catch(e){updateInterview(s.id,{status:'error'});throw e;}}

async function handleApi(req,res,url){
  if(req.method==='GET'&&url.pathname==='/api/state'){
    const id=getActivePlayerId();if(!id)return json(res,200,{needsOnboarding:true,runtime:runtime(),settings:getPublicApiSettings(),saveReader:getSaveReaderStatus()});
    const p=playerRuntime(id);return json(res,200,{needsOnboarding:false,player:{canon:p.canon,dynamic:p.dynamic,sourceDocuments:p.sourceDocuments||[]},seasonStats:getSeasonStats(id),seasons:listSeasons(id),games:listGames(id,1600).map(g=>({id:g.id,date:g.date,timeLabel:g.time_label,worldTimeMinutes:g.world_time_minutes,opponent:g.opponent,homeAway:g.home_away,teamScore:g.team_score,opponentScore:g.opponent_score,result:g.result,performanceGrade:g.performance_grade,attentionLevel:g.attention_level,mode:g.mode,batting:g.parsed?.batting,pitching:g.parsed?.pitching,hasOutput:Boolean(g.bundle),outputStale:Boolean(g.output_stale),interviewRequired:g.interview_required,interviews:listInterviewsForGame(g.id)})),events:listEvents(id,1600).map(e=>({id:e.id,date:e.date,timeLabel:e.time_label,worldTimeMinutes:e.world_time_minutes,category:e.category,summary:e.summary,attentionLevel:e.attention_level,lifecycle:e.lifecycle,hasOutput:Boolean(e.bundle),outputStale:Boolean(e.output_stale)})),schedules:listScheduleEntries(id,800),timeline:listTimelineDays(id,800),characters:listCharacters(),lineUnread:unreadMessageCount(id),runtime:runtime(),saveReader:getSaveReaderStatus()});
  }

  if(req.method==='GET'&&url.pathname==='/api/settings')return json(res,200,getPublicApiSettings());
  if(req.method==='PATCH'&&url.pathname==='/api/settings'){const b=await readBody(req);return json(res,200,saveApiSettings(b));}
  if(req.method==='DELETE'&&url.pathname==='/api/settings/api')return json(res,200,clearApiSettings());
  if(req.method==='POST'&&url.pathname==='/api/settings/test'){const b=await readBody(req),kind=['main','interview','line'].includes(b.kind)?b.kind:'main';try{return json(res,200,await testGeminiConnection(kind));}catch(e){return json(res,400,{error:e.message});}}

  if(req.method==='POST'&&url.pathname==='/api/onboarding/analyze'){
    const b=await readBody(req);if(!getRuntimeConfig().mainApiKey)return json(res,400,{error:'먼저 메인 Gemini API를 설정해 주세요.'});
    try{const basic=b.basic||{},analysis=await analyzeCharacterSetup({basic,documents:Array.isArray(b.documents)?b.documents:[]});analysis.player={...(analysis.player||{}),name:basic.name||analysis.player?.name,team:basic.team||analysis.player?.team,mainPosition:basic.mainPosition||analysis.player?.mainPosition,positions:Array.isArray(basic.positions)&&basic.positions.length?basic.positions:(analysis.player?.positions||[]),reactionScopes:basic.reactionScopes||analysis.player?.reactionScopes};return json(res,200,{analysis});}catch(e){return json(res,400,{error:`캐릭터 설정 분석 실패: ${e.message}`});}
  }
  if(req.method==='POST'&&url.pathname==='/api/onboarding/complete'){
    const b=await readBody(req),analysis=b.analysis||{},player={...(analysis.player||{})};player.photoDataUrl=String(b.photoDataUrl||'').startsWith('data:image/')?b.photoDataUrl:null;
    try{const r=startFreshSimulation({canon:player,characters:Array.isArray(analysis.characters)?analysis.characters:[],sourceDocuments:Array.isArray(b.documents)?b.documents:[]});resetSaveReaderLinkage({preservePath:true});return json(res,201,{ok:true,backup:r.backup,player:r.player});}catch(e){return json(res,400,{error:e.message});}
  }

  if(req.method==='PATCH'&&url.pathname==='/api/player'){
    const id=requirePlayer(res);if(!id)return;const b=await readBody(req);const canonPatch={...b};delete canonPatch.pitchingRole;delete canonPatch.season;delete canonPatch.seasons;
    if(Object.prototype.hasOwnProperty.call(b,'positions'))canonPatch.positions=Array.isArray(b.positions)?b.positions:String(b.positions||'').split(/[,/\n]+/).map(x=>x.trim()).filter(Boolean);
    if(Object.prototype.hasOwnProperty.call(b,'aiKeywords'))canonPatch.aiKeywords=Array.isArray(b.aiKeywords)?b.aiKeywords:String(b.aiKeywords||'').split(/[,\n]+/).map(x=>x.trim()).filter(Boolean);
    const canon=updatePlayerCanon(id,canonPatch);
    if(Object.prototype.hasOwnProperty.call(b,'pitchingRole')||Object.prototype.hasOwnProperty.call(b,'season'))updatePlayerDynamic(id,d=>({...d,pitchingRole:Object.prototype.hasOwnProperty.call(b,'pitchingRole')?(['미지정','선발투수','중간계투','셋업맨','마무리투수'].includes(b.pitchingRole)?b.pitchingRole:'미지정'):d.pitchingRole,season:Object.prototype.hasOwnProperty.call(b,'season')&&listSeasons(id).includes(Number(b.season))?Number(b.season):d.season}));
    return json(res,200,{canon,dynamic:playerRuntime(id).dynamic});
  }
  if(req.method==='GET'&&url.pathname==='/api/stats'){const id=requirePlayer(res);if(!id)return;const season=Number(url.searchParams.get('season'))||playerRuntime(id).dynamic.season;return json(res,200,{season,stats:getSeasonStats(id,season)});}
  if(req.method==='POST'&&url.pathname==='/api/seasons'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{return json(res,201,{seasons:addSeason(id,b.year),currentSeason:Number(b.year)});}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/reset'){const id=requirePlayer(res);if(!id)return;resetSimulation({keepPlayer:true,keepCharacters:true});resetSaveReaderLinkage({preservePath:true});return json(res,200,{ok:true,saveReader:getSaveReaderStatus()});}

  if(req.method==='GET'&&url.pathname==='/api/save-reader'){return json(res,200,{status:getSaveReaderStatus(),pending:listPending()});}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/select-folder'){const id=requirePlayer(res);if(!id)return;try{const picked=await chooseSaveFolder();if(!picked)return json(res,200,{cancelled:true,status:getSaveReaderStatus()});const status=setSavePath(picked.savePath);return json(res,200,{...picked,status});}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/update'){const id=requirePlayer(res);if(!id)return;try{const buf=await readRawBody(req);const filename=decodeURIComponent(String(req.headers['x-file-name']||'SaveReader.zip'));return json(res,200,await installSaveReaderBundle(buf,filename));}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='PATCH'&&url.pathname==='/api/save-reader/path'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{return json(res,200,{status:setSavePath(b.savePath)});}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/inspect'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{if(Object.prototype.hasOwnProperty.call(b,'savePath'))setSavePath(b.savePath);return json(res,200,await inspectSave(undefined,playerRuntime(id).canon));}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/link'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{const linked=await linkCurrentSave({canon:playerRuntime(id).canon,force:Boolean(b.force),importSeasonToDate:Boolean(b.importSeasonToDate)});if(b.importSeasonToDate&&linked.seasonStatsConfirmed&&linked.seasonYear){setReaderSeasonStats(id,linked.seasonYear,linked.seasonStatsConfirmed,linked.inspect?.display?.lastCompletedGameDate||linked.inspect?.display?.date||null);}return json(res,200,linked);}catch(e){if(e.code==='MISMATCH')return json(res,409,{error:e.message,inspect:e.inspect});return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/pause'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{return json(res,200,{status:pauseSaveReader(Boolean(b.paused))});}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/unlink'){const id=requirePlayer(res);if(!id)return;try{return json(res,200,{status:unlinkSaveReader()});}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/rebaseline'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{return json(res,200,{status:await rebaselineCurrentSave({canon:playerRuntime(id).canon,force:Boolean(b.force)})});}catch(e){return json(res,400,{error:e.message});}}
  if(req.method==='POST'&&url.pathname==='/api/save-reader/scan'){const id=requirePlayer(res);if(!id)return;try{return json(res,200,{status:await manualScanNow()});}catch(e){return json(res,400,{error:e.message});}}
  const srPending=url.pathname.match(/^\/api\/save-reader\/pending\/(\d+)$/);
  if(req.method==='GET'&&srPending){const id=requirePlayer(res);if(!id)return;const pending=getPending(Number(srPending[1]));if(!pending)return json(res,404,{error:'미등록 경기 항목을 찾지 못했습니다.'});if(pending.kind==='game'){const parsed=sanitizeParsedGame(pending.parsed),j=buildRuntimeJudgement(id,parsed),missing=Array.isArray(pending.unavailable)?pending.unavailable:[];return json(res,200,{pending:{...pending,parsed},preview:{performanceGrade:j.performanceGrade,attentionLevel:j.attentionLevel,willCorrectExisting:Boolean(j.match),outputPlan:j.plan,temporalWarning:null},warning:`SaveReader ${pending.readerVersion||getSaveReaderStatus().readerVersion} · schema ${pending.schemaVersion||1} 검증 결과입니다. confirmed 값만 자동입력합니다.${missing.length?` 현재 자동입력 제외: ${missing.join(' · ')}.`:''}`});}return json(res,200,{pending});}
  const srAck=url.pathname.match(/^\/api\/save-reader\/pending\/(\d+)\/ack$/);if(req.method==='POST'&&srAck){const id=requirePlayer(res);if(!id)return;try{return json(res,200,{pending:acknowledgePending(Number(srAck[1]))});}catch(e){return json(res,404,{error:e.message});}}

  if(req.method==='GET'&&url.pathname==='/api/characters')return json(res,200,{characters:listCharacters()});
  if(req.method==='POST'&&url.pathname==='/api/characters'){const b=await readBody(req);b.keywords=Array.isArray(b.keywords)?b.keywords:String(b.keywords||'').split(/[,\n]+/).map(x=>x.trim()).filter(Boolean);return json(res,201,{character:saveCharacter(b)});}
  const charMatch=url.pathname.match(/^\/api\/characters\/(char-\d+)$/);
  if(charMatch&&req.method==='PATCH'){const old=getCharacter(charMatch[1]);if(!old)return json(res,404,{error:'캐릭터를 찾지 못했습니다.'});const b=await readBody(req);b.keywords=Array.isArray(b.keywords)?b.keywords:String(b.keywords||'').split(/[,\n]+/).map(x=>x.trim()).filter(Boolean);return json(res,200,{character:saveCharacter({...old,...b,id:old.id})});}
  if(charMatch&&req.method==='DELETE')return json(res,deleteCharacter(charMatch[1])?200:404,{ok:true});

  if(req.method==='GET'&&url.pathname==='/api/line/threads'){const id=requirePlayer(res);if(!id)return;const cfg=getRuntimeConfig();if(!cfg.lineEnabled)return json(res,403,{error:'LINE 기능이 꺼져 있습니다. 설정에서 LINE 사용을 켜 주세요.'});return json(res,200,{threads:listConversationThreads(id),unread:unreadMessageCount(id),mode:cfg.lineMode});}
  const lineMatch=url.pathname.match(/^\/api\/line\/(char-\d+)$/);
  if(lineMatch&&req.method==='GET'){const id=requirePlayer(res);if(!id)return;if(!getRuntimeConfig().lineEnabled)return json(res,403,{error:'LINE 기능이 꺼져 있습니다.'});const c=getCharacter(lineMatch[1]);if(!c)return json(res,404,{error:'캐릭터를 찾지 못했습니다.'});markConversationRead(id,c.id);return json(res,200,{character:c,messages:getConversation(id,c.id,160),unread:unreadMessageCount(id),mode:getRuntimeConfig().lineMode});}
  if(lineMatch&&req.method==='POST'){const id=requirePlayer(res);if(!id)return;const cfg=getRuntimeConfig();if(!cfg.lineEnabled)return json(res,403,{error:'LINE 기능이 꺼져 있습니다.'});const c=getCharacter(lineMatch[1]);if(!c)return json(res,404,{error:'캐릭터를 찾지 못했습니다.'});const b=await readBody(req),text=String(b.message||'').trim();if(!text)return json(res,400,{error:'메시지가 비어 있습니다.'});if(!cfg.lineApiKey)return json(res,400,{error:'LINE 답장을 생성하려면 LINE 전용 Gemini API 키가 필요합니다.'});let reply;try{reply=await generateLineReply({playerCanon:playerRuntime(id).canon,character:c,recentMessages:getConversation(id,c.id,16),userMessage:text});}catch(e){return json(res,400,{error:`LINE Gemini 답장 생성에 실패했습니다: ${e.message}`});}const sourceDate=String(b.sourceDate||'').trim()||listTimelineDays(id,1)?.[0]?.date||null;addMessage(id,c.id,'player',text,{meta:{direct:true,sourceDate}});addMessage(id,c.id,'character',reply,{unread:false,meta:{direct:true,sourceDate}});return json(res,200,{reply,messages:getConversation(id,c.id,160)});}

  if(req.method==='POST'&&url.pathname==='/api/schedule'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req);try{const entry=saveScheduleEntry(id,b);if(b.saveReaderPendingId){const sr=getPending(Number(b.saveReaderPendingId));if(sr?.seasonStatsConfirmed){const season=Number(sr.seasonStatsConfirmed.season)||Number(String(entry.date||'').slice(0,4));setReaderSeasonStats(id,season,sr.seasonStatsConfirmed,entry.date);}completePending(Number(b.saveReaderPendingId));}return json(res,201,{entry,saveReader:getSaveReaderStatus()});}catch(e){return json(res,400,{error:e.message});}}
  const sd=url.pathname.match(/^\/api\/schedule\/(\d+)$/);if(req.method==='DELETE'&&sd)return deleteScheduleEntry(Number(sd[1]))?json(res,200,{ok:true}):json(res,404,{error:'일정 항목을 찾지 못했습니다.'});
  const del=url.pathname.match(/^\/api\/(games|events)\/(\d+)$/);if(req.method==='DELETE'&&del){const ok=del[1]==='games'?deleteGame(Number(del[2])):deleteEvent(Number(del[2]));return ok?json(res,200,{ok:true}):json(res,404,{error:'항목을 찾지 못했습니다.'});}
  const gm=url.pathname.match(/^\/api\/games\/(\d+)$/);
  if(req.method==='GET'&&gm){const g=getGame(Number(gm[1]));return g?json(res,200,{game:g,interviews:listInterviewsForGame(g.id)}):json(res,404,{error:'경기를 찾지 못했습니다.'});}
  if(req.method==='PATCH'&&gm){const id=requirePlayer(res);if(!id)return;const old=getGame(Number(gm[1]));if(!old||old.player_id!==id)return json(res,404,{error:'경기를 찾지 못했습니다.'});const b=await readBody(req),parsed=sanitizeParsedGame({...old.parsed,...(b.parsed||{})});const j=buildRuntimeJudgement(id,parsed);const g=updateGameRecord(old.id,{parsed,performanceGrade:j.performanceGrade,attentionLevel:j.attentionLevel,markOutputStale:!b.regenerate});let generationError=null;if(b.regenerate)({generationError}=await generateGameBundle(id,old.id,parsed,j));return json(res,200,{game:getGame(old.id),seasonStats:getSeasonStats(id,Number(String(parsed.date||'').slice(0,4))||null),regenerated:Boolean(b.regenerate),generationError});}
  const em=url.pathname.match(/^\/api\/events\/(\d+)$/);
  if(req.method==='GET'&&em){const e=getEvent(Number(em[1]));return e?json(res,200,{event:e}):json(res,404,{error:'이벤트를 찾지 못했습니다.'});}
  if(req.method==='PATCH'&&em){const id=requirePlayer(res);if(!id)return;const old=getEvent(Number(em[1]));if(!old||old.player_id!==id)return json(res,404,{error:'이벤트를 찾지 못했습니다.'});const b=await readBody(req),parsed=sanitizeParsedEvent({...old.parsed,...(b.parsed||{})});const j=buildEventJudgement(id,parsed);updateEventRecord(old.id,{parsed,attentionLevel:j.attentionLevel,plan:j.plan,markOutputStale:!b.regenerate});let generationError=null;if(b.regenerate)({generationError}=await generateEventBundle(id,old.id,parsed,j));return json(res,200,{event:getEvent(old.id),regenerated:Boolean(b.regenerate),generationError});}
  const dm=url.pathname.match(/^\/api\/days\/(\d{4}-\d{2}-\d{2})$/);if(req.method==='GET'&&dm){const id=requirePlayer(res);if(!id)return;const entries=getDayEntries(id,dm[1]).map(x=>x.type==='game'?{...x,data:{...x.data,_interviews:listInterviewsForGame(x.id)}}:x);return json(res,200,{date:dm[1],entries});}

  if(req.method==='POST'&&url.pathname==='/api/parse'){
    const id=requirePlayer(res);if(!id)return;const b=await readBody(req),raw=String(b.rawInput||'').trim();if(!raw)return json(res,400,{error:'경기 입력이 비어 있습니다.'});if(isLikelySpecialEventInput(raw))return json(res,422,{error:'이 입력은 경기보다 이벤트 상황에 가깝습니다. 이벤트 입력을 사용해 주세요.'});let parsed,warning=null;const p=playerRuntime(id);if(getRuntimeConfig().mainApiKey){try{parsed=await parseGameWithGemini(raw,p.canon);}catch(e){parsed=offlineParseGameInput(raw);warning=`Gemini 파싱 실패로 오프라인 파서를 사용했습니다: ${e.message}`;}}else{parsed=offlineParseGameInput(raw);warning='메인 Gemini API 키가 없어 오프라인 파서를 사용했습니다.';}parsed=overrideTime(parsed,b);const j=buildRuntimeJudgement(id,parsed);const sameDayEvents=parsed.date?listEvents(id,300).filter(e=>e.date===parsed.date).length:0;const temporalWarning=sameDayEvents&&parsed.worldTimeMinutes==null?'같은 날 이벤트가 있습니다. 선행 이벤트를 정확히 반영하려면 경기 시점을 선택해 주세요.':null;return json(res,200,{parsed,preview:{performanceGrade:j.performanceGrade,attentionLevel:j.attentionLevel,willCorrectExisting:Boolean(j.match),outputPlan:j.plan,temporalWarning},warning});
  }
  if(req.method==='POST'&&url.pathname==='/api/commit'){
    const id=requirePlayer(res);if(!id)return;const b=await readBody(req),raw=String(b.rawInput||'').trim();let parsed=overrideTime(sanitizeParsedGame(b.parsed||{}),b);if(!raw)return json(res,400,{error:'원본 경기 입력이 필요합니다.'});if(isLikelySpecialEventInput(raw))return json(res,422,{error:'특별 이벤트는 경기로 저장할 수 없습니다.'});
    let interviewMode=['none','manual','auto'].includes(String(b.interviewMode||''))?String(b.interviewMode):Boolean(b.interviewRequested)?'manual':'none';
    if(parsed.specialTriggers.includes('hero_interview')&&interviewMode==='none')interviewMode='manual';
    const requested=interviewMode!=='none';if(requested&&!getRuntimeConfig().interviewApiKey)return json(res,400,{error:'히어로 인터뷰를 사용하려면 인터뷰 Gemini API 키를 먼저 설정해 주세요.'});if(requested&&!parsed.specialTriggers.includes('hero_interview'))parsed.specialTriggers.push('hero_interview');const questions=Math.max(2,Math.min(3,Number(b.interviewQuestions)||3));const j=buildRuntimeJudgement(id,parsed),saved=saveGame(id,raw,parsed,j.performanceGrade,j.attentionLevel,{interviewRequired:requested,interviewQuestions:questions});if(b.saveReaderPendingId){const sr=getPending(Number(b.saveReaderPendingId));if(sr?.seasonStatsConfirmed){const season=Number(sr.seasonStatsConfirmed.season)||Number(String(parsed.date||'').slice(0,4));setReaderSeasonStats(id,season,sr.seasonStatsConfirmed,parsed.date);}completePending(Number(b.saveReaderPendingId));}let generationError=null,interview=null,interviewStartError=null;
    if(interviewMode==='manual'){
      saveGeneratedOutput(saved.gameId,j.plan,{articles:[],communities:[],note:'히어로 인터뷰 완료 후 기사·커뮤니티가 생성됩니다.'});saveCommunityMemory(saved.gameId,buildMemorySummary(parsed,j.plan,{articles:[],communities:[]}));try{interview=await beginInterview(id,saved.gameId,questions);}catch(e){interviewStartError=e.message;}
    }else if(interviewMode==='auto'){
      saveGeneratedOutput(saved.gameId,j.plan,{articles:[],communities:[],note:'자동 히어로 인터뷰를 생성한 뒤 기사·커뮤니티에 반영합니다.'});saveCommunityMemory(saved.gameId,buildMemorySummary(parsed,j.plan,{articles:[],communities:[]}));try{interview=await beginAutoInterview(id,saved.gameId,questions);({generationError}=await generateGameBundle(id,saved.gameId,parsed,j,{interviewTranscript:interview.transcript||[]}));}catch(e){interviewStartError=e.message;if(!interview){({generationError}=await generateGameBundle(id,saved.gameId,parsed,j));}}
    }else({generationError}=await generateGameBundle(id,saved.gameId,parsed,j));
    const autoMessages=await maybeAutoLine(id,sourceContextText('game',parsed),j.attentionLevel,{sourceDate:parsed.date,sourceType:'game'});return json(res,200,{game:getGame(saved.gameId),mode:saved.mode,seasonStats:getSeasonStats(id),generationError,interviewRequired:requested,interviewMode,interview,interviewStartError,autoMessages});
  }
  if(req.method==='POST'&&url.pathname==='/api/events/parse'){
    const id=requirePlayer(res);if(!id)return;const b=await readBody(req),raw=String(b.rawInput||'').trim();if(!raw)return json(res,400,{error:'이벤트 입력이 비어 있습니다.'});if(isLikelyGameInput(raw))return json(res,422,{error:'이 입력은 특별 이벤트보다 경기 원본에 가깝습니다. 경기 입력을 사용해 주세요.'});let parsed,warning=null;const p=playerRuntime(id),chars=charPromptList(raw);if(getRuntimeConfig().mainApiKey){try{parsed=await parseEventWithGemini(raw,p.canon,chars);}catch(e){parsed=offlineParseEventInput(raw);warning=`Gemini 이벤트 파싱 실패로 오프라인 파서를 사용했습니다: ${e.message}`;}}else{parsed=offlineParseEventInput(raw);warning='메인 Gemini API 키가 없어 오프라인 이벤트 파서를 사용했습니다.';}parsed=overrideTime(parsed,b);const j=buildEventJudgement(id,parsed);return json(res,200,{parsed,preview:{attentionLevel:j.attentionLevel,outputPlan:j.plan,lifecycle:inferEventLifecycle(parsed)},warning});
  }
  if(req.method==='POST'&&url.pathname==='/api/events/commit'){
    const id=requirePlayer(res);if(!id)return;const b=await readBody(req),raw=String(b.rawInput||'').trim();let parsed=overrideTime(sanitizeParsedEvent(b.parsed||{}),b);if(!raw)return json(res,400,{error:'원본 이벤트 입력이 필요합니다.'});if(isLikelyGameInput(raw))return json(res,422,{error:'경기 원본은 이벤트로 저장할 수 없습니다.'});const j=buildEventJudgement(id,parsed),saved=saveEvent(id,raw,parsed,j.attentionLevel,j.plan);applyEventStateChanges(id,parsed);const {generationError}=await generateEventBundle(id,saved.eventId,parsed,j);const autoMessages=await maybeAutoLine(id,sourceContextText('event',parsed),j.attentionLevel,{sourceDate:parsed.date,sourceType:'event'});return json(res,200,{event:getEvent(saved.eventId),generationError,autoMessages});
  }

  if(req.method==='POST'&&url.pathname==='/api/interviews/start'){const id=requirePlayer(res);if(!id)return;const b=await readBody(req),game=getGame(Number(b.gameId));if(!game||game.player_id!==id)return json(res,404,{error:'경기를 찾지 못했습니다.'});try{return json(res,201,{interview:await beginInterview(id,game.id,b.maxQuestions||game.interview_questions||3)});}catch(e){return json(res,400,{error:e.message});}}
  const im=url.pathname.match(/^\/api\/interviews\/(\d+)\/answer$/);if(im&&req.method==='POST'){const id=requirePlayer(res);if(!id)return;let s=getInterview(Number(im[1]));if(!s||s.player_id!==id)return json(res,404,{error:'인터뷰 세션을 찾지 못했습니다.'});const b=await readBody(req),answer=String(b.answer||'').trim();if(!answer)return json(res,400,{error:'답변을 입력해 주세요.'});const transcript=[...(s.transcript||[]),{question:s.currentQuestion,answer}];if(transcript.length>=s.maxQuestions){s=updateInterview(s.id,{transcript,currentQuestion:null,status:'completed'});const game=getGame(s.game_id),j=buildRuntimeJudgement(id,game.parsed),generated=await generateGameBundle(id,game.id,game.parsed,j,{interviewTranscript:transcript});return json(res,200,{interview:s,completed:true,game:getGame(game.id),generationError:generated.generationError});}try{const q=await generateInterviewQuestion({playerCanon:playerRuntime(id).canon,gameContext:formatGameForPrompt(getGame(s.game_id).parsed),transcript,questionIndex:transcript.length+1,maxQuestions:s.maxQuestions});s=updateInterview(s.id,{transcript,currentQuestion:q.question});return json(res,200,{interview:s,completed:false});}catch(e){return json(res,400,{error:e.message});}}

  return json(res,404,{error:'Not found'});
}

const port=Number(process.env.PORT||3000);
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost');if(url.pathname==='/api/live'&&req.method==='GET')handleLive(req,res);else if(url.pathname.startsWith('/api/'))await handleApi(req,res,url);else serveStatic(req,res);}catch(e){console.error(e);json(res,500,{error:e.message||'서버 오류'});}});
server.listen(port,()=>{const r=runtime(),url=`http://127.0.0.1:${port}`;console.log(`StarPlayer Gemini MVP v0.9.4: ${url}`);console.log(`Main Gemini: ${r.geminiConfigured?'configured':'offline'} / ${r.model}`);console.log(`Interview Gemini: ${r.interviewConfigured?'configured':'offline'} / ${r.interviewModel}`);console.log(`LINE Gemini: ${!r.lineEnabled?'disabled':r.lineConfigured?'configured':'offline'}${r.lineEnabled?` / ${r.lineModel} / ${r.lineMode}`:''}`);console.log('Windows browser auto-open is handled by START_WINDOWS.bat after an actual HTTP readiness check.');});
