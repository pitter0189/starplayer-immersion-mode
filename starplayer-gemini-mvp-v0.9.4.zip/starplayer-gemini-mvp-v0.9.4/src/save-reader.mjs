import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const configDir = path.join(root, 'data', 'config');
const dataDir = path.join(root, 'data', 'save-reader');
const pendingDir = path.join(dataDir, 'pending');
const internalDir = path.join(root, 'internal', 'save-reader');
const manifestPath = path.join(internalDir, 'manifest.json');
const statePath = path.join(configDir, 'save-reader.json');
const CONTRACT_SCHEMA_VERSION = 1;

fs.mkdirSync(configDir, { recursive: true });
fs.mkdirSync(pendingDir, { recursive: true });
fs.mkdirSync(internalDir, { recursive: true });

const TEAM_KO = {
  'Hanshin Tigers':'한신 타이거스','Yokohama DeNA BayStars':'요코하마 DeNA 베이스타스','Yomiuri Giants':'요미우리 자이언츠',
  'Chunichi Dragons':'주니치 드래곤즈','Hiroshima Toyo Carp':'히로시마 도요 카프','Tokyo Yakult Swallows':'도쿄 야쿠르트 스왈로스',
  'Fukuoka SoftBank Hawks':'후쿠오카 소프트뱅크 호크스','Hokkaido Nippon-Ham Fighters':'홋카이도 닛폰햄 파이터즈','ORIX Buffaloes':'오릭스 버팔로스',
  'Tohoku Rakuten Golden Eagles':'도호쿠 라쿠텐 골든이글스','Saitama Seibu Lions':'사이타마 세이부 라이온즈','Chiba Lotte Marines':'치바 롯데 마린스'
};

const FIELD_LABELS = {
  'pitching.pitch_count':'투구 수','pitching.started':'선발 여부','pitching.hold':'홀드','pitching.save':'세이브','pitching.blown_save':'블론세이브','pitching.quality_start_plus':'QS+',
  'batting.plate_appearances':'타석','batting.hbp':'타자 사구','batting.stolen_bases':'도루','batting.grounded_into_double_play':'병살타','batting.errors':'실책','batting.position':'수비 위치'
};

function loadManifest(){
  try{
    const m=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
    return {schemaVersion:Number(m.schemaVersion)||null,readerVersion:String(m.readerVersion||'unknown'),installedAt:m.installedAt||null,active:m.active||{},source:m.source||null,sha256:m.sha256||{},declaredCapabilities:m.declaredCapabilities||{}};
  }catch{
    return {schemaVersion:null,readerVersion:'unknown',installedAt:null,active:{win32:'reader.exe',linux:'reader_linux'},source:null,sha256:{},declaredCapabilities:{}};
  }
}
let readerInfo=loadManifest();

function capabilityCounts(caps={}){const out={confirmed:0,pending:0,unmapped:0,other:0};for(const v of Object.values(caps||{})){if(v==='confirmed')out.confirmed++;else if(v==='pending')out.pending++;else if(v==='unmapped')out.unmapped++;else out.other++;}return out;}
function blankState(savePath='') {
  return {version:4,savePath,linked:false,enabled:false,paused:false,linkedPlayerId:null,linkedPlayerName:null,linkedTeam:null,baselineFile:null,baselineMeta:null,seasonAnchorFile:null,seasonAnchorConfirmed:null,seasonAnchorYear:null,seasonStatsMode:'from-link',latestSeasonStatsConfirmed:null,latestSeasonYear:null,pending:[],nextPendingId:1,lastError:null,lastEvent:null,blockedReason:null,lastCapabilities:null};
}
function legacyNum(v){return typeof v==='number'&&Number.isFinite(v)?v:null;}
function normalizeStoredSeasonAnchor(anchor){
  if(!anchor||typeof anchor!=='object')return null;
  const b=anchor.batting||{},p=anchor.pitching||{};
  // v0.8+ already stores the internal camelCase shape.
  if(Object.prototype.hasOwnProperty.call(b,'atBats')||Object.prototype.hasOwnProperty.call(p,'battersFaced'))return anchor;
  // v0.7.1 stored the raw v1.4 season_stats_confirmed snake_case object.
  return {
    batting:{games:legacyNum(b.games),plateAppearances:legacyNum(b.plate_appearances),atBats:legacyNum(b.at_bats),hits:legacyNum(b.hits),singles:legacyNum(b.singles),doubles:legacyNum(b.doubles),triples:legacyNum(b.triples),homeRuns:legacyNum(b.home_runs),rbi:legacyNum(b.rbi),runs:legacyNum(b.runs),walks:legacyNum(b.walks),hbp:legacyNum(b.hbp),strikeouts:legacyNum(b.strikeouts),stolenBases:legacyNum(b.stolen_bases),groundedIntoDoublePlay:legacyNum(b.grounded_into_double_play),errors:legacyNum(b.errors)},
    pitching:{games:legacyNum(p.appearances),starts:legacyNum(p.starts),outs:legacyNum(p.outs??p.innings_outs),battersFaced:legacyNum(p.batters_faced),pitches:legacyNum(p.pitch_count),hits:legacyNum(p.hits_allowed),homeRuns:legacyNum(p.home_runs_allowed),walks:legacyNum(p.walks),hbp:legacyNum(p.hbp_allowed??p.hbp),strikeouts:legacyNum(p.strikeouts),runs:legacyNum(p.runs),earnedRuns:legacyNum(p.earned_runs),wins:legacyNum(p.wins),losses:legacyNum(p.losses),holds:legacyNum(p.holds),saves:legacyNum(p.saves),blownSaves:legacyNum(p.blown_saves),qs:legacyNum(p.quality_starts),qsPlus:legacyNum(p.quality_start_plus)}
  };
}
function loadState(){
  try{
    if(!fs.existsSync(statePath))return blankState();
    const raw=JSON.parse(fs.readFileSync(statePath,'utf8'))||{};
    const migrated={...blankState(raw.savePath||''),...raw,version:4,pending:Array.isArray(raw.pending)?raw.pending:[]};
    if(!['from-link','full-season'].includes(migrated.seasonStatsMode))migrated.seasonStatsMode='from-link';
    migrated.seasonAnchorConfirmed=normalizeStoredSeasonAnchor(raw.seasonAnchorConfirmed);
    // v0.7.1 did not retain the original season-anchor DAT. Keep its known totals,
    // and baseline any newly-confirmed fields at the first v0.8+ observation instead.
    if(!migrated.seasonAnchorFile||!fs.existsSync(migrated.seasonAnchorFile||''))migrated.seasonAnchorFile=null;
    return migrated;
  }catch{return blankState();}
}
let state=loadState();
let watcherPath=null;
let watchTimer=null;
let processing=false;
let notifier=()=>{};
function persist(){fs.writeFileSync(`${statePath}.tmp`,JSON.stringify(state,null,2),'utf8');fs.renameSync(`${statePath}.tmp`,statePath);}
function publicState(){
  const caps=state.lastCapabilities||readerInfo.declaredCapabilities||{};
  return {readerVersion:readerInfo.readerVersion,schemaVersion:readerInfo.schemaVersion,readerInstalledAt:readerInfo.installedAt,readerSource:readerInfo.source,capabilityCounts:capabilityCounts(caps),capabilities:caps,
    savePath:state.savePath,linked:state.linked,enabled:state.enabled,paused:state.paused,linkedPlayerId:state.linkedPlayerId,linkedPlayerName:state.linkedPlayerName,linkedTeam:state.linkedTeam,baselineMeta:state.baselineMeta,seasonStatsMode:state.seasonStatsMode,
    pendingCount:state.pending.length,pending:state.pending.map(x=>({id:x.id,kind:x.kind,date:x.date,opponent:x.opponent,teamScore:x.teamScore,opponentScore:x.opponentScore,result:x.result,detectedAt:x.detectedAt,acknowledged:Boolean(x.acknowledged),summary:x.summary,readerVersion:x.readerVersion})),
    lastError:state.lastError,lastEvent:state.lastEvent,blockedReason:state.blockedReason,status:!state.linked?'unlinked':state.paused?'paused':state.blockedReason?'blocked':state.enabled?'watching':'linked'};
}
export function getSaveReaderStatus(){return publicState();}
export function setSaveReaderNotifier(fn){notifier=typeof fn==='function'?fn:()=>{};}
function emit(type,payload={}){try{notifier(type,{...payload,status:publicState()});}catch{}}

function readerBinary(custom=null){
  if(custom)return custom;
  readerInfo=loadManifest();
  const rel=process.platform==='win32'?(readerInfo.active?.win32||'reader.exe'):process.platform==='linux'?(readerInfo.active?.linux||'reader_linux'):null;
  if(!rel)throw new Error('자동 기록판독기는 현재 Windows/Linux 실행을 기준으로 제공합니다.');
  const file=path.resolve(internalDir,rel);
  if(!file.startsWith(internalDir))throw new Error('SaveReader 실행 경로가 올바르지 않습니다.');
  return file;
}
function spawnCollect(bin,args,{timeout=20000}={}){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='';let settled=false;const done=(fn,v)=>{if(settled)return;settled=true;clearTimeout(timer);fn(v)};const timer=setTimeout(()=>{try{p.kill();}catch{}done(reject,new Error('SaveReader 응답 시간이 초과됐습니다.'));},timeout);p.stdout?.on('data',c=>out+=c);p.stderr?.on('data',c=>err+=c);p.on('error',e=>done(reject,e));p.on('close',code=>{if(code!==0)return done(reject,new Error((err||`프로세스 종료 코드 ${code}`).trim()));done(resolve,{stdout:out,stderr:err});});});}
async function runReader(args,customBinary=null){const bin=readerBinary(customBinary);if(!fs.existsSync(bin))throw new Error(`SaveReader 실행 파일을 찾지 못했습니다: ${path.basename(bin)}`);if(process.platform!=='win32')try{fs.chmodSync(bin,0o755);}catch{}const {stdout}=await spawnCollect(bin,args);let parsed;try{parsed=JSON.parse(stdout);}catch(e){throw new Error(`SaveReader JSON 판독 실패: ${e.message}`);}return parsed;}
function oneSnapshot(v){return Array.isArray(v)?v[0]:v;}
function validateContractOutput(raw,{compare=false}={}){const o=oneSnapshot(raw);if(!o||typeof o!=='object')throw new Error('SaveReader 출력이 JSON 객체가 아닙니다.');if(Number(o.schema_version)!==CONTRACT_SCHEMA_VERSION)throw new Error(`지원하지 않는 SaveReader schema_version입니다. 필요: ${CONTRACT_SCHEMA_VERSION}, 감지: ${o.schema_version??'없음'}`);if(!o.reader_version)throw new Error('SaveReader reader_version을 확인할 수 없습니다.');if(!o.player||!o.game||!o.batting||!o.pitching||!o.season||!o.capabilities)throw new Error('SaveReader 고정 스키마 필수 섹션이 없습니다.');if(compare&&o.verification?.new_game_log_count==null)throw new Error('비교 결과에 new_game_log_count가 없습니다.');return o;}
function field(node,key){const v=node?.[key];return v&&v.status==='confirmed'?v.value:null;}
function status(node,key){return node?.[key]?.status||'unmapped';}
function boolField(node,key){const v=field(node,key);return typeof v==='boolean'?v:null;}
function numField(node,key){const v=field(node,key);return typeof v==='number'&&Number.isFinite(v)?v:null;}
function strField(node,key){const v=field(node,key);return typeof v==='string'&&v.trim()?v:null;}
function normalize(s){return String(s||'').toLowerCase().replace(/[\s·・._-]+/g,'');}
function teamMatches(canonTeam,readerTeam){const a=normalize(canonTeam),b=normalize(readerTeam),ko=normalize(TEAM_KO[readerTeam]||'');return Boolean(a&&b&&(a===b||a===ko||a.includes(b)||b.includes(a)||a.includes(ko)||ko.includes(a)));}
function resolveSaveFilePath(value){
  const p=String(value||'').trim();if(!p)return'';
  try{if(fs.existsSync(p)&&fs.statSync(p).isDirectory()){const entry=fs.readdirSync(p).find(x=>x.toLowerCase()==='starplayer.dat');if(!entry)throw new Error('선택한 폴더에서 StarPlayer.dat를 찾지 못했습니다.');return path.join(p,entry);}}catch(e){if(e?.message?.includes('StarPlayer.dat'))throw e;}
  return p;
}
function yearFromOutput(o){const d=strField(o?.game,'date');return Number(String(d||'').slice(0,4))||null;}
function snapshotMeta(snap){const bat=snap?.season?.batting||{},pit=snap?.season?.pitching||{},d=strField(snap?.game,'date');return {saveDate:d||null,lastCompletedGameDate:d||null,playerGameLogCount:null,battingGames:numField(bat,'games'),pitchingAppearances:numField(pit,'appearances'),pitchingStarts:numField(pit,'starts')};}

function extractConfirmedSeason(snap){
  const sb=snap?.season?.batting||{},sp=snap?.season?.pitching||{};
  return {batting:{games:numField(sb,'games'),plateAppearances:numField(sb,'plate_appearances'),atBats:numField(sb,'at_bats'),hits:numField(sb,'hits'),singles:numField(sb,'singles'),doubles:numField(sb,'doubles'),triples:numField(sb,'triples'),homeRuns:numField(sb,'home_runs'),rbi:numField(sb,'rbi'),runs:numField(sb,'runs'),walks:numField(sb,'walks'),hbp:numField(sb,'hbp'),strikeouts:numField(sb,'strikeouts'),stolenBases:numField(sb,'stolen_bases'),groundedIntoDoublePlay:numField(sb,'grounded_into_double_play'),errors:numField(sb,'errors')},
    pitching:{games:numField(sp,'appearances'),starts:numField(sp,'starts'),outs:numField(sp,'innings_outs'),battersFaced:numField(sp,'batters_faced'),pitches:numField(sp,'pitch_count'),hits:numField(sp,'hits_allowed'),homeRuns:numField(sp,'home_runs_allowed'),walks:numField(sp,'walks'),hbp:numField(sp,'hbp'),strikeouts:numField(sp,'strikeouts'),runs:numField(sp,'runs'),earnedRuns:numField(sp,'earned_runs'),wins:numField(sp,'wins'),losses:numField(sp,'losses'),holds:numField(sp,'holds'),saves:numField(sp,'saves'),blownSaves:numField(sp,'blown_saves'),qs:numField(sp,'quality_starts'),qsPlus:numField(sp,'quality_start_plus')}};
}
function deltaVal(cur,base,sameYear){if(cur==null)return null;if(!sameYear)return cur;if(base==null)return null;const v=Number(cur)-Number(base);return Number.isFinite(v)&&v>=0?v:null;}
function confirmedSeasonDelta(current,anchor,currentYear,anchorYear){
  if(!current)return null;const sameYear=Number(currentYear)===Number(anchorYear),cb=current.batting||{},bb=anchor?.batting||{},cp=current.pitching||{},bp=anchor?.pitching||{};
  const bat={},pit={};for(const k of ['games','plateAppearances','atBats','hits','singles','doubles','triples','homeRuns','rbi','runs','walks','hbp','strikeouts','stolenBases','groundedIntoDoublePlay','errors'])bat[k]=deltaVal(cb[k],bb[k],sameYear);
  for(const k of ['games','starts','outs','battersFaced','pitches','hits','homeRuns','walks','hbp','strikeouts','runs','earnedRuns','wins','losses','holds','saves','blownSaves','qs','qsPlus'])pit[k]=deltaVal(cp[k],bp[k],sameYear);
  if(bat.atBats!=null&&bat.hits!=null)bat.average=bat.atBats>0?bat.hits/bat.atBats:null;else bat.average=null;
  if([bat.singles,bat.doubles,bat.triples,bat.homeRuns,bat.atBats].every(v=>v!=null))bat.slugging=bat.atBats>0?(bat.singles+2*bat.doubles+3*bat.triples+4*bat.homeRuns)/bat.atBats:null;else bat.slugging=null;
  pit.era=pit.outs>0&&pit.earnedRuns!=null?pit.earnedRuns*27/pit.outs:null;pit.whip=pit.outs>0&&pit.hits!=null&&pit.walks!=null?(pit.hits+pit.walks)*3/pit.outs:null;pit.kbb=pit.walks>0&&pit.strikeouts!=null?pit.strikeouts/pit.walks:null;pit.k9=pit.outs>0&&pit.strikeouts!=null?pit.strikeouts*27/pit.outs:null;pit.bb9=pit.outs>0&&pit.walks!=null?pit.walks*27/pit.outs:null;pit.hr9=pit.outs>0&&pit.homeRuns!=null?pit.homeRuns*27/pit.outs:null;
  return {source:`SaveReader Contract schema ${CONTRACT_SCHEMA_VERSION}`,readerVersion:readerInfo.readerVersion,season:Number(currentYear)||null,batting:bat,pitching:pit};
}
function seedMissingLegacyAnchor(current){
  if(state.seasonAnchorFile||!state.seasonAnchorConfirmed||!current)return;
  for(const section of ['batting','pitching']){
    const dst=state.seasonAnchorConfirmed[section]||(state.seasonAnchorConfirmed[section]={}),src=current[section]||{};
    for(const [key,value] of Object.entries(src)){if(dst[key]==null&&value!=null)dst[key]=value;}
  }
}
function updateLatestConfirmedFromSnapshot(snap){const y=yearFromOutput(snap),cur=extractConfirmedSeason(snap);seedMissingLegacyAnchor(cur);state.latestSeasonYear=y;state.latestSeasonStatsConfirmed=state.seasonStatsMode==='full-season'?confirmedSeasonDelta(cur,null,y,-1):confirmedSeasonDelta(cur,state.seasonAnchorConfirmed,y,state.seasonAnchorYear);state.lastCapabilities=snap?.capabilities||state.lastCapabilities;return state.latestSeasonStatsConfirmed;}

export async function inspectSave(savePath=state.savePath,canon=null){
  const p=resolveSaveFilePath(savePath);if(!p)throw new Error('StarPlayer.dat 경로를 먼저 입력해 주세요.');if(!fs.existsSync(p)||fs.statSync(p).isDirectory())throw new Error('지정한 StarPlayer.dat 파일을 찾지 못했습니다.');if(p!==state.savePath&&!state.linked){state.savePath=p;persist();}
  const snap=validateContractOutput(await runReader([p]));const player=snap.player||{};if(player.id==null)throw new Error('세이브에서 선수 정보를 확인하지 못했습니다.');state.lastCapabilities=snap.capabilities||state.lastCapabilities;persist();const year=yearFromOutput(snap),meta=snapshotMeta(snap);
  return {snapshot:snap,match:{name:canon?normalize(canon.name)===normalize(player.name):null,team:canon?teamMatches(canon.team,player.team):null,year},seasonStatsConfirmed:confirmedSeasonDelta(extractConfirmedSeason(snap),null,year,-1),display:{player:player.name,team:TEAM_KO[player.team]||player.team,date:meta.saveDate,lastCompletedGameDate:meta.lastCompletedGameDate,playerGameLogCount:meta.playerGameLogCount,battingGames:meta.battingGames,pitchingAppearances:meta.pitchingAppearances,pitchingStarts:meta.pitchingStarts,readerVersion:snap.reader_version,schemaVersion:snap.schema_version}};
}
function safeUnlinkSnapshotFiles(){try{for(const f of fs.readdirSync(dataDir)){if(f==='pending')continue;const x=path.join(dataDir,f);if(fs.statSync(x).isFile())fs.rmSync(x,{force:true});}}catch{}try{for(const f of fs.readdirSync(pendingDir))fs.rmSync(path.join(pendingDir,f),{force:true});}catch{}}
export function resetSaveReaderLinkage({preservePath=true}={}){stopWatcher();const p=preservePath?state.savePath:'';safeUnlinkSnapshotFiles();state=blankState(p);persist();emit('save-reader-reset');return publicState();}
export function setSavePath(savePath){const p=resolveSaveFilePath(savePath);if(state.linked&&p!==state.savePath)throw new Error('연결 중에는 경로를 바꿀 수 없습니다. 먼저 연결 해제 후 변경해 주세요.');state.savePath=p;state.lastError=null;persist();return publicState();}
function copySnapshot(src,label){const file=path.join(dataDir,`${label}.dat`);fs.copyFileSync(src,file);return file;}
export async function linkCurrentSave({canon,force=false,importSeasonToDate=false}={}){
  const inspected=await inspectSave(state.savePath,canon);if(canon&&!force&&(!inspected.match.name||!inspected.match.team)){const e=new Error('현재 주인공과 세이브의 선수/팀 정보가 일치하지 않습니다.');e.code='MISMATCH';e.inspect=inspected;throw e;}
  stopWatcher();safeUnlinkSnapshotFiles();const baseline=copySnapshot(state.savePath,'baseline'),anchor=copySnapshot(state.savePath,'season-anchor'),snap=inspected.snapshot,y=yearFromOutput(snap),seasonAnchor=extractConfirmedSeason(snap),seasonStatsMode=importSeasonToDate?'full-season':'from-link';
  const latestSeasonStatsConfirmed=seasonStatsMode==='full-season'?confirmedSeasonDelta(seasonAnchor,null,y,-1):confirmedSeasonDelta(seasonAnchor,seasonAnchor,y,y);
  state={...blankState(state.savePath),linked:true,enabled:true,paused:false,linkedPlayerId:snap.player.id,linkedPlayerName:snap.player.name,linkedTeam:snap.player.team,baselineFile:baseline,baselineMeta:{linkedAt:new Date().toISOString(),...snapshotMeta(snap)},seasonAnchorFile:anchor,seasonAnchorConfirmed:seasonAnchor,seasonAnchorYear:y,seasonStatsMode,lastCapabilities:snap.capabilities||null,latestSeasonStatsConfirmed,latestSeasonYear:y,lastEvent:`현재 세이브를 SaveReader ${snap.reader_version} · schema ${snap.schema_version} 기준점으로 연결했습니다. 시즌 기록 방식: ${seasonStatsMode==='full-season'?'현재까지 누적 포함':'연결 이후만'}.`};persist();startWatcher();emit('save-reader-linked',{inspect:inspected});return {status:publicState(),inspect:inspected,seasonStatsConfirmed:latestSeasonStatsConfirmed,seasonYear:y};
}
export function pauseSaveReader(paused=true){if(!state.linked)throw new Error('먼저 현재 세이브를 연결해 주세요.');state.paused=Boolean(paused);state.enabled=!state.paused;state.lastError=null;persist();if(state.paused)stopWatcher();else startWatcher();emit('save-reader-status');return publicState();}
export function unlinkSaveReader(){return resetSaveReaderLinkage({preservePath:true});}
export async function rebaselineCurrentSave({canon,force=false}={}){
  if(!state.linked)throw new Error('연결된 세이브가 없습니다.');const inspected=await inspectSave(state.savePath,canon);if(!force&&(Number(inspected.snapshot.player.id)!==Number(state.linkedPlayerId)))throw new Error('연결된 선수와 현재 세이브 선수가 다릅니다.');
  const baseline=copySnapshot(state.savePath,'baseline');state.baselineFile=baseline;state.baselineMeta={linkedAt:state.baselineMeta?.linkedAt||new Date().toISOString(),...snapshotMeta(inspected.snapshot),updatedAt:new Date().toISOString()};updateLatestConfirmedFromSnapshot(inspected.snapshot);state.pending=[];state.blockedReason=null;state.lastError=null;state.lastEvent=`현재 저장을 SaveReader ${inspected.snapshot.reader_version} 새 비교 기준점으로 설정했습니다.`;try{for(const f of fs.readdirSync(pendingDir))fs.rmSync(path.join(pendingDir,f),{force:true});}catch{}persist();startWatcher();emit('save-reader-rebaseline');return publicState();
}
function outcome(v){return v==='win'?'W':v==='loss'?'L':v==='draw'?'T':'unknown';}
function battingAppeared(b){const lineup=numField(b,'lineup_order'),pos=strField(b,'position');if(lineup!=null||pos)return true;for(const k of ['plate_appearances','at_bats','hits','home_runs','rbi','runs','walks','hbp','strikeouts','stolen_bases']){const v=numField(b,k);if(v!=null&&v>0)return true;}return false;}
function pitchingDecision(p,appeared){if(!appeared)return 'none';const win=boolField(p,'win'),loss=boolField(p,'loss'),nd=boolField(p,'no_decision'),hold=boolField(p,'hold'),save=boolField(p,'save'),bs=boolField(p,'blown_save');if(win===true)return 'W';if(loss===true)return 'L';if(save===true)return 'S';if(hold===true)return 'H';if(bs===true)return 'BS';if(nd===true)return 'ND';return 'none';}
export function buildParsedFromCompare(compare){
  const o=validateContractOutput(compare,{compare:true}),g=o.game||{},b=o.batting||{},p=o.pitching||{};const pitchAppeared=boolField(p,'appeared')===true,batAppeared=battingAppeared(b);
  const parsed={date:strField(g,'date'),timeLabel:null,worldTimeMinutes:null,opponent:TEAM_KO[strField(g,'opponent')]||strField(g,'opponent'),homeAway:strField(g,'home_away')||'unknown',teamScore:numField(g,'team_score'),opponentScore:numField(g,'opponent_score'),result:outcome(strField(g,'result')),
    pitching:pitchAppeared?{outs:numField(p,'innings_outs'),battersFaced:numField(p,'batters_faced'),hits:numField(p,'hits_allowed'),homeRuns:numField(p,'home_runs_allowed'),strikeouts:numField(p,'strikeouts'),walks:numField(p,'walks'),hbp:numField(p,'hbp'),walksPlusHbp:(numField(p,'walks')!=null&&numField(p,'hbp')!=null)?numField(p,'walks')+numField(p,'hbp'):null,runs:numField(p,'runs'),earnedRuns:numField(p,'earned_runs'),pitches:numField(p,'pitch_count'),decision:pitchingDecision(p,true),started:boolField(p,'started'),qualityStart:boolField(p,'quality_start'),highQualityStart:boolField(p,'quality_start_plus'),win:boolField(p,'win'),loss:boolField(p,'loss'),noDecision:boolField(p,'no_decision'),hold:boolField(p,'hold'),save:boolField(p,'save'),blownSave:boolField(p,'blown_save')}:null,
    batting:batAppeared?{lineupSpot:numField(b,'lineup_order'),position:strField(b,'position'),plateAppearances:numField(b,'plate_appearances'),atBats:numField(b,'at_bats'),hits:numField(b,'hits'),singles:numField(b,'singles'),doubles:numField(b,'doubles'),triples:numField(b,'triples'),homeRuns:numField(b,'home_runs'),rbi:numField(b,'rbi'),runs:numField(b,'runs'),walks:numField(b,'walks'),hbp:numField(b,'hbp'),stolenBases:numField(b,'stolen_bases'),strikeouts:numField(b,'strikeouts'),groundedIntoDoublePlay:numField(b,'grounded_into_double_play'),errors:numField(b,'errors'),sacBuntCandidate:null,sacFlyCandidate:null}:null,
    highlights:[],exitContext:null,specialTriggers:[],parser:'save-reader-contract-v1'};
  return {parsed,batAppeared,pitchAppeared,readerVersion:o.reader_version,schemaVersion:o.schema_version,capabilities:o.capabilities||{}};
}
function decisionLabel(v){return ({W:'승',L:'패',ND:'승패 없음',S:'세이브',H:'홀드',BS:'블론세이브'})[v]||null;}
function buildRaw(parsed,readerVersion){
  const d=String(parsed.date||''),dateText=/^\d{4}-\d{2}-\d{2}$/.test(d)?`${d.slice(0,4)}년 ${Number(d.slice(5,7))}월 ${Number(d.slice(8,10))}일`:d;const lines=[`${dateText||'날짜 미판독'} - ${parsed.opponent||'상대팀'}(${parsed.homeAway==='home'?'홈':parsed.homeAway==='away'?'원정':'미지정'})`,'',`${parsed.teamScore??'—'}-${parsed.opponentScore??'—'} ${parsed.result==='W'?'승리':parsed.result==='L'?'패배':parsed.result==='T'?'무승부':'결과 미제공'}`];
  if(parsed.pitching){const p=parsed.pitching;lines.push('','[투수 기록]',`${Math.floor((p.outs||0)/3)}.${(p.outs||0)%3}이닝 상대 타자 ${p.battersFaced??'미판독'}명 ${p.hits??'미판독'}피안타 ${p.homeRuns??'미판독'}피홈런 ${p.strikeouts??'미판독'}탈삼진 ${p.walks??'미판독'}볼넷 ${p.hbp??'미판독'}사구 ${p.runs??'미판독'}실점 ${p.earnedRuns??'미판독'}자책점`,p.pitches!=null?`투구 수: ${p.pitches}개`:'투구 수: 미판독');const dl=decisionLabel(p.decision);if(dl)lines.push(dl);}
  if(parsed.batting){const b=parsed.batting,pos=b.position?`(${b.position})`:'';const extras=[];if(b.doubles!=null)extras.push(`${b.doubles}2루타`);if(b.triples!=null)extras.push(`${b.triples}3루타`);if(b.hbp!=null)extras.push(`${b.hbp}사구`);if(b.stolenBases!=null)extras.push(`${b.stolenBases}도루`);if(b.groundedIntoDoublePlay!=null)extras.push(`${b.groundedIntoDoublePlay}병살`);if(b.errors!=null)extras.push(`${b.errors}실책`);lines.push('','[타자 기록]',`${b.lineupSpot??'타순 미판독'}번타자${pos} ${b.atBats??'미판독'}타수 ${b.hits??'미판독'}안타 ${b.homeRuns??'미판독'}홈런 ${b.rbi??'미판독'}타점 ${b.runs??'미판독'}득점 ${b.walks??'미판독'}볼넷 ${b.strikeouts??'미판독'}삼진${extras.length?` ${extras.join(' ')}`:''}`);}
  lines.push('',`[자동 판독] SaveReader ${readerVersion||readerInfo.readerVersion} · Contract schema ${CONTRACT_SCHEMA_VERSION} · confirmed 값만 사용`,'[미확정] pending / unmapped / null 값은 자동입력하지 않음');return lines.join('\n');
}
function unavailableFields(o){const out=[];for(const [k,label] of Object.entries(FIELD_LABELS)){const [section,key]=k.split('.'),s=status(o?.[section],key);if(s!=='confirmed')out.push(`${label}(${s})`);}return out;}
function makePending(compare,snapshotPath,seasonStatsConfirmed=null){
  const o=validateContractOutput(compare,{compare:true}),ver=o.verification||{};if(ver.verified!==true)throw new Error('SaveReader 고정 스키마 검증에 통과하지 못했습니다.');const newLogs=Number(ver.new_game_log_count);if(newLogs!==1)throw new Error(`신규 GAME LOG 수가 ${newLogs}개입니다.`);
  const {parsed,batAppeared,pitchAppeared,readerVersion,schemaVersion,capabilities}=buildParsedFromCompare(o),kind=!batAppeared&&!pitchAppeared?'dnp':'game',id=state.nextPendingId++,summary=kind==='dnp'?`${parsed.date} ${parsed.opponent||''} · 미출전`:`${parsed.date} ${parsed.opponent||''} · ${parsed.teamScore??'—'}-${parsed.opponentScore??'—'}`;
  return{id,kind,date:parsed.date,opponent:parsed.opponent,teamScore:parsed.teamScore,opponentScore:parsed.opponentScore,result:parsed.result,homeAway:parsed.homeAway,parsed:kind==='game'?parsed:null,rawInput:kind==='game'?buildRaw(parsed,readerVersion):null,dnp:kind==='dnp'?{kind:'dnp',date:parsed.date,opponent:parsed.opponent,homeAway:parsed.homeAway,teamScore:parsed.teamScore,opponentScore:parsed.opponentScore,result:parsed.result,reason:'단순 미출전'}:null,readerCompare:o,readerVersion,schemaVersion,capabilities,unavailable:unavailableFields(o),seasonStatsConfirmed,snapshotPath,detectedAt:new Date().toISOString(),acknowledged:false,summary};
}
async function waitStable(file){let prev=null;for(let i=0;i<7;i++){const st=fs.statSync(file),sig=`${st.size}:${st.mtimeMs}`;if(prev===sig)return;prev=sig;await new Promise(r=>setTimeout(r,650));}throw new Error('세이브 파일이 아직 기록 중입니다. 잠시 후 다시 확인합니다.');}
function stopWatcher(){if(watcherPath){fs.unwatchFile(watcherPath);watcherPath=null;}if(watchTimer){clearTimeout(watchTimer);watchTimer=null;}}
function scheduleProcess(){if(watchTimer)clearTimeout(watchTimer);watchTimer=setTimeout(()=>processSaveChange().catch(()=>{}),1100);}
export function startWatcher(){stopWatcher();if(!state.linked||!state.enabled||state.paused||state.blockedReason||!state.savePath||!fs.existsSync(state.savePath)||!state.baselineFile||!fs.existsSync(state.baselineFile))return;watcherPath=state.savePath;fs.watchFile(watcherPath,{interval:900},(cur,prev)=>{if(cur.mtimeMs!==prev.mtimeMs||cur.size!==prev.size)scheduleProcess();});}
function block(reason,payload={}){state.blockedReason=reason;state.lastError=reason;persist();emit('save-reader-blocked',payload);}
async function processSaveChange({allowPaused=false}={}){
  if(processing||!state.linked||(!allowPaused&&state.paused)||state.blockedReason)return;processing=true;let snapshotPath=null;
  try{
    await waitStable(state.savePath);snapshotPath=path.join(dataDir,`observed-${Date.now()}.dat`);fs.copyFileSync(state.savePath,snapshotPath);const cmp=validateContractOutput(await runReader(['--compare',state.baselineFile,snapshotPath]),{compare:true}),newLogs=Number(cmp.verification?.new_game_log_count);state.lastCapabilities=cmp.capabilities||state.lastCapabilities;
    if(!Number.isFinite(newLogs))throw new Error('SaveReader 비교 결과에서 신규 GAME LOG 수를 읽지 못했습니다.');
    if(newLogs===0){fs.copyFileSync(snapshotPath,state.baselineFile);fs.rmSync(snapshotPath,{force:true});snapshotPath=null;const snap=validateContractOutput(await runReader([state.baselineFile]));state.baselineMeta={...state.baselineMeta,...snapshotMeta(snap),updatedAt:new Date().toISOString()};updateLatestConfirmedFromSnapshot(snap);state.lastEvent='세이브 변경 감지 · 신규 GAME LOG 없음';state.lastError=null;persist();return;}
    if(newLogs>1){block(`새 GAME LOG가 ${newLogs}개 감지되어 자동 입력을 중단했습니다. 여러 경기를 하나로 합치지 않습니다. 빠진 경기를 확인한 뒤 현재 저장을 새 기준점으로 설정해 주세요.`,{newGameLogCount:newLogs});return;}
    if(cmp.verification?.verified!==true){block('새 GAME LOG 1개를 찾았지만 SaveReader 검증에 통과하지 못해 자동 입력을 중단했습니다.',{newGameLogCount:newLogs});return;}
    const snap=validateContractOutput(await runReader([snapshotPath])),seasonStatsConfirmed=updateLatestConfirmedFromSnapshot(snap),pending=makePending(cmp,snapshotPath,seasonStatsConfirmed),finalPath=path.join(pendingDir,`pending-${pending.id}.dat`);fs.renameSync(snapshotPath,finalPath);snapshotPath=null;pending.snapshotPath=finalPath;state.pending.push(pending);fs.copyFileSync(finalPath,state.baselineFile);state.baselineMeta={...state.baselineMeta,...snapshotMeta(snap),updatedAt:new Date().toISOString()};state.lastError=null;state.lastEvent=`새 경기 감지: ${pending.summary}`;persist();emit('save-reader-pending',{pending:{...pending,snapshotPath:undefined,readerCompare:undefined}});
  }catch(e){if(snapshotPath)try{fs.rmSync(snapshotPath,{force:true});}catch{}state.lastError=e.message;persist();emit('save-reader-error',{error:e.message});}finally{processing=false;}
}
export function listPending(){return state.pending.map(x=>({...x,snapshotPath:undefined,readerCompare:undefined}));}
export function getPending(id){const p=state.pending.find(x=>x.id===Number(id));return p?JSON.parse(JSON.stringify({...p,snapshotPath:undefined,readerCompare:undefined})):null;}
export function acknowledgePending(id){const p=state.pending.find(x=>x.id===Number(id));if(!p)throw new Error('미등록 경기 항목을 찾지 못했습니다.');p.acknowledged=true;persist();return getPending(id);}
export function completePending(id){const i=state.pending.findIndex(x=>x.id===Number(id));if(i<0)return false;const p=state.pending[i];try{if(p.snapshotPath)fs.rmSync(p.snapshotPath,{force:true});}catch{}state.pending.splice(i,1);state.lastEvent=`미등록 경기 등록 완료: ${p.summary}`;persist();emit('save-reader-pending-completed',{id:Number(id)});return true;}
export async function manualScanNow(){if(!state.linked)throw new Error('먼저 현재 세이브를 연결해 주세요.');if(state.blockedReason)throw new Error(state.blockedReason);await processSaveChange({allowPaused:true});return publicState();}

function walkFiles(dir){const out=[];for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,ent.name);if(ent.isDirectory())out.push(...walkFiles(p));else out.push(p);}return out;}
function safeVersion(v){return String(v||'unknown').replace(/[^0-9A-Za-z._-]+/g,'_').slice(0,60)||'unknown';}
function sha256(file){const h=crypto.createHash('sha256');h.update(fs.readFileSync(file));return h.digest('hex');}
async function extractZip(zipPath,dest){
  fs.mkdirSync(dest,{recursive:true});
  if(process.platform==='win32'){
    try{await spawnCollect('tar',['-xf',zipPath,'-C',dest],{timeout:30000});return;}catch{}
    await spawnCollect('powershell.exe',['-NoProfile','-NonInteractive','-Command','Expand-Archive -LiteralPath $args[0] -DestinationPath $args[1] -Force',zipPath,dest],{timeout:40000});return;
  }
  try{await spawnCollect('unzip',['-q',zipPath,'-d',dest],{timeout:30000});return;}catch{}
  await spawnCollect('tar',['-xf',zipPath,'-C',dest],{timeout:30000});
}
function sampleContractFromFiles(files){for(const f of files.filter(x=>x.toLowerCase().endsWith('.json'))){try{let d=JSON.parse(fs.readFileSync(f,'utf8'));d=oneSnapshot(d);if(Number(d?.schema_version)===CONTRACT_SCHEMA_VERSION&&d?.reader_version&&d?.capabilities&&d?.game&&d?.pitching)return {sample:d,file:f};}catch{}}return null;}
function candidateBinaries(files){const win=files.find(f=>/savereader/i.test(path.basename(f))&&f.toLowerCase().endsWith('.exe'))||files.find(f=>f.toLowerCase().endsWith('.exe'))||null;const linux=files.find(f=>/savereader/i.test(path.basename(f))&&/_linux$/i.test(path.basename(f)))||files.find(f=>/_linux$/i.test(path.basename(f)))||null;return{win,linux};}
async function refreshAnchorsAfterReaderUpdate(){
  if(!state.linked)return;
  try{
    if(state.seasonAnchorFile&&fs.existsSync(state.seasonAnchorFile)){const anchor=validateContractOutput(await runReader([state.seasonAnchorFile]));state.seasonAnchorConfirmed=extractConfirmedSeason(anchor);state.seasonAnchorYear=yearFromOutput(anchor);}
    if(state.savePath&&fs.existsSync(state.savePath)){const cur=validateContractOutput(await runReader([state.savePath]));updateLatestConfirmedFromSnapshot(cur);state.lastCapabilities=cur.capabilities||state.lastCapabilities;}
  }catch(e){state.lastError=`판독기 업데이트 후 기준 통계 재확인 실패: ${e.message}`;}
}
function restoreReaderBackup(backupDir){
  if(!backupDir||!fs.existsSync(backupDir))return;
  for(const f of ['reader.exe','reader_linux','manifest.json']){
    const active=path.join(internalDir,f),backup=path.join(backupDir,f);
    try{fs.rmSync(active,{force:true});}catch{}
    if(fs.existsSync(backup))fs.copyFileSync(backup,active);
  }
  readerInfo=loadManifest();
}
export async function installSaveReaderBundle(buffer,filename='SaveReader.zip'){
  if(!Buffer.isBuffer(buffer)||buffer.length<4)throw new Error('SaveReader ZIP 파일이 비어 있습니다.');
  const wasWatching=state.linked&&state.enabled&&!state.paused&&!state.blockedReason;
  stopWatcher();
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'starplayer-reader-'));
  const zipPath=path.join(tmp,'bundle.zip'),extractDir=path.join(tmp,'extract');
  let backupDir=null,releaseDir=null,swapStarted=false;
  fs.writeFileSync(zipPath,buffer);
  try{
    await extractZip(zipPath,extractDir);
    const files=walkFiles(extractDir),bins=candidateBinaries(files),sampleInfo=sampleContractFromFiles(files);
    if(!bins.win)throw new Error('업데이트 ZIP에서 Windows SaveReader .exe를 찾지 못했습니다.');

    // Validate the candidate before touching the active reader. Prefer a real linked save;
    // otherwise use the contract sample bundled with the reader release.
    let proof=sampleInfo?.sample||null;
    const platformCandidate=process.platform==='win32'?bins.win:process.platform==='linux'?bins.linux:null;
    if(platformCandidate&&state.savePath&&fs.existsSync(state.savePath)){
      try{proof=validateContractOutput(await runReader([state.savePath],platformCandidate));}
      catch(e){throw new Error(`새 판독기 실행 검증 실패: ${e.message}`);}
    }
    if(!proof)throw new Error('업데이트 ZIP에서 schema_version을 검증할 샘플 JSON을 찾지 못했습니다. 연결된 세이브도 없어 실행 검증을 할 수 없습니다.');
    proof=validateContractOutput(proof);
    const newVersion=String(proof.reader_version),schemaVersion=Number(proof.schema_version);
    if(schemaVersion!==CONTRACT_SCHEMA_VERSION)throw new Error(`스키마 ${schemaVersion}은 현재 몰입모드와 호환되지 않습니다.`);

    const old=loadManifest();
    backupDir=path.join(internalDir,'backups',`${stamp}-v${safeVersion(old.readerVersion)}`);
    fs.mkdirSync(backupDir,{recursive:true});
    for(const f of ['reader.exe','reader_linux','manifest.json']){
      const src=path.join(internalDir,f);if(fs.existsSync(src))fs.copyFileSync(src,path.join(backupDir,f));
    }
    releaseDir=path.join(internalDir,'releases',`${safeVersion(newVersion)}-${stamp}`);
    fs.cpSync(extractDir,releaseDir,{recursive:true});

    // Stage all replacement files first, then swap. Any failure after this point rolls
    // back to the backup above so a broken reader update cannot strand the app.
    const stagedWin=path.join(internalDir,'reader.exe.new');
    fs.copyFileSync(bins.win,stagedWin);
    let stagedLinux=null;
    if(bins.linux){stagedLinux=path.join(internalDir,'reader_linux.new');fs.copyFileSync(bins.linux,stagedLinux);try{fs.chmodSync(stagedLinux,0o755);}catch{}}
    swapStarted=true;
    const activeWin=path.join(internalDir,'reader.exe');fs.rmSync(activeWin,{force:true});fs.renameSync(stagedWin,activeWin);
    let linuxHash=null;
    if(stagedLinux){const activeLinux=path.join(internalDir,'reader_linux');fs.rmSync(activeLinux,{force:true});fs.renameSync(stagedLinux,activeLinux);linuxHash=sha256(activeLinux);}

    const manifest={
      schemaVersion:CONTRACT_SCHEMA_VERSION,
      readerVersion:newVersion,
      installedAt:new Date().toISOString(),
      active:{win32:'reader.exe',linux:bins.linux?'reader_linux':old.active?.linux||'reader_linux'},
      source:path.basename(filename||'SaveReader.zip'),
      sha256:{win32:sha256(activeWin),...(linuxHash?{linux:linuxHash}:{})},
      declaredCapabilities:proof.capabilities||{}
    };
    fs.writeFileSync(`${manifestPath}.tmp`,JSON.stringify(manifest,null,2),'utf8');
    fs.renameSync(`${manifestPath}.tmp`,manifestPath);
    readerInfo=loadManifest();
    state.lastCapabilities=proof.capabilities||state.lastCapabilities;
    state.lastError=null;
    state.lastEvent=`SaveReader ${newVersion} 업데이트 완료 · schema ${schemaVersion}`;
    await refreshAnchorsAfterReaderUpdate();
    persist();
    if(wasWatching)startWatcher();
    emit('save-reader-updated',{readerVersion:newVersion,schemaVersion});
    return {status:publicState(),reader:{readerVersion:newVersion,schemaVersion,capabilityCounts:capabilityCounts(proof.capabilities||{}),backupDir:path.relative(root,backupDir)}};
  }catch(e){
    if(swapStarted){
      try{restoreReaderBackup(backupDir);}catch(rollbackError){e.message+=` / 이전 판독기 복구 실패: ${rollbackError.message}`;}
    }
    try{fs.rmSync(path.join(internalDir,'reader.exe.new'),{force:true});}catch{}
    try{fs.rmSync(path.join(internalDir,'reader_linux.new'),{force:true});}catch{}
    try{fs.rmSync(`${manifestPath}.tmp`,{force:true});}catch{}
    if(releaseDir)try{fs.rmSync(releaseDir,{recursive:true,force:true});}catch{}
    if(wasWatching)startWatcher();
    throw e;
  }finally{
    try{fs.rmSync(tmp,{recursive:true,force:true});}catch{}
  }
}

startWatcher();
