package main

import (
	"bytes"
	"compress/zlib"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"
)

const (
	encryptedStart     = 0x448
	identityScanMax    = 0x20000
	scheduleBase       = 0x15EE600
	scoreBase          = 0x1602870
	scheduleDayStride  = 0x100
	scoreDayStride     = 0x30
	scheduleSlotBase   = 0x30
	scheduleSlotStride = 0x10
	scoreSlotStride    = 3
	slotsPerDay        = 6
	maxScoreSearchBack = 15
	gameLogBase        = 0x24BF8
	gameLogStride      = 0x48
	maxGameLogs        = 180
)

var secretKey = sha256.Sum256([]byte("5A8CA36B895641B16D03BAEDB582BE5A"))
var headerRE = regexp.MustCompile(`^(.+?)\s+(\d{4})년\s+(\d{1,2})월\s+(\d{1,2})일`)

type TeamInfo struct {
	Code  int    `json:"code"`
	Short string `json:"short"`
	Name  string `json:"name"`
}

var teams = []TeamInfo{
	{1, "Hanshin", "Hanshin Tigers"}, {2, "DeNA", "Yokohama DeNA BayStars"},
	{3, "Yomiuri", "Yomiuri Giants"}, {4, "Chunichi", "Chunichi Dragons"},
	{5, "Hiroshima", "Hiroshima Toyo Carp"}, {6, "Yakult", "Tokyo Yakult Swallows"},
	{9, "SoftBank", "Fukuoka SoftBank Hawks"}, {10, "Nippon-Ham", "Hokkaido Nippon-Ham Fighters"},
	{11, "ORIX", "ORIX Buffaloes"}, {12, "Rakuten", "Tohoku Rakuten Golden Eagles"},
	{13, "Seibu", "Saitama Seibu Lions"}, {14, "Lotte", "Chiba Lotte Marines"},
}

type Header struct {
	Raw      string `json:"raw"`
	Team     string `json:"team"`
	Date     string `json:"date"`
	TeamCode int    `json:"team_code"`
}
type Player struct {
	ID             uint32 `json:"id"`
	FamilyName     string `json:"family_name"`
	GivenName      string `json:"given_name"`
	FullName       string `json:"full_name"`
	IdentityOffset string `json:"identity_offset"`
}
type Bat struct{ Games, PA, AB, H, Doubles, Triples, HR, RBI, R, BB, HBP, SO, SB, Sac1, Sac2 int }
type Pitch struct{ Apps, Starts, QS, HQS, W, LCandidate, SVCandidate, Outs, H, BB, HBP, HR, BF, K, R, ER int }
type BatJSON struct {
	Games   int `json:"games"`
	PA      int `json:"plate_appearances"`
	AB      int `json:"at_bats"`
	H       int `json:"hits"`
	Doubles int `json:"doubles"`
	Triples int `json:"triples"`
	HR      int `json:"home_runs"`
	RBI     int `json:"rbi"`
	R       int `json:"runs"`
	BB      int `json:"walks"`
	HBP     int `json:"hbp"`
	SO      int `json:"strikeouts"`
	SB      int `json:"stolen_bases"`
	Sac1    int `json:"sac_bunt_candidate"`
	Sac2    int `json:"sac_fly_candidate"`
}
type PitchJSON struct {
	Apps        int    `json:"appearances"`
	Starts      int    `json:"starts"`
	QS          int    `json:"quality_starts"`
	HQS         int    `json:"high_quality_starts"`
	W           int    `json:"wins"`
	LCandidate  int    `json:"losses_candidate"`
	SVCandidate int    `json:"saves_candidate"`
	Outs        int    `json:"outs"`
	Innings     string `json:"innings"`
	H           int    `json:"hits_allowed"`
	BB          int    `json:"walks"`
	HBP         int    `json:"hbp_allowed"`
	FreePasses  int    `json:"walks_plus_hbp"`
	HR          int    `json:"home_runs_allowed"`
	BF          int    `json:"batters_faced"`
	K           int    `json:"strikeouts"`
	R           int    `json:"runs"`
	ER          int    `json:"earned_runs"`
}
type ScoreResult struct {
	Verified       bool   `json:"verified"`
	Date           string `json:"date,omitempty"`
	TeamScore      *int   `json:"team_score,omitempty"`
	OpponentScore  *int   `json:"opponent_score,omitempty"`
	Outcome        string `json:"outcome,omitempty"`
	TeamCode       int    `json:"team_code,omitempty"`
	OpponentCode   int    `json:"opponent_code,omitempty"`
	Opponent       string `json:"opponent,omitempty"`
	Venue          string `json:"venue,omitempty"`
	ScheduleOffset string `json:"schedule_offset,omitempty"`
	RecordOffset   string `json:"record_offset,omitempty"`
	Candidates     int    `json:"candidates"`
	Note           string `json:"note,omitempty"`
}
type CryptoInfo struct {
	Chunks       int  `json:"chunks"`
	LogicalBytes int  `json:"logical_bytes"`
	HMACVerified bool `json:"hmac_verified"`
}
type StatsInfo struct {
	RecordOffset     string    `json:"record_offset"`
	CandidateCount   int       `json:"candidate_count"`
	AmbiguousAllZero bool      `json:"ambiguous_all_zero,omitempty"`
	Bat              BatJSON   `json:"batting"`
	Pitch            PitchJSON `json:"pitching"`
}
type SeasonBatConfirmed struct {
	Games   int     `json:"games"`
	AB      int     `json:"at_bats"`
	H       int     `json:"hits"`
	Singles int     `json:"singles"`
	Doubles int     `json:"doubles"`
	Triples int     `json:"triples"`
	HR      int     `json:"home_runs"`
	RBI     int     `json:"rbi"`
	R       int     `json:"runs"`
	BB      int     `json:"walks"`
	SO      int     `json:"strikeouts"`
	Average float64 `json:"batting_average"`
}

type SeasonPitchConfirmed struct {
	Apps    int     `json:"appearances"`
	Starts  int     `json:"starts"`
	QS      int     `json:"quality_starts"`
	W       int     `json:"wins"`
	L       int     `json:"losses"`
	Outs    int     `json:"outs"`
	Innings string  `json:"innings"`
	H       int     `json:"hits_allowed"`
	BB      int     `json:"walks"`
	HBP     int     `json:"hbp_allowed"`
	HR      int     `json:"home_runs_allowed"`
	BF      int     `json:"batters_faced"`
	K       int     `json:"strikeouts"`
	R       int     `json:"runs"`
	ER      int     `json:"earned_runs"`
	ERA     float64 `json:"era"`
	WHIP    float64 `json:"whip"`
	KBB     float64 `json:"k_per_bb"`
	K9      float64 `json:"k_per_9"`
	BB9     float64 `json:"bb_per_9"`
	HR9     float64 `json:"hr_per_9"`
}

type ConfirmedSeasonStats struct {
	Batting  SeasonBatConfirmed   `json:"batting"`
	Pitching SeasonPitchConfirmed `json:"pitching"`
}

type PendingFields struct {
	Batting  []string `json:"batting"`
	Pitching []string `json:"pitching"`
	GameLog  []string `json:"single_game"`
}

type GameBatting struct {
	Appeared       bool   `json:"appeared"`
	AppearanceCode *int   `json:"appearance_code,omitempty"`
	Lineup         *int   `json:"lineup,omitempty"`
	PositionCode   *int   `json:"position_code,omitempty"`
	Position       string `json:"position,omitempty"`
	AB             int    `json:"at_bats"`
	H              int    `json:"hits"`
	HR             int    `json:"home_runs"`
	RBI            int    `json:"rbi"`
	R              int    `json:"runs"`
	BB             int    `json:"walks"`
	SO             int    `json:"strikeouts"`
}

type GamePitching struct {
	Appeared     bool   `json:"appeared"`
	DecisionCode int    `json:"decision_code"`
	Win          bool   `json:"win"`
	Loss         bool   `json:"loss"`
	InningsRaw   int    `json:"innings_raw"`
	Outs         int    `json:"outs"`
	Innings      string `json:"innings"`
	BF           int    `json:"batters_faced"`
	H            int    `json:"hits_allowed"`
	HR           int    `json:"home_runs_allowed"`
	K            int    `json:"strikeouts"`
	FreePasses   int    `json:"walks_plus_hbp"`
	BB           *int   `json:"walks,omitempty"`
	HBP          *int   `json:"hbp_allowed,omitempty"`
	R            int    `json:"runs"`
	ER           int    `json:"earned_runs"`
}

type PlayerGameLog struct {
	Index        int          `json:"index"`
	GameID       uint32       `json:"game_id"`
	RecordOffset string       `json:"record_offset"`
	Batting      GameBatting  `json:"batting"`
	Pitching     GamePitching `json:"pitching"`
}

type Snapshot struct {
	File               string               `json:"file"`
	Header             Header               `json:"header"`
	Player             Player               `json:"player"`
	Crypto             CryptoInfo           `json:"crypto"`
	ConfirmedSeason    ConfirmedSeasonStats `json:"season_stats_confirmed"`
	Pending            PendingFields        `json:"pending_fields"`
	LatestPlayerGame   *PlayerGameLog       `json:"latest_player_game_log,omitempty"`
	LastCompletedGame  ScoreResult          `json:"last_completed_game"`
	ValidationWarnings []string             `json:"validation_warnings,omitempty"`
	Limits             []string             `json:"limits,omitempty"`
	Stats              StatsInfo            `json:"-"`
	GameLogs           []PlayerGameLog      `json:"-"`
}

type DetectedGame struct {
	Before          string         `json:"before"`
	After           string         `json:"after"`
	Player          string         `json:"player"`
	Verified        bool           `json:"verified"`
	NewGameLogCount int            `json:"new_game_log_count"`
	Game            *PlayerGameLog `json:"player_game_log,omitempty"`
	Score           ScoreResult    `json:"score"`
	Warnings        []string       `json:"warnings,omitempty"`
}

func teamByName(name string) (TeamInfo, bool) {
	for _, t := range teams {
		if t.Name == name || t.Short == name {
			return t, true
		}
	}
	return TeamInfo{}, false
}
func teamByCode(code int) (TeamInfo, bool) {
	for _, t := range teams {
		if t.Code == code {
			return t, true
		}
	}
	return TeamInfo{}, false
}

func cString(b []byte) string {
	if i := bytes.IndexByte(b, 0); i >= 0 {
		b = b[:i]
	}
	return strings.TrimSpace(string(b))
}
func readU16(b []byte, off int) (int, bool) {
	if off < 0 || off+2 > len(b) {
		return 0, false
	}
	return int(binary.LittleEndian.Uint16(b[off : off+2])), true
}
func readU32(b []byte, off int) (uint32, bool) {
	if off < 0 || off+4 > len(b) {
		return 0, false
	}
	return binary.LittleEndian.Uint32(b[off : off+4]), true
}

func parseHeader(raw []byte) (Header, error) {
	if len(raw) < encryptedStart {
		return Header{}, errors.New("file too short for header")
	}
	s := cString(raw[0x48:encryptedStart])
	m := headerRE.FindStringSubmatch(s)
	if m == nil {
		return Header{}, fmt.Errorf("header format not recognized: %q", s)
	}
	var y, mo, d int
	fmt.Sscanf(m[2], "%d", &y)
	fmt.Sscanf(m[3], "%d", &mo)
	fmt.Sscanf(m[4], "%d", &d)
	tm, err := time.Parse("2006-1-2", fmt.Sprintf("%d-%d-%d", y, mo, d))
	if err != nil {
		return Header{}, err
	}
	ti, ok := teamByName(strings.TrimSpace(m[1]))
	code := 0
	if ok {
		code = ti.Code
	}
	return Header{Raw: s, Team: strings.TrimSpace(m[1]), Date: tm.Format("2006-01-02"), TeamCode: code}, nil
}

func decryptSave(raw []byte) ([]byte, CryptoInfo, error) {
	if len(raw) < encryptedStart {
		return nil, CryptoInfo{}, errors.New("save is shorter than 0x448")
	}
	p := encryptedStart
	var out bytes.Buffer
	chunks := 0
	for p+8 <= len(raw) {
		payloadLen := int(binary.LittleEndian.Uint32(raw[p : p+4]))
		compLen := int(binary.LittleEndian.Uint32(raw[p+4 : p+8]))
		p += 8
		if payloadLen == 0 {
			break
		}
		if payloadLen < 48 || p+payloadLen > len(raw) {
			return nil, CryptoInfo{}, fmt.Errorf("invalid chunk %d payload length %d", chunks, payloadLen)
		}
		payload := raw[p : p+payloadLen]
		p += payloadLen
		iv := payload[:16]
		wantMAC := payload[16:48]
		ciphertext := payload[48:]
		mac := hmac.New(sha256.New, secretKey[:])
		mac.Write(ciphertext)
		if !hmac.Equal(wantMAC, mac.Sum(nil)) {
			return nil, CryptoInfo{}, fmt.Errorf("HMAC mismatch at chunk %d", chunks)
		}
		if len(ciphertext)%aes.BlockSize != 0 {
			return nil, CryptoInfo{}, fmt.Errorf("AES ciphertext not block aligned at chunk %d", chunks)
		}
		block, err := aes.NewCipher(secretKey[:16])
		if err != nil {
			return nil, CryptoInfo{}, err
		}
		plain := make([]byte, len(ciphertext))
		cipher.NewCBCDecrypter(block, iv).CryptBlocks(plain, ciphertext)
		if compLen < 0 || compLen > len(plain) {
			return nil, CryptoInfo{}, fmt.Errorf("invalid compressed length at chunk %d", chunks)
		}
		zr, err := zlib.NewReader(bytes.NewReader(plain[:compLen]))
		if err != nil {
			return nil, CryptoInfo{}, fmt.Errorf("zlib init chunk %d: %w", chunks, err)
		}
		_, err = io.Copy(&out, zr)
		closeErr := zr.Close()
		if err != nil {
			return nil, CryptoInfo{}, fmt.Errorf("zlib chunk %d: %w", chunks, err)
		}
		if closeErr != nil {
			return nil, CryptoInfo{}, closeErr
		}
		chunks++
	}
	if chunks == 0 {
		return nil, CryptoInfo{}, errors.New("no encrypted chunks found")
	}
	return out.Bytes(), CryptoInfo{Chunks: chunks, LogicalBytes: out.Len(), HMACVerified: true}, nil
}

func readNamePairAt(b []byte, off int) (string, string, bool) {
	start := off + 0x1c
	if start < 0 || start >= len(b) {
		return "", "", false
	}
	limit := start + 0x30
	if limit > len(b) {
		limit = len(b)
	}
	x := b[start:limit]
	i := bytes.IndexByte(x, 0)
	if i <= 0 {
		return "", "", false
	}
	famB := x[:i]
	x = x[i+1:]
	j := bytes.IndexByte(x, 0)
	if j <= 0 {
		return "", "", false
	}
	givB := x[:j]
	if !utf8.Valid(famB) || !utf8.Valid(givB) {
		return "", "", false
	}
	fam, giv := string(famB), string(givB)
	if !plausibleName(fam) || !plausibleName(giv) {
		return "", "", false
	}
	return fam, giv, true
}
func plausibleName(s string) bool {
	if len([]rune(s)) < 1 || len([]rune(s)) > 16 {
		return false
	}
	letters := 0
	for _, r := range s {
		if unicode.IsLetter(r) {
			letters++
		} else if r != '-' && r != ' ' && r != '・' && r != '.' {
			return false
		}
	}
	return letters > 0
}

func parsePlayerIdentity(b []byte) (Player, error) {
	max := len(b)
	if max > identityScanMax {
		max = identityScanMax
	}
	type cand struct {
		id       uint32
		fam, giv string
		offs     []int
	}
	groups := map[string]*cand{}
	for off := 0; off+0x50 <= max; off++ {
		id := binary.LittleEndian.Uint32(b[off : off+4])
		if id == 0 || id > 2000000 {
			continue
		}
		fam, giv, ok := readNamePairAt(b, off)
		if !ok {
			continue
		}
		key := fmt.Sprintf("%d\x00%s\x00%s", id, fam, giv)
		if groups[key] == nil {
			groups[key] = &cand{id: id, fam: fam, giv: giv}
		}
		groups[key].offs = append(groups[key].offs, off)
	}
	if len(groups) == 0 {
		return Player{}, errors.New("no plausible player identity found in first 0x20000 bytes")
	}
	all := make([]*cand, 0, len(groups))
	for _, c := range groups {
		all = append(all, c)
	}
	sort.Slice(all, func(i, j int) bool {
		if len(all[i].offs) != len(all[j].offs) {
			return len(all[i].offs) > len(all[j].offs)
		}
		return all[i].offs[0] < all[j].offs[0]
	})
	c := all[0]
	if len(c.offs) < 2 {
		return Player{}, fmt.Errorf("player identity not repeated/verified: id=%d %s %s", c.id, c.fam, c.giv)
	}
	return Player{ID: c.id, FamilyName: c.fam, GivenName: c.giv, FullName: strings.TrimSpace(c.fam + " " + c.giv), IdentityOffset: fmt.Sprintf("0x%x", c.offs[0])}, nil
}

func findProfileOccurrences(b []byte, p Player) []int {
	sig := make([]byte, 4)
	binary.LittleEndian.PutUint32(sig, p.ID)
	fam := []byte(p.FamilyName)
	giv := []byte(p.GivenName)
	var offs []int
	for pos := 0; ; {
		i := bytes.Index(b[pos:], sig)
		if i < 0 {
			break
		}
		o := pos + i
		pos = o + 1
		n := o + 0x1c
		if n+len(fam)+1+len(giv)+1 > len(b) {
			continue
		}
		if bytes.Equal(b[n:n+len(fam)], fam) && b[n+len(fam)] == 0 && bytes.Equal(b[n+len(fam)+1:n+len(fam)+1+len(giv)], giv) && b[n+len(fam)+1+len(giv)] == 0 {
			offs = append(offs, o)
		}
	}
	return offs
}

func parseStatsAt(b []byte, base int) (Bat, Pitch, bool) {
	u := func(rel int) int {
		v, ok := readU16(b, base+rel)
		if !ok {
			return -1
		}
		return v
	}
	pa := u(0x77c)
	bb := u(0x77a)
	hbp := u(0x78a)
	sac1 := u(0x786)
	sac2 := u(0x780)
	singles := u(0x778)
	doubles := u(0x76e)
	triples := u(0x77e)
	hr := u(0x770)
	bat := Bat{Games: u(0x7d4), PA: pa, AB: pa - bb - hbp - sac1 - sac2, H: singles + doubles + triples + hr, Doubles: doubles, Triples: triples, HR: hr, RBI: u(0x76c), R: u(0x772), BB: bb, HBP: hbp, SO: u(0x774), SB: u(0x782), Sac1: sac1, Sac2: sac2}
	// Pitching map cross-validated against multiple in-game season screens and two true one-game before/after pairs.
	// Confirmed: +0x730 BB, +0x732 HR, +0x734 ER, +0x736 H, +0x73a R, +0x73c BF, +0x73e K, +0x748 W, +0x758 HBP.
	// QS/HQS are also screen-validated: +0x764 QS and +0x766 HQS. The 2026-04-29 6.0 IP/2 ER game increments QS only;
	// the later 3.0 IP/5 ER game increments neither, matching the supplied season totals (QS=3, HQS=1).
	pitch := Pitch{Apps: u(0x744), Starts: u(0x7e6), QS: u(0x764), HQS: u(0x766), W: u(0x748), LCandidate: u(0x74a), SVCandidate: u(0x74c), Outs: u(0x7e2), H: u(0x736), BB: u(0x730), HBP: u(0x758), HR: u(0x732), BF: u(0x73c), K: u(0x73e), R: u(0x73a), ER: u(0x734)}
	ok := validateBat(bat) && validatePitch(pitch)
	return bat, pitch, ok
}
func validateBat(x Bat) bool {
	if x.Games < 0 || x.Games > 1000 || x.PA < 0 || x.PA > 10000 || x.AB < 0 || x.AB > x.PA || x.H < 0 || x.H > x.AB || x.HR < 0 || x.HR > x.H || x.Doubles < 0 || x.Triples < 0 || x.RBI < 0 || x.RBI > x.PA*4 {
		return false
	}
	for _, v := range []int{x.R, x.BB, x.HBP, x.SO, x.SB, x.Sac1, x.Sac2} {
		if v < 0 {
			return false
		}
	}
	if x.Games == 0 && (x.PA > 0 || x.AB > 0 || x.H > 0 || x.RBI > 0 || x.R > 0) {
		return false
	}
	return true
}
func validatePitch(x Pitch) bool {
	if x.Apps < 0 || x.Apps > 500 || x.Starts < 0 || x.Starts > x.Apps || x.QS < 0 || x.QS > x.Starts || x.HQS < 0 || x.HQS > x.QS || x.W < 0 || x.W > x.Apps || x.LCandidate < 0 || x.LCandidate > x.Apps || x.SVCandidate < 0 || x.SVCandidate > x.Apps || x.Outs < 0 || x.Outs > 10000 || x.H < 0 || x.BB < 0 || x.HBP < 0 || x.HR < 0 || x.BF < 0 || x.BF > 10000 || x.K < 0 || x.R < 0 || x.ER < 0 {
		return false
	}
	if x.BF > 0 && x.Outs > x.BF*3 {
		return false
	}
	if x.H > x.BF || x.K > x.BF {
		return false
	}
	if x.Apps == 0 && (x.Starts > 0 || x.QS > 0 || x.HQS > 0 || x.W > 0 || x.LCandidate > 0 || x.SVCandidate > 0 || x.Outs > 0 || x.H > 0 || x.BB > 0 || x.HR > 0 || x.BF > 0 || x.K > 0 || x.R > 0 || x.ER > 0) {
		return false
	}
	return true
}
func activityScore(b Bat, p Pitch) int {
	return b.Games*20 + b.PA*3 + b.H*5 + b.HR*10 + p.Apps*30 + p.Starts*10 + p.Outs*2 + p.BF + p.K*2
}
func allZeroStats(b Bat, p Pitch) bool {
	return activityScore(b, p) == 0 && b.RBI == 0 && b.R == 0 && b.BB == 0 && b.HBP == 0 && b.SO == 0 && b.SB == 0 && p.W == 0 && p.LCandidate == 0 && p.SVCandidate == 0 && p.BB == 0 && p.HR == 0 && p.R == 0
}

func parseStats(b []byte, p Player) (StatsInfo, error) {
	offs := findProfileOccurrences(b, p)
	if len(offs) == 0 {
		return StatsInfo{}, errors.New("no matching player records found")
	}
	type c struct {
		off      int
		bat      Bat
		pit      Pitch
		activity int
	}
	var valid []c
	for _, off := range offs {
		if off+0x7e8 > len(b) {
			continue
		}
		bat, pit, ok := parseStatsAt(b, off)
		if ok {
			valid = append(valid, c{off, bat, pit, activityScore(bat, pit)})
		}
	}
	if len(valid) == 0 {
		return StatsInfo{}, fmt.Errorf("%d matching player records found but none passed stat validation", len(offs))
	}
	sort.Slice(valid, func(i, j int) bool {
		if valid[i].activity != valid[j].activity {
			return valid[i].activity > valid[j].activity
		}
		return valid[i].off > valid[j].off
	})
	best := valid[0]
	zeroAmb := best.activity == 0 && len(valid) > 1
	return StatsInfo{RecordOffset: fmt.Sprintf("0x%x", best.off), CandidateCount: len(valid), AmbiguousAllZero: zeroAmb, Bat: batJSON(best.bat), Pitch: pitchJSON(best.pit)}, nil
}
func batJSON(x Bat) BatJSON {
	return BatJSON{x.Games, x.PA, x.AB, x.H, x.Doubles, x.Triples, x.HR, x.RBI, x.R, x.BB, x.HBP, x.SO, x.SB, x.Sac1, x.Sac2}
}
func innings(outs int) string {
	if outs < 0 {
		return ""
	}
	return fmt.Sprintf("%d.%d", outs/3, outs%3)
}
func pitchJSON(x Pitch) PitchJSON {
	return PitchJSON{x.Apps, x.Starts, x.QS, x.HQS, x.W, x.LCandidate, x.SVCandidate, x.Outs, innings(x.Outs), x.H, x.BB, x.HBP, x.BB + x.HBP, x.HR, x.BF, x.K, x.R, x.ER}
}

func ptrInt(v int) *int { return &v }

func decodeGameLogInnings(raw int) (int, string, bool) {
	if raw < 0 {
		return 0, "", false
	}
	whole := raw / 4
	rem := raw % 4
	outsPart := 0
	suffix := 0
	switch rem {
	case 0:
		outsPart, suffix = 0, 0
	case 2:
		outsPart, suffix = 1, 1
	case 3:
		outsPart, suffix = 2, 2
	default:
		return 0, "", false
	}
	return whole*3 + outsPart, fmt.Sprintf("%d.%d", whole, suffix), true
}

func positionNameMapped(code int) (string, string) {
	switch code {
	case 0:
		return "P", "confirmed"
	case 1:
		return "C", "pending"
	case 2:
		return "1B", "pending"
	case 3:
		return "2B", "pending"
	case 4:
		return "3B", "pending"
	case 5:
		return "SS", "pending"
	case 6:
		return "LF", "pending"
	case 7:
		return "CF", "pending"
	case 8:
		return "RF", "pending"
	case 9:
		return "DH", "pending"
	case 10:
		return "PH", "confirmed"
	default:
		return "", "unmapped"
	}
}

func parseGameLogs(b []byte) []PlayerGameLog {
	logs := make([]PlayerGameLog, 0, maxGameLogs)
	for i := 0; i < maxGameLogs; i++ {
		off := gameLogBase + i*gameLogStride
		if off < 0 || off+gameLogStride > len(b) {
			break
		}
		gid := binary.LittleEndian.Uint32(b[off : off+4])
		if gid == 0 {
			break
		}
		bf := int(b[off+0x07])
		innRaw := int(b[off+0x0d])
		pAppeared := bf > 0 || innRaw > 0
		outs, inn, ok := decodeGameLogInnings(innRaw)
		if !ok {
			outs, inn = 0, ""
		}
		decisionCode := int(b[off+0x06])
		pit := GamePitching{
			Appeared: pAppeared, DecisionCode: decisionCode, Win: decisionCode == 1, Loss: decisionCode == 2,
			InningsRaw: innRaw, Outs: outs, Innings: inn,
			BF: bf, H: int(b[off+0x08]), HR: int(b[off+0x09]), K: int(b[off+0x0a]),
			FreePasses: int(b[off+0x0b]), R: int(b[off+0x0c]), ER: int(b[off+0x0e]),
		}
		appearanceCode := int(b[off+0x14])
		bAppeared := appearanceCode != 0
		bat := GameBatting{Appeared: bAppeared}
		if bAppeared {
			lineupRaw := int(b[off+0x15])
			posCode := int(b[off+0x16])
			bat.AppearanceCode = ptrInt(appearanceCode)
			bat.Lineup = ptrInt(lineupRaw + 1)
			bat.PositionCode = ptrInt(posCode)
			bat.Position, _ = positionNameMapped(posCode)
			bat.AB = int(b[off+0x17])
			bat.H = int(b[off+0x18])
			bat.RBI = int(b[off+0x19])
			bat.R = int(b[off+0x1a])
			bat.BB = int(b[off+0x1b])
			bat.HR = int(b[off+0x1c])
			bat.SO = int(b[off+0x1e])
		}
		logs = append(logs, PlayerGameLog{Index: i, GameID: gid, RecordOffset: fmt.Sprintf("0x%x", off), Batting: bat, Pitching: pit})
	}
	return logs
}

func confirmedSeasonStats(st StatsInfo, logs []PlayerGameLog) (ConfirmedSeasonStats, []string) {
	var warnings []string
	batGames, ab, h, rbi, runs, bb, hr, so := 0, 0, 0, 0, 0, 0, 0, 0
	for _, g := range logs {
		if g.Batting.Appeared {
			batGames++
			ab += g.Batting.AB
			h += g.Batting.H
			rbi += g.Batting.RBI
			runs += g.Batting.R
			bb += g.Batting.BB
			hr += g.Batting.HR
			so += g.Batting.SO
		}
	}
	if batGames != st.Bat.Games {
		warnings = append(warnings, fmt.Sprintf("batting games mismatch: game_log=%d season=%d", batGames, st.Bat.Games))
	}
	if ab != st.Bat.AB {
		warnings = append(warnings, fmt.Sprintf("at-bats mismatch: game_log=%d season-derived=%d", ab, st.Bat.AB))
	}
	if h != st.Bat.H {
		warnings = append(warnings, fmt.Sprintf("hits mismatch: game_log=%d season=%d", h, st.Bat.H))
	}
	if rbi != st.Bat.RBI || runs != st.Bat.R || bb != st.Bat.BB || hr != st.Bat.HR || so != st.Bat.SO {
		warnings = append(warnings, "one or more batting totals differ between game log and season counters")
	}
	avg := 0.0
	if ab > 0 {
		avg = float64(h) / float64(ab)
	}
	bat := SeasonBatConfirmed{
		Games: batGames, AB: ab, H: h, Singles: st.Bat.H - st.Bat.Doubles - st.Bat.Triples - st.Bat.HR,
		Doubles: st.Bat.Doubles, Triples: st.Bat.Triples, HR: st.Bat.HR,
		RBI: rbi, R: runs, BB: bb, SO: so, Average: avg,
	}
	ip := float64(st.Pitch.Outs) / 3.0
	era, whip, kbb, k9, bb9, hr9 := 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
	if ip > 0 {
		era = float64(st.Pitch.ER) * 9.0 / ip
		whip = float64(st.Pitch.H+st.Pitch.BB) / ip
		k9 = float64(st.Pitch.K) * 9.0 / ip
		bb9 = float64(st.Pitch.BB) * 9.0 / ip
		hr9 = float64(st.Pitch.HR) * 9.0 / ip
	}
	if st.Pitch.BB > 0 {
		kbb = float64(st.Pitch.K) / float64(st.Pitch.BB)
	}
	pit := SeasonPitchConfirmed{
		Apps: st.Pitch.Apps, Starts: st.Pitch.Starts, QS: st.Pitch.QS, W: st.Pitch.W, L: st.Pitch.LCandidate,
		Outs: st.Pitch.Outs, Innings: innings(st.Pitch.Outs), H: st.Pitch.H, BB: st.Pitch.BB,
		HBP: st.Pitch.HBP, HR: st.Pitch.HR, BF: st.Pitch.BF, K: st.Pitch.K, R: st.Pitch.R, ER: st.Pitch.ER,
		ERA: era, WHIP: whip, KBB: kbb, K9: k9, BB9: bb9, HR9: hr9,
	}
	return ConfirmedSeasonStats{Batting: bat, Pitching: pit}, warnings
}

func pendingFields() PendingFields {
	return PendingFields{
		Batting: []string{
			"plate_appearances (raw candidate +0x77C; exact identity not yet independently verified)",
			"hit_by_pitch (raw candidate +0x78A; no positive sample)",
			"stolen_bases (raw candidate +0x782; no positive sample)",
			"sacrifice fields +0x780/+0x786 (exact bunt/fly identity not verified)",
		},
		Pitching: []string{
			"high_quality_starts (raw candidate +0x766; season screen matches, but no observed +1 transition)",
			"saves (raw candidate +0x74C; no positive sample)",
			"pitch_count (not mapped)",
		},
		GameLog: []string{
			"pitching walks and HBP are stored only as a combined free-pass count in the confirmed direct game-log fields; before/after season deltas are used to split them when exactly one new game is detected",
			"pitching decision codes 1=win and 2=loss are confirmed from positive game samples",
			"position codes 0=P and 10=PH are confirmed; codes 1=C, 2=1B, 3=2B, 4=3B, 5=SS, 6=LF, 7=CF, 8=RF, 9=DH are provisional mappings and remain pending",
			"single-game batting HBP, stolen bases, doubles and triples are not yet mapped from the direct game log",
		},
	}
}

func parseScore(logical []byte, h Header) ScoreResult {
	if h.TeamCode == 0 {
		return ScoreResult{Verified: false, Note: "team name was not found in the engine's 12-team code table"}
	}
	date, err := time.Parse("2006-01-02", h.Date)
	if err != nil {
		return ScoreResult{Verified: false, TeamCode: h.TeamCode, Note: err.Error()}
	}
	jan1 := time.Date(date.Year(), 1, 1, 0, 0, 0, 0, time.UTC)
	cur := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, time.UTC)
	dayIndex := int(cur.Sub(jan1).Hours() / 24)
	for back := 0; back < maxScoreSearchBack && dayIndex-back >= 0; back++ {
		di := dayIndex - back
		dayCandidates := 0
		var found *ScoreResult
		for slot := 0; slot < slotsPerDay; slot++ {
			so := scheduleBase + di*scheduleDayStride + scheduleSlotBase + slot*scheduleSlotStride
			ro := scoreBase + di*scoreDayStride + slot*scoreSlotStride
			if so+8 > len(logical) || ro+2 > len(logical) {
				continue
			}
			a := int(binary.LittleEndian.Uint32(logical[so : so+4]))
			bb := int(binary.LittleEndian.Uint32(logical[so+4 : so+8]))
			if a != h.TeamCode && bb != h.TeamCode {
				continue
			}
			s1, s2 := int(logical[ro]), int(logical[ro+1])
			if s1 == 255 || s2 == 255 || s1 > 50 || s2 > 50 {
				continue
			}
			dayCandidates++
			ts, os, opp := s1, s2, bb
			venue := "home"
			if bb == h.TeamCode {
				ts, os, opp = s2, s1, a
				venue = "away"
			}
			oc := "D"
			if ts > os {
				oc = "W"
			} else if ts < os {
				oc = "L"
			}
			oppName := ""
			if ti, ok := teamByCode(opp); ok {
				oppName = ti.Name
			}
			// The save's schedule day index is 1-based relative to Jan 1.
			// Screenshot ground truth: index previously labeled 2026-04-23 is the 2026-04-24 game.
			gameDate := jan1.AddDate(0, 0, di+1).Format("2006-01-02")
			r := ScoreResult{Verified: true, Date: gameDate, TeamScore: &ts, OpponentScore: &os, Outcome: oc, TeamCode: h.TeamCode, OpponentCode: opp, Opponent: oppName, Venue: venue, ScheduleOffset: fmt.Sprintf("0x%x", so), RecordOffset: fmt.Sprintf("0x%x", ro), Candidates: 1}
			found = &r
		}
		if dayCandidates == 1 && found != nil {
			found.Candidates = 1
			return *found
		}
		if dayCandidates > 1 {
			return ScoreResult{Verified: false, TeamCode: h.TeamCode, Candidates: dayCandidates, Note: fmt.Sprintf("multiple completed candidates on %s", jan1.AddDate(0, 0, di+1).Format("2006-01-02"))}
		}
	}
	return ScoreResult{Verified: false, TeamCode: h.TeamCode, Candidates: 0, Note: "no completed game for this team found in the engine's 15-day backward search window"}
}

func parseOne(path string) (Snapshot, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return Snapshot{}, err
	}
	h, err := parseHeader(raw)
	if err != nil {
		return Snapshot{}, err
	}
	logical, ci, err := decryptSave(raw)
	if err != nil {
		return Snapshot{}, err
	}
	p, err := parsePlayerIdentity(logical)
	if err != nil {
		return Snapshot{}, err
	}
	st, err := parseStats(logical, p)
	if err != nil {
		return Snapshot{}, err
	}
	logs := parseGameLogs(logical)
	confirmed, statWarnings := confirmedSeasonStats(st, logs)
	sc := parseScore(logical, h)
	var warnings []string
	warnings = append(warnings, statWarnings...)
	if st.Pitch.ER > st.Pitch.R {
		warnings = append(warnings, "earned_runs exceeds runs; pitching field mapping or save data should be rechecked")
	}
	if st.Pitch.HR > st.Pitch.R {
		warnings = append(warnings, "home_runs_allowed exceeds runs; pitching field mapping or save data should be rechecked")
	}
	var latest *PlayerGameLog
	if len(logs) > 0 {
		x := logs[len(logs)-1]
		latest = &x
	}
	limits := []string{
		"v1.6 default output contains only fields considered confirmed from supplied save/screen/game-log cross-checks.",
		"Direct single-game records are read from the 0x48-byte player game-log table (corrected table base 0x24BF8).",
		"Schedule/score data supplies date, opponent, home/away, score and team outcome.",
		"Pitching game-log free passes are a confirmed combined BB+HBP count; --compare splits BB/HBP only when exactly one new game is present and the confirmed season deltas agree with the game-log total.",
		"Unverified candidate fields are listed under pending_fields and are not emitted as confirmed values.",
	}
	return Snapshot{File: filepath.Base(path), Header: h, Player: p, Crypto: ci, ConfirmedSeason: confirmed, Pending: pendingFields(), LatestPlayerGame: latest, LastCompletedGame: sc, ValidationWarnings: warnings, Limits: limits, Stats: st, GameLogs: logs}, nil
}

func newGameLogs(before, after []PlayerGameLog) []PlayerGameLog {
	seen := make(map[uint32]bool, len(before))
	for _, g := range before {
		seen[g.GameID] = true
	}
	var out []PlayerGameLog
	for _, g := range after {
		if !seen[g.GameID] {
			out = append(out, g)
		}
	}
	return out
}

func compareSnapshots(before, after Snapshot) DetectedGame {
	res := DetectedGame{Before: before.File, After: after.File, Player: after.Player.FullName, Score: after.LastCompletedGame}
	if before.Player.ID != after.Player.ID || before.Player.FullName != after.Player.FullName || before.Header.TeamCode != after.Header.TeamCode {
		res.Warnings = append(res.Warnings, "PLAYER_MISMATCH: before/after are not the same player/team")
		return res
	}
	ng := newGameLogs(before.GameLogs, after.GameLogs)
	res.NewGameLogCount = len(ng)
	if len(ng) != 1 {
		if len(ng) == 0 {
			res.Warnings = append(res.Warnings, "no new player game-log record detected")
		} else {
			res.Warnings = append(res.Warnings, fmt.Sprintf("%d new game-log records detected; refusing to collapse multiple games into one", len(ng)))
		}
		return res
	}
	g := ng[0]
	verified := true
	// Confirm direct batting fields against season cumulative changes where those cumulative fields are confirmed.
	checks := [][3]int{
		{g.Batting.AB, after.ConfirmedSeason.Batting.AB - before.ConfirmedSeason.Batting.AB, 1},
		{g.Batting.H, after.ConfirmedSeason.Batting.H - before.ConfirmedSeason.Batting.H, 2},
		{g.Batting.RBI, after.ConfirmedSeason.Batting.RBI - before.ConfirmedSeason.Batting.RBI, 3},
		{g.Batting.R, after.ConfirmedSeason.Batting.R - before.ConfirmedSeason.Batting.R, 4},
		{g.Batting.BB, after.ConfirmedSeason.Batting.BB - before.ConfirmedSeason.Batting.BB, 5},
		{g.Batting.HR, after.ConfirmedSeason.Batting.HR - before.ConfirmedSeason.Batting.HR, 6},
		{g.Batting.SO, after.ConfirmedSeason.Batting.SO - before.ConfirmedSeason.Batting.SO, 7},
	}
	for _, c := range checks {
		if c[0] != c[1] {
			verified = false
			res.Warnings = append(res.Warnings, fmt.Sprintf("batting direct/delta mismatch check %d: game_log=%d season_delta=%d", c[2], c[0], c[1]))
		}
	}
	if g.Pitching.Appeared {
		bbd := after.Stats.Pitch.BB - before.Stats.Pitch.BB
		hbpd := after.Stats.Pitch.HBP - before.Stats.Pitch.HBP
		if bbd >= 0 && hbpd >= 0 && bbd+hbpd == g.Pitching.FreePasses {
			g.Pitching.BB = ptrInt(bbd)
			g.Pitching.HBP = ptrInt(hbpd)
		} else {
			verified = false
			res.Warnings = append(res.Warnings, fmt.Sprintf("pitching BB/HBP split not verified: season_delta BB=%d HBP=%d, game_log free_passes=%d", bbd, hbpd, g.Pitching.FreePasses))
		}
		pitchChecks := [][3]int{
			{g.Pitching.Outs, after.ConfirmedSeason.Pitching.Outs - before.ConfirmedSeason.Pitching.Outs, 1},
			{g.Pitching.H, after.ConfirmedSeason.Pitching.H - before.ConfirmedSeason.Pitching.H, 2},
			{g.Pitching.HR, after.ConfirmedSeason.Pitching.HR - before.ConfirmedSeason.Pitching.HR, 3},
			{g.Pitching.BF, after.ConfirmedSeason.Pitching.BF - before.ConfirmedSeason.Pitching.BF, 4},
			{g.Pitching.K, after.ConfirmedSeason.Pitching.K - before.ConfirmedSeason.Pitching.K, 5},
			{g.Pitching.R, after.ConfirmedSeason.Pitching.R - before.ConfirmedSeason.Pitching.R, 6},
			{g.Pitching.ER, after.ConfirmedSeason.Pitching.ER - before.ConfirmedSeason.Pitching.ER, 7},
		}
		for _, c := range pitchChecks {
			if c[0] != c[1] {
				verified = false
				res.Warnings = append(res.Warnings, fmt.Sprintf("pitching direct/delta mismatch check %d: game_log=%d season_delta=%d", c[2], c[0], c[1]))
			}
		}
	}
	if !after.LastCompletedGame.Verified {
		verified = false
		res.Warnings = append(res.Warnings, "latest schedule/score record was not verified")
	}
	res.Game = &g
	res.Verified = verified
	return res
}

type ContractField struct {
	Value  interface{} `json:"value"`
	Status string      `json:"status"`
}

type ContractPlayer struct {
	ID   uint32 `json:"id"`
	Name string `json:"name"`
	Team string `json:"team"`
}

type ContractGame struct {
	Date          ContractField `json:"date"`
	Opponent      ContractField `json:"opponent"`
	HomeAway      ContractField `json:"home_away"`
	TeamScore     ContractField `json:"team_score"`
	OpponentScore ContractField `json:"opponent_score"`
	Result        ContractField `json:"result"`
}

type ContractBatting struct {
	LineupOrder            ContractField `json:"lineup_order"`
	Position               ContractField `json:"position"`
	PlateAppearances       ContractField `json:"plate_appearances"`
	AtBats                 ContractField `json:"at_bats"`
	Hits                   ContractField `json:"hits"`
	Singles                ContractField `json:"singles"`
	Doubles                ContractField `json:"doubles"`
	Triples                ContractField `json:"triples"`
	HomeRuns               ContractField `json:"home_runs"`
	RBI                    ContractField `json:"rbi"`
	Runs                   ContractField `json:"runs"`
	Walks                  ContractField `json:"walks"`
	HBP                    ContractField `json:"hbp"`
	Strikeouts             ContractField `json:"strikeouts"`
	StolenBases            ContractField `json:"stolen_bases"`
	GroundedIntoDoublePlay ContractField `json:"grounded_into_double_play"`
	Errors                 ContractField `json:"errors"`
}

type ContractPitching struct {
	Appeared         ContractField `json:"appeared"`
	Started          ContractField `json:"started"`
	InningsOuts      ContractField `json:"innings_outs"`
	BattersFaced     ContractField `json:"batters_faced"`
	PitchCount       ContractField `json:"pitch_count"`
	HitsAllowed      ContractField `json:"hits_allowed"`
	HomeRunsAllowed  ContractField `json:"home_runs_allowed"`
	Walks            ContractField `json:"walks"`
	HBP              ContractField `json:"hbp"`
	Strikeouts       ContractField `json:"strikeouts"`
	Runs             ContractField `json:"runs"`
	EarnedRuns       ContractField `json:"earned_runs"`
	Win              ContractField `json:"win"`
	Loss             ContractField `json:"loss"`
	NoDecision       ContractField `json:"no_decision"`
	Hold             ContractField `json:"hold"`
	Save             ContractField `json:"save"`
	BlownSave        ContractField `json:"blown_save"`
	QualityStart     ContractField `json:"quality_start"`
	QualityStartPlus ContractField `json:"quality_start_plus"`
}

type ContractSeason struct {
	Batting  ContractSeasonBatting  `json:"batting"`
	Pitching ContractSeasonPitching `json:"pitching"`
}

type ContractSeasonBatting struct {
	Games                  ContractField `json:"games"`
	PlateAppearances       ContractField `json:"plate_appearances"`
	AtBats                 ContractField `json:"at_bats"`
	Hits                   ContractField `json:"hits"`
	Singles                ContractField `json:"singles"`
	Doubles                ContractField `json:"doubles"`
	Triples                ContractField `json:"triples"`
	HomeRuns               ContractField `json:"home_runs"`
	RBI                    ContractField `json:"rbi"`
	Runs                   ContractField `json:"runs"`
	Walks                  ContractField `json:"walks"`
	HBP                    ContractField `json:"hbp"`
	Strikeouts             ContractField `json:"strikeouts"`
	StolenBases            ContractField `json:"stolen_bases"`
	GroundedIntoDoublePlay ContractField `json:"grounded_into_double_play"`
	Errors                 ContractField `json:"errors"`
}

type ContractSeasonPitching struct {
	Appearances      ContractField `json:"appearances"`
	Starts           ContractField `json:"starts"`
	InningsOuts      ContractField `json:"innings_outs"`
	BattersFaced     ContractField `json:"batters_faced"`
	PitchCount       ContractField `json:"pitch_count"`
	HitsAllowed      ContractField `json:"hits_allowed"`
	HomeRunsAllowed  ContractField `json:"home_runs_allowed"`
	Walks            ContractField `json:"walks"`
	HBP              ContractField `json:"hbp"`
	Strikeouts       ContractField `json:"strikeouts"`
	Runs             ContractField `json:"runs"`
	EarnedRuns       ContractField `json:"earned_runs"`
	Wins             ContractField `json:"wins"`
	Losses           ContractField `json:"losses"`
	Holds            ContractField `json:"holds"`
	Saves            ContractField `json:"saves"`
	BlownSaves       ContractField `json:"blown_saves"`
	QualityStarts    ContractField `json:"quality_starts"`
	QualityStartPlus ContractField `json:"quality_start_plus"`
}

type ContractVerification struct {
	Verified        bool     `json:"verified"`
	NewGameLogCount int      `json:"new_game_log_count,omitempty"`
	Warnings        []string `json:"warnings,omitempty"`
}

type ContractSource struct {
	Mode   string `json:"mode"`
	File   string `json:"file,omitempty"`
	Before string `json:"before,omitempty"`
	After  string `json:"after,omitempty"`
}

type ContractOutput struct {
	SchemaVersion int                  `json:"schema_version"`
	ReaderVersion string               `json:"reader_version"`
	Source        ContractSource       `json:"source"`
	Player        ContractPlayer       `json:"player"`
	Capabilities  map[string]string    `json:"capabilities"`
	Game          ContractGame         `json:"game"`
	Batting       ContractBatting      `json:"batting"`
	Pitching      ContractPitching     `json:"pitching"`
	Season        ContractSeason       `json:"season"`
	Verification  ContractVerification `json:"verification"`
}

func cf(value interface{}, status string) ContractField {
	return ContractField{Value: value, Status: status}
}
func nilcf(status string) ContractField {
	return ContractField{Value: nil, Status: status}
}

func contractCapabilities() map[string]string {
	return map[string]string{
		"game.date":           "confirmed",
		"game.opponent":       "confirmed",
		"game.home_away":      "confirmed",
		"game.team_score":     "confirmed",
		"game.opponent_score": "confirmed",
		"game.result":         "confirmed",

		"game.batting.lineup_order":              "confirmed",
		"game.batting.position":                  "pending",
		"game.batting.plate_appearances":         "unmapped",
		"game.batting.at_bats":                   "confirmed",
		"game.batting.hits":                      "confirmed",
		"game.batting.singles":                   "confirmed",
		"game.batting.doubles":                   "confirmed",
		"game.batting.triples":                   "confirmed",
		"game.batting.home_runs":                 "confirmed",
		"game.batting.rbi":                       "confirmed",
		"game.batting.runs":                      "confirmed",
		"game.batting.walks":                     "confirmed",
		"game.batting.hbp":                       "pending",
		"game.batting.strikeouts":                "confirmed",
		"game.batting.stolen_bases":              "pending",
		"game.batting.grounded_into_double_play": "unmapped",
		"game.batting.errors":                    "unmapped",

		"game.pitching.appeared":           "confirmed",
		"game.pitching.started":            "pending",
		"game.pitching.innings_outs":       "confirmed",
		"game.pitching.batters_faced":      "confirmed",
		"game.pitching.pitch_count":        "unmapped",
		"game.pitching.hits_allowed":       "confirmed",
		"game.pitching.home_runs_allowed":  "confirmed",
		"game.pitching.walks":              "confirmed",
		"game.pitching.hbp":                "confirmed",
		"game.pitching.strikeouts":         "confirmed",
		"game.pitching.runs":               "confirmed",
		"game.pitching.earned_runs":        "confirmed",
		"game.pitching.win":                "confirmed",
		"game.pitching.loss":               "confirmed",
		"game.pitching.no_decision":        "confirmed",
		"game.pitching.hold":               "unmapped",
		"game.pitching.save":               "pending",
		"game.pitching.blown_save":         "unmapped",
		"game.pitching.quality_start":      "confirmed",
		"game.pitching.quality_start_plus": "pending",

		"season.batting.games":                     "confirmed",
		"season.batting.plate_appearances":         "pending",
		"season.batting.at_bats":                   "confirmed",
		"season.batting.hits":                      "confirmed",
		"season.batting.singles":                   "confirmed",
		"season.batting.doubles":                   "confirmed",
		"season.batting.triples":                   "confirmed",
		"season.batting.home_runs":                 "confirmed",
		"season.batting.rbi":                       "confirmed",
		"season.batting.runs":                      "confirmed",
		"season.batting.walks":                     "confirmed",
		"season.batting.hbp":                       "pending",
		"season.batting.strikeouts":                "confirmed",
		"season.batting.stolen_bases":              "pending",
		"season.batting.grounded_into_double_play": "unmapped",
		"season.batting.errors":                    "unmapped",

		"season.pitching.appearances":        "confirmed",
		"season.pitching.starts":             "pending",
		"season.pitching.innings_outs":       "confirmed",
		"season.pitching.batters_faced":      "confirmed",
		"season.pitching.pitch_count":        "unmapped",
		"season.pitching.hits_allowed":       "confirmed",
		"season.pitching.home_runs_allowed":  "confirmed",
		"season.pitching.walks":              "confirmed",
		"season.pitching.hbp":                "confirmed",
		"season.pitching.strikeouts":         "confirmed",
		"season.pitching.runs":               "confirmed",
		"season.pitching.earned_runs":        "confirmed",
		"season.pitching.wins":               "confirmed",
		"season.pitching.losses":             "confirmed",
		"season.pitching.holds":              "unmapped",
		"season.pitching.saves":              "pending",
		"season.pitching.blown_saves":        "unmapped",
		"season.pitching.quality_starts":     "confirmed",
		"season.pitching.quality_start_plus": "pending",
	}
}

func contractGame(score ScoreResult) ContractGame {
	g := ContractGame{
		Date: nilcf("confirmed"), Opponent: nilcf("confirmed"), HomeAway: nilcf("confirmed"),
		TeamScore: nilcf("confirmed"), OpponentScore: nilcf("confirmed"), Result: nilcf("confirmed"),
	}
	if !score.Verified {
		return g
	}
	g.Date = cf(score.Date, "confirmed")
	g.Opponent = cf(score.Opponent, "confirmed")
	g.HomeAway = cf(score.Venue, "confirmed")
	if score.TeamScore != nil {
		g.TeamScore = cf(*score.TeamScore, "confirmed")
	}
	if score.OpponentScore != nil {
		g.OpponentScore = cf(*score.OpponentScore, "confirmed")
	}
	switch score.Outcome {
	case "W":
		g.Result = cf("win", "confirmed")
	case "L":
		g.Result = cf("loss", "confirmed")
	case "D":
		g.Result = cf("draw", "confirmed")
	}
	return g
}

func emptyContractBatting() ContractBatting {
	return ContractBatting{
		LineupOrder: nilcf("confirmed"), Position: nilcf("pending"), PlateAppearances: nilcf("unmapped"),
		AtBats: nilcf("confirmed"), Hits: nilcf("confirmed"), Singles: nilcf("confirmed"), Doubles: nilcf("confirmed"),
		Triples: nilcf("confirmed"), HomeRuns: nilcf("confirmed"), RBI: nilcf("confirmed"), Runs: nilcf("confirmed"),
		Walks: nilcf("confirmed"), HBP: nilcf("pending"), Strikeouts: nilcf("confirmed"), StolenBases: nilcf("pending"),
		GroundedIntoDoublePlay: nilcf("unmapped"), Errors: nilcf("unmapped"),
	}
}
func contractBattingFromLog(g *PlayerGameLog) ContractBatting {
	b := emptyContractBatting()
	if g == nil || !g.Batting.Appeared {
		return b
	}
	if g.Batting.Lineup != nil {
		b.LineupOrder = cf(*g.Batting.Lineup, "confirmed")
	}
	if g.Batting.PositionCode != nil {
		pos, status := positionNameMapped(*g.Batting.PositionCode)
		if pos != "" {
			b.Position = cf(pos, status)
		} else {
			b.Position = nilcf("unmapped")
		}
	}
	b.AtBats = cf(g.Batting.AB, "confirmed")
	b.Hits = cf(g.Batting.H, "confirmed")
	b.HomeRuns = cf(g.Batting.HR, "confirmed")
	b.RBI = cf(g.Batting.RBI, "confirmed")
	b.Runs = cf(g.Batting.R, "confirmed")
	b.Walks = cf(g.Batting.BB, "confirmed")
	b.Strikeouts = cf(g.Batting.SO, "confirmed")
	return b
}
func fillCompareBattingFields(b *ContractBatting, before, after Snapshot, g *PlayerGameLog, warnings *[]string) {
	if g == nil || !g.Batting.Appeared {
		return
	}
	d2 := after.Stats.Bat.Doubles - before.Stats.Bat.Doubles
	d3 := after.Stats.Bat.Triples - before.Stats.Bat.Triples
	ds := after.ConfirmedSeason.Batting.Singles - before.ConfirmedSeason.Batting.Singles
	if d2 >= 0 && d3 >= 0 && ds >= 0 && ds+d2+d3+g.Batting.HR == g.Batting.H {
		b.Singles, b.Doubles, b.Triples = cf(ds, "confirmed"), cf(d2, "confirmed"), cf(d3, "confirmed")
	} else {
		b.Singles, b.Doubles, b.Triples = nilcf("pending"), nilcf("pending"), nilcf("pending")
		*warnings = append(*warnings, "single-game extra-base-hit split did not validate against season deltas")
	}
	if d := after.Stats.Bat.PA - before.Stats.Bat.PA; d >= 0 {
		b.PlateAppearances = cf(d, "pending")
	}
	if d := after.Stats.Bat.HBP - before.Stats.Bat.HBP; d >= 0 {
		b.HBP = cf(d, "pending")
	}
	if d := after.Stats.Bat.SB - before.Stats.Bat.SB; d >= 0 {
		b.StolenBases = cf(d, "pending")
	}
}

func emptyContractPitching() ContractPitching {
	return ContractPitching{
		Appeared: cf(false, "confirmed"), Started: nilcf("pending"), InningsOuts: nilcf("confirmed"),
		BattersFaced: nilcf("confirmed"), PitchCount: nilcf("unmapped"), HitsAllowed: nilcf("confirmed"),
		HomeRunsAllowed: nilcf("confirmed"), Walks: nilcf("confirmed"), HBP: nilcf("confirmed"),
		Strikeouts: nilcf("confirmed"), Runs: nilcf("confirmed"), EarnedRuns: nilcf("confirmed"),
		Win: cf(false, "confirmed"), Loss: cf(false, "confirmed"), NoDecision: cf(false, "confirmed"),
		Hold: nilcf("unmapped"), Save: nilcf("pending"), BlownSave: nilcf("unmapped"),
		QualityStart: nilcf("confirmed"), QualityStartPlus: nilcf("pending"),
	}
}
func contractPitchingFromLog(g *PlayerGameLog) ContractPitching {
	p := emptyContractPitching()
	if g == nil || !g.Pitching.Appeared {
		return p
	}
	p.Appeared = cf(true, "confirmed")
	p.InningsOuts = cf(g.Pitching.Outs, "confirmed")
	p.BattersFaced = cf(g.Pitching.BF, "confirmed")
	p.HitsAllowed = cf(g.Pitching.H, "confirmed")
	p.HomeRunsAllowed = cf(g.Pitching.HR, "confirmed")
	p.Strikeouts = cf(g.Pitching.K, "confirmed")
	p.Runs = cf(g.Pitching.R, "confirmed")
	p.EarnedRuns = cf(g.Pitching.ER, "confirmed")
	p.Win = cf(g.Pitching.DecisionCode == 1, "confirmed")
	p.Loss = cf(g.Pitching.DecisionCode == 2, "confirmed")
	p.NoDecision = cf(g.Pitching.DecisionCode == 0, "confirmed")
	if g.Pitching.FreePasses == 0 {
		p.Walks, p.HBP = cf(0, "confirmed"), cf(0, "confirmed")
	}
	return p
}
func fillComparePitchingFields(p *ContractPitching, before, after Snapshot, g *PlayerGameLog, warnings *[]string) {
	if g == nil || !g.Pitching.Appeared {
		return
	}
	if g.Pitching.BB != nil && g.Pitching.HBP != nil {
		p.Walks, p.HBP = cf(*g.Pitching.BB, "confirmed"), cf(*g.Pitching.HBP, "confirmed")
	} else if g.Pitching.FreePasses > 0 {
		p.Walks, p.HBP = nilcf("pending"), nilcf("pending")
	}
	if d := after.Stats.Pitch.Starts - before.Stats.Pitch.Starts; d == 0 || d == 1 {
		p.Started = cf(d == 1, "pending")
	}
	if d := after.Stats.Pitch.SVCandidate - before.Stats.Pitch.SVCandidate; d >= 0 && d <= 1 {
		p.Save = cf(d == 1, "pending")
	}
	if d := after.Stats.Pitch.QS - before.Stats.Pitch.QS; d == 0 || d == 1 {
		p.QualityStart = cf(d == 1, "confirmed")
	} else {
		p.QualityStart = nilcf("pending")
		*warnings = append(*warnings, "quality-start delta was outside expected 0/1 range")
	}
	if d := after.Stats.Pitch.HQS - before.Stats.Pitch.HQS; d == 0 || d == 1 {
		p.QualityStartPlus = cf(d == 1, "pending")
	}
}

func contractSeason(s Snapshot) ContractSeason {
	sb, sp := s.ConfirmedSeason.Batting, s.ConfirmedSeason.Pitching
	return ContractSeason{
		Batting: ContractSeasonBatting{
			Games: cf(sb.Games, "confirmed"), PlateAppearances: cf(s.Stats.Bat.PA, "pending"), AtBats: cf(sb.AB, "confirmed"),
			Hits: cf(sb.H, "confirmed"), Singles: cf(sb.Singles, "confirmed"), Doubles: cf(sb.Doubles, "confirmed"),
			Triples: cf(sb.Triples, "confirmed"), HomeRuns: cf(sb.HR, "confirmed"), RBI: cf(sb.RBI, "confirmed"), Runs: cf(sb.R, "confirmed"),
			Walks: cf(sb.BB, "confirmed"), HBP: cf(s.Stats.Bat.HBP, "pending"), Strikeouts: cf(sb.SO, "confirmed"),
			StolenBases: cf(s.Stats.Bat.SB, "pending"), GroundedIntoDoublePlay: nilcf("unmapped"), Errors: nilcf("unmapped"),
		},
		Pitching: ContractSeasonPitching{
			Appearances: cf(sp.Apps, "confirmed"), Starts: cf(sp.Starts, "pending"), InningsOuts: cf(sp.Outs, "confirmed"),
			BattersFaced: cf(sp.BF, "confirmed"), PitchCount: nilcf("unmapped"), HitsAllowed: cf(sp.H, "confirmed"),
			HomeRunsAllowed: cf(sp.HR, "confirmed"), Walks: cf(sp.BB, "confirmed"), HBP: cf(sp.HBP, "confirmed"),
			Strikeouts: cf(sp.K, "confirmed"), Runs: cf(sp.R, "confirmed"), EarnedRuns: cf(sp.ER, "confirmed"),
			Wins: cf(sp.W, "confirmed"), Losses: cf(sp.L, "confirmed"), Holds: nilcf("unmapped"),
			Saves: cf(s.Stats.Pitch.SVCandidate, "pending"), BlownSaves: nilcf("unmapped"),
			QualityStarts: cf(sp.QS, "confirmed"), QualityStartPlus: cf(s.Stats.Pitch.HQS, "pending"),
		},
	}
}

func contractFromSnapshot(s Snapshot) ContractOutput {
	warnings := append([]string{}, s.ValidationWarnings...)
	bat, pit := emptyContractBatting(), emptyContractPitching()
	if s.LatestPlayerGame != nil {
		bat, pit = contractBattingFromLog(s.LatestPlayerGame), contractPitchingFromLog(s.LatestPlayerGame)
	}
	return ContractOutput{
		SchemaVersion: 1, ReaderVersion: "1.8", Source: ContractSource{Mode: "snapshot", File: s.File},
		Player:       ContractPlayer{ID: s.Player.ID, Name: s.Player.FullName, Team: s.Header.Team},
		Capabilities: contractCapabilities(), Game: contractGame(s.LastCompletedGame), Batting: bat, Pitching: pit,
		Season: contractSeason(s), Verification: ContractVerification{Verified: s.LastCompletedGame.Verified, Warnings: warnings},
	}
}
func contractFromCompare(before, after Snapshot, detected DetectedGame) ContractOutput {
	warnings := append([]string{}, detected.Warnings...)
	warnings = append(warnings, after.ValidationWarnings...)
	bat, pit := contractBattingFromLog(detected.Game), contractPitchingFromLog(detected.Game)
	if detected.Game != nil {
		fillCompareBattingFields(&bat, before, after, detected.Game, &warnings)
		fillComparePitchingFields(&pit, before, after, detected.Game, &warnings)
	}
	return ContractOutput{
		SchemaVersion: 1, ReaderVersion: "1.8", Source: ContractSource{Mode: "compare", Before: before.File, After: after.File},
		Player:       ContractPlayer{ID: after.Player.ID, Name: after.Player.FullName, Team: after.Header.Team},
		Capabilities: contractCapabilities(), Game: contractGame(detected.Score), Batting: bat, Pitching: pit,
		Season: contractSeason(after), Verification: ContractVerification{Verified: detected.Verified, NewGameLogCount: detected.NewGameLogCount, Warnings: warnings},
	}
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage:\n  SPCS_SaveReader_Contract_v1_8 <save1.dat> [save2.dat ...]\n  SPCS_SaveReader_Contract_v1_8 --compare <before.dat> <after.dat>\n  (--delta is accepted as an alias for --compare)")
		os.Exit(2)
	}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if os.Args[1] == "--compare" || os.Args[1] == "--delta" {
		if len(os.Args) != 4 {
			fmt.Fprintln(os.Stderr, "--compare requires before.dat and after.dat")
			os.Exit(2)
		}
		before, err := parseOne(os.Args[2])
		if err != nil {
			fmt.Fprintln(os.Stderr, "before:", err)
			os.Exit(1)
		}
		after, err := parseOne(os.Args[3])
		if err != nil {
			fmt.Fprintln(os.Stderr, "after:", err)
			os.Exit(1)
		}
		detected := compareSnapshots(before, after)
		if err := enc.Encode(contractFromCompare(before, after, detected)); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	results := make([]ContractOutput, 0, len(os.Args)-1)
	failed := false
	for _, path := range os.Args[1:] {
		s, err := parseOne(path)
		if err != nil {
			failed = true
			fmt.Fprintf(os.Stderr, "%s: %v\n", path, err)
			continue
		}
		results = append(results, contractFromSnapshot(s))
	}
	if err := enc.Encode(results); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if failed {
		os.Exit(1)
	}
}

func init() { _ = hex.EncodeToString }
