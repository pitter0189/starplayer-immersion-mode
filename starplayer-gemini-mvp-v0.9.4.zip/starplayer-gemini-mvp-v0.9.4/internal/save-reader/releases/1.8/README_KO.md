# SPCS SaveReader Contract v1.8

몰입모드 연동용 고정 JSON 스키마(`schema_version: 1`)를 유지하는 SaveReader입니다.

## v1.8 핵심

- GAME LOG 포지션 코드를 다음과 같이 우선 매핑합니다.
  - `0 = P` — **confirmed**
  - `1 = C` — pending
  - `2 = 1B` — pending
  - `3 = 2B` — pending
  - `4 = 3B` — pending
  - `5 = SS` — pending
  - `6 = LF` — pending
  - `7 = CF` — pending
  - `8 = RF` — pending
  - `9 = DH` — pending
  - `10 = PH` — **confirmed**
- `1~9`는 시리즈 내부 포지션 enum 자료와 구조적 연속성을 근거로 한 임시 매핑입니다. 아직 이 SaveReader의 실제 GAME LOG 표본으로 직접 검증하지 않았으므로 **자동입력 금지(pending)** 상태입니다.
- 실제 플레이 검증이 끝난 코드만 같은 필드명 그대로 `confirmed`로 승격합니다.
- 승/패/승패 없음 매핑은 v1.7과 동일하게 confirmed 유지합니다.
- 투구 수는 계속 고정 스키마에 존재하지만 `unmapped`입니다.

## 사용

단일 저장본:

```text
SPCS_SaveReader_Contract_v1_8.exe StarPlayer.dat
```

경기 전/후 비교:

```text
SPCS_SaveReader_Contract_v1_8.exe --compare before.dat after.dat
```

몰입모드는 `status: "confirmed"`인 값만 자동 입력해야 합니다.
