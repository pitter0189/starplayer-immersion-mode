# v0.8.0

- SaveReader Contract v1.7 기본 탑재
- 투수 승 / 패 / 승패 없음 확정 자동매핑
- SaveReader 내부 오프셋/버전 의존 제거, 고정 `schema_version=1` 계약으로 전환
- `confirmed` 값만 자동입력, `pending` / `unmapped` / `null`은 비워둠
- 기존 미매핑 필드가 향후 `confirmed`로 변경되면 앱 수정 없이 자동 사용
- 모르는 신규 필드는 무시하여 하위 호환 유지
- 설정 화면에서 SaveReader ZIP 직접 업데이트
- 업데이트 전 기존 판독기 자동 백업
- 최초 연결 DAT를 season anchor로 별도 보존
- 고정 스키마용 병살/실책/블론/승패 없음 등 내부 기록 슬롯 확장
- 투구 수는 현재 unmapped이지만 고정 슬롯 유지: 향후 confirmed 시 자동 사용

- v0.7.1 SaveReader 시즌 anchor 저장형식 마이그레이션 호환 추가
- 판독기 ZIP 설치 실패 시 기존 활성 판독기 자동 롤백
- 초기 manifest에 v1.7 capability 상태를 포함하여 세이브 연결 전에도 confirmed/pending/unmapped 현황 표시
