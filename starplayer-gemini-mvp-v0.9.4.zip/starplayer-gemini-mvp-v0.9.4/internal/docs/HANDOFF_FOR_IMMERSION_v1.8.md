# 몰입모드 연동 HANDOFF — SaveReader Contract v1.8

## 계약

- `schema_version = 1` 고정.
- 기존 필드명은 변경하지 않는다.
- 몰입모드는 `status = confirmed`만 자동입력한다.
- `pending`, `unmapped`, `value = null`은 추정하거나 자동입력하지 않는다.
- SaveReader 업데이트로 미확정 필드가 검증되면 같은 필드명의 status/value만 변경한다.

## v1.8 포지션 코드

GAME LOG의 `position`은 다음 후보 매핑을 사용한다.

- `0=P` → confirmed
- `1=C` → pending
- `2=1B` → pending
- `3=2B` → pending
- `4=3B` → pending
- `5=SS` → pending
- `6=LF` → pending
- `7=CF` → pending
- `8=RF` → pending
- `9=DH` → pending
- `10=PH` → confirmed

따라서 예를 들어 코드 8이 나오면 SaveReader는:

```json
"position": {
  "value": "RF",
  "status": "pending"
}
```

처럼 출력한다. 몰입모드는 이 값을 아직 자동입력하면 안 된다.
실제 우익수 출전 세이브로 코드 8이 검증되면 추후 `status: confirmed`로만 승격한다.

## 투수 경기결정

GAME LOG `decision_code`는 계속 확정:

- `0 = 승패 없음`
- `1 = 승`
- `2 = 패`

`pitching.win`, `pitching.loss`, `pitching.no_decision` 모두 confirmed.

## 판독 우선순위

1. GAME LOG 직접 판독
2. 일정/스코어 결합
3. 확정된 시즌 누적값으로 필요한 보완·검증

불확실한 값이 GAME LOG의 confirmed 값을 덮어쓰면 안 된다.
