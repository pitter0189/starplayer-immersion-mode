# v0.6.1

- Gemini 모델명을 직접 입력하지 않고 `Gemini 3.5 Flash-Lite` / `Gemini 3.6 Flash` 중 선택하도록 변경
- 최초 설정과 일반 설정 화면 모두 동일한 모델 선택 UI 사용
- 메인 모델 기본 선택: Gemini 3.5 Flash-Lite
- 인터뷰/LINE 모델 기본 선택: Gemini 3.6 Flash
- Windows 시작 시 서버가 실제 listen 상태가 된 뒤 `http://127.0.0.1:3000`을 기본 브라우저로 여는 방식으로 변경
