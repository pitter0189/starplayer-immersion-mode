# v0.7.0

- StarPlayer.dat 자동 기록판독 통합
- SaveReader 내부 실행 파일 포함, Gemini와 독립 판독
- explicit baseline 연결 / 미연결·감시·일시정지·blocked 상태
- DAT 안정화 후 snapshot 판독, pending queue, 2+ 경기 안전 차단
- 팀 완료 경기 count 출력 보강
- 자동 DNP 후보
- 상단 SAVE 상태 및 설정 UI
- 새 주인공/시즌 초기화 시 SaveReader 연결 안전 해제
- 주인공 성격/말투/HARD/SOFT 등 최초 등록 후 수정 가능
- LINE 가까운 관계 말투 및 비전문가 야구지식 경계 강화
- 인터뷰 답변 버튼 우측 정렬
- 공식 인터뷰 기사/커뮤니티 반영 품질 검증
- 커뮤니티 댓글 기본량 증가
- 시즌 타임라인 다크 스크롤 유지
