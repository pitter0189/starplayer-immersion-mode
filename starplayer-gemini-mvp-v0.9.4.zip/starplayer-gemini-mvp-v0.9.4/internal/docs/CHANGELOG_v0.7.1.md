# v0.7.1

- 자동 기록판독 엔진을 SaveReader Confirmed v1.4로 교체
- GAME LOG base `0x24BF8` 적용, 구 `0x24C88` 경로 제거
- `--compare` + `verified=true` + `new_game_log_count=1` 안전 조건 적용
- 직접 GAME LOG 기록을 누적 차분보다 우선 사용
- 일정/스코어 테이블로 날짜·상대·홈원정·스코어·승패 연결
- 한 경기 검증 시 투수 BB/HBP 분리값 사용
- 타순 및 P/PH 확정 포지션 자동 판독 반영
- 경기별 미확정 타자 HBP/도루/2B/3B 및 투구수 자동입력 금지
- 승리/HQS raw/세이브 자동 확정 금지, 패전 decision_code=2만 자동 반영
- 시즌 누적 확정 필드를 최초 연결 baseline 대비 차분으로 시즌 기록 보정
- 기존 캐릭터 설정과 세이브 연결 분리 안전장치 유지
