# GAME LOG 포지션 코드 매핑 — v1.8

| 코드 | 출력 | 상태 | 근거 |
|---:|---|---|---|
| 0 | P | confirmed | 실제 제공 세이브에서 투수 출전과 직접 일치 |
| 1 | C | pending | 시리즈 내부 포지션 enum/연속 구조 근거, GAME LOG 직접 검증 전 |
| 2 | 1B | pending | 동일 |
| 3 | 2B | pending | 동일 |
| 4 | 3B | pending | 동일 |
| 5 | SS | pending | 동일 |
| 6 | LF | pending | 동일 |
| 7 | CF | pending | 동일 |
| 8 | RF | pending | 동일 |
| 9 | DH | pending | enum 순서상 후보, GAME LOG 직접 검증 전 |
| 10 | PH | confirmed | 실제 제공 세이브에서 대타 출전과 직접 일치 |

## 동작 원칙

- 코드 0/10은 `position.value`와 함께 `status: confirmed`.
- 코드 1~9는 이름을 제공하지만 `status: pending`.
- 알 수 없는 코드는 `value: null`, `status: unmapped`.
- 몰입모드는 confirmed만 자동입력한다.
- 실제 플레이 표본으로 확인된 포지션은 다음 버전에서 필드명 변경 없이 status만 confirmed로 승격한다.
