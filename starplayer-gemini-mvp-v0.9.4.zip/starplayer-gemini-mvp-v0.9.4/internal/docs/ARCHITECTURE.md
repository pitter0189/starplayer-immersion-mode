# v0.9 Architecture

## 기본 원칙

- 로컬에는 항상 하나의 현재 메인 캐릭터만 존재합니다.
- 새 메인 캐릭터를 확정하면 기존 세계를 자동 백업한 뒤 완전 교체합니다.
- 사용자 입력과 사용자가 검토한 캐릭터 설정이 생성 결과보다 우선합니다.
- Gemini는 구조화/표현을 담당하고, 누적 기록과 상태 변경은 프로그램이 계산합니다.

## `simulation.mjs`

Gemini 없이도 사용할 수 있는 규칙 엔진입니다.

- 경기/이벤트 오프라인 파서 fallback
- `사사구` 기본 처리
- 이닝 ↔ outs 변환
- PERFORMANCE GRADE / ATTENTION LEVEL
- 출력 플랫폼 계획
- 확정 데이터 프롬프트 포맷

## `db.mjs`

로컬 JSON 상태 저장소입니다.

- 현재 메인 캐릭터 canon / dynamic state
- 시즌 목록(2026부터 시작)
- 경기 / 이벤트 / 미출전 / 휴일
- 투수/타자 line
- 생성 콘텐츠 / 반복 억제 memory
- 등장인물 / LINE / 인터뷰
- 부분 정정 및 누적 재계산
- 새 메인 캐릭터 교체 전 자동 백업

## `gemini.mjs`

Gemini 어댑터입니다.

- 새 메인 캐릭터 설정 문서 분석
- 경기/이벤트 Structured JSON 추출
- 기사/커뮤니티 생성
- 인터뷰 질문 생성
- LINE 장면/답장 생성

메인 / 인터뷰 / LINE API와 모델을 각각 분리할 수 있으며 배포본에는 기본 API 키나 모델명이 없습니다.

## `server.mjs`

로컬 HTTP API와 정적 UI를 제공합니다.

- 최초 실행 onboarding
- 일정 입력/수정/삭제
- 시즌 관리
- 캐릭터/LINE/인터뷰
- API 설정

## `public/`

데스크톱 중심 UI입니다.

- 날짜 중심 Daily Timeline
- 상세 시즌 기록 아코디언
- 월별 경기 원장
- 중앙 영역 1/3 LINE drawer + 전체 LINE 화면
- 독립 다크 스크롤 영역
- 캐릭터 최초 설정 마법사


## v0.9 반응권 / 커뮤니티 계획

PLAYER CANON의 `reactionScopes`를 규칙 엔진이 읽어 OUTPUT PLAN을 구성합니다. 기본 새 캐릭터는 일본 야구만 활성화됩니다. 활성 반응권이 늘어나면 기존 플랫폼을 줄이지 않고 플랫폼과 총 생성량이 추가됩니다.

각 community plan에는 `commentsMin`, `commentsMax`, `nestedShare`, `angleHint`가 포함됩니다. Gemini 출력은 `primaryAngle`을 함께 반환하며, 계획 누락·댓글량·대댓글 비율·플랫폼 간 관점 유사도를 자동 검수합니다.

X는 내부적으로 `x_jp`, `x_kr`을 별도 생성하지만 UI에서는 하나의 X 카드로 합칩니다.

## Windows browser helper

브라우저 자동 실행은 서버 프로세스와 분리합니다. `scripts/open-browser.ps1`이 서버의 실제 HTTP 준비 상태를 확인한 뒤 Windows shell을 통해 URL을 열며, 실패 이력을 `data/browser-open.log`에 남깁니다.
