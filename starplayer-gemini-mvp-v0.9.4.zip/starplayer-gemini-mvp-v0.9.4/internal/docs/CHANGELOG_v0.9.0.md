# v0.9.0 변경사항

## 반응권
- 기본: 일본 야구 ON
- 선택: 한국 야구 / 한국 SNS
- 활성 반응권 증가에 따라 총 생성량도 증가

## 플랫폼
- 일본: 5ch 전력분석 / 야구ch / 소속팀 팬 커뮤니티 / 일본 X
- 한국 야구: MLBPARK / 디시 야갤
- 한국 SNS: 한국 X / 더쿠
- 일본·한국 X 동시 생성 시 하나의 X 카드에서 지역 구분

## 생성 품질
- 야구ch / 야갤: 대댓글이 원댓글보다 많도록 검수
- 최소 한 depth 2 체인 요구
- 플랫폼별 primaryAngle 분리
- 계획된 플랫폼/게시글 누락 검수
- 최근 콘텐츠 반복 방지와 함께 최대 1회 재생성

## Windows 브라우저 자동 실행
- Node 서버의 직접 browser spawn 제거
- START_WINDOWS.bat가 PowerShell helper를 백그라운드 실행
- http://127.0.0.1:3000 실제 응답 후 브라우저 실행
- Start-Process URL → explorer.exe → cmd start fallback
- data/browser-open.log 진단 로그

## 유지
- SaveReader Contract v1.7 / schema v1 confirmed-only 플러그인 업데이트 구조
- 시즌 중간 연결 시 누적 기록 포함/연결 이후만 선택
- 주인공 설정 사후 수정, 인터뷰 검수, LINE 별도 API, 기록 부분 수정 등 v0.8.1 기능 유지
