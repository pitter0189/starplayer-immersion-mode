# v0.9.2 internal changelog

- Bundled SaveReader updated from Contract v1.7 to Contract v1.8.
- Position code mapping is treated as trusted for this distribution at the user's request:
  - 0=P, 1=C, 2=1B, 3=2B, 4=3B, 5=SS, 6=LF, 7=CF, 8=RF, 9=DH, 10=PH.
- Upstream v1.8 marks 1-9 as pending. The active bundled reader promotes those position statuses to confirmed only; other contract statuses remain unchanged.
- The immersion app itself continues to consume only confirmed contract values and does not hard-code SaveReader memory offsets.
- Future compatible SaveReader ZIP updates can replace the bundled reader through the existing updater; their schema/status values take precedence after update.
