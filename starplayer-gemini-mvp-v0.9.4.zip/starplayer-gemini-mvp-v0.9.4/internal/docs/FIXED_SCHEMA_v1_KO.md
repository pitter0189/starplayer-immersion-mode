# 몰입모드용 SaveReader 고정 스키마 v1

## 상태 의미

- `confirmed`: 실제 세이브/게임 화면/전후 차분 등으로 충분히 검증됨. 자동입력 가능.
- `pending`: 후보 위치 또는 계산 경로가 있으나 실전 양성 검증이 부족함. 자동입력 금지.
- `unmapped`: 아직 신뢰할 수 있는 위치/방법을 찾지 못함. 자동입력 금지.

`value`가 `null`이면 값이 현재 판독 컨텍스트에서 제공되지 않는다는 뜻이다. 몰입모드는 추정하지 않는다.

## 경기 기본 정보

항상 출력:

- `game.date`
- `game.opponent`
- `game.home_away`
- `game.team_score`
- `game.opponent_score`
- `game.result`

현재 모두 `confirmed`.

## 경기별 타격

항상 출력:

- `batting.lineup_order`
- `batting.position`
- `batting.plate_appearances`
- `batting.at_bats`
- `batting.hits`
- `batting.singles`
- `batting.doubles`
- `batting.triples`
- `batting.home_runs`
- `batting.rbi`
- `batting.runs`
- `batting.walks`
- `batting.hbp`
- `batting.strikeouts`
- `batting.stolen_bases`
- `batting.grounded_into_double_play`
- `batting.errors`

현재 주의:

- `position`: 포지션 코드 슬롯은 다음처럼 매핑한다. `0=P`, `10=PH`는 실제 GAME LOG로 검증되어 `confirmed`. `1=C`, `2=1B`, `3=2B`, `4=3B`, `5=SS`, `6=LF`, `7=CF`, `8=RF`, `9=DH`는 임시 매핑으로 값을 출력하되 `pending`. 몰입모드는 pending 포지션을 자동입력하지 않는다.
- `plate_appearances`: 시즌 누적 후보를 이용한 차분값은 `pending`.
- `singles/doubles/triples`: 정확히 한 경기만 추가된 `--compare`에서는 확정 시즌 누적 변화량과 게임로그를 교차검증해 `confirmed`로 출력.
- `hbp`, `stolen_bases`: 후보 누적 필드 변화량만 있어 `pending`.
- `grounded_into_double_play`, `errors`: `unmapped`.

## 경기별 투구

항상 출력:

- `pitching.appeared`
- `pitching.started`
- `pitching.innings_outs`
- `pitching.batters_faced`
- `pitching.pitch_count`
- `pitching.hits_allowed`
- `pitching.home_runs_allowed`
- `pitching.walks`
- `pitching.hbp`
- `pitching.strikeouts`
- `pitching.runs`
- `pitching.earned_runs`
- `pitching.win`
- `pitching.loss`
- `pitching.no_decision`
- `pitching.hold`
- `pitching.save`
- `pitching.blown_save`
- `pitching.quality_start`
- `pitching.quality_start_plus`

현재 확정 결정 코드:

- `0` = 승패 없음 → `win=false`, `loss=false`, `no_decision=true`
- `1` = 승 → `win=true`, `loss=false`, `no_decision=false`
- `2` = 패 → `win=false`, `loss=true`, `no_decision=false`

현재 주의:

- `started`: 시즌 선발 수 후보 변화량은 있으나 구원 등판 양성 표본 부족 → `pending`.
- `pitch_count`: 계속 추적하되 현재 `unmapped`.
- `walks`, `hbp`: GAME LOG에는 합계가 직접 저장되며, 정확히 한 경기인 `--compare`에서 확정 시즌 누적 BB/HBP 변화량과 합계가 일치할 때만 각각 `confirmed`로 분리.
- `hold`, `blown_save`: `unmapped`.
- `save`: 후보 필드만 존재 → `pending`.
- `quality_start`: 시즌 QS 누적 변화량으로 `confirmed`.
- `quality_start_plus`: 후보 누적 필드는 있으나 실제 +1 양성 표본 부족 → `pending`.

## 시즌 누적 타격

항상 출력:

- `season.batting.games`
- `season.batting.plate_appearances`
- `season.batting.at_bats`
- `season.batting.hits`
- `season.batting.singles`
- `season.batting.doubles`
- `season.batting.triples`
- `season.batting.home_runs`
- `season.batting.rbi`
- `season.batting.runs`
- `season.batting.walks`
- `season.batting.hbp`
- `season.batting.strikeouts`
- `season.batting.stolen_bases`
- `season.batting.grounded_into_double_play`
- `season.batting.errors`

현재 `pending`: `plate_appearances`, `hbp`, `stolen_bases`.
현재 `unmapped`: `grounded_into_double_play`, `errors`.
나머지는 현재 검증 범위에서 `confirmed`.

## 시즌 누적 투구

항상 출력:

- `season.pitching.appearances`
- `season.pitching.starts`
- `season.pitching.innings_outs`
- `season.pitching.batters_faced`
- `season.pitching.pitch_count`
- `season.pitching.hits_allowed`
- `season.pitching.home_runs_allowed`
- `season.pitching.walks`
- `season.pitching.hbp`
- `season.pitching.strikeouts`
- `season.pitching.runs`
- `season.pitching.earned_runs`
- `season.pitching.wins`
- `season.pitching.losses`
- `season.pitching.holds`
- `season.pitching.saves`
- `season.pitching.blown_saves`
- `season.pitching.quality_starts`
- `season.pitching.quality_start_plus`

현재 `pending`: `starts`, `saves`, `quality_start_plus`.
현재 `unmapped`: `pitch_count`, `holds`, `blown_saves`.
나머지는 현재 검증 범위에서 `confirmed`.

## 계산형 지표

AVG / OBP / SLG / OPS / ERA / WHIP / K/BB / K/9 / BB/9 / HR/9 등은 원시 기록에서 정확히 계산할 수 있으므로 고정 메모리 매핑 필수 항목으로 두지 않는다.
