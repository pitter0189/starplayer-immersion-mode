@echo off
setlocal
cd /d "%~dp0"

echo [STAR PLAYER] Starting preflight...
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js was not found.
  echo Install Node.js 20 or newer, then open a new terminal.
  pause
  exit /b 1
)

node scripts\preflight.mjs
if errorlevel 1 (
  pause
  exit /b 1
)

if not exist .env (
  copy .env.example .env >nul
  echo.
  echo Created .env file.
  echo API and model settings are entered in the first-run setup screen.
)

if not exist node_modules\@google\genai (
  echo.
  echo Installing Gemini SDK...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo npm install failed. Check the error above and your internet/npm setup.
    pause
    exit /b 1
  )
)

echo.
echo Starting STAR PLAYER...
start "" /b powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\open-browser.ps1" "http://127.0.0.1:3000"
call npm start
if errorlevel 1 (
  echo.
  echo Server stopped with an error. Copy the error lines above if you need help.
  if exist data\browser-open.log (
    echo Browser helper log: %~dp0data\browser-open.log
  )
  pause
  exit /b 1
)
